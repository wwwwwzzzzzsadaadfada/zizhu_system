<template>
  <div class="app-container">
    <el-row :gutter="20" class="stats-row">
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat-label">预算总额(元)</div>
          <div class="stat-value primary">{{ formatAmount(statistics.totalBudget) }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat-label">已使用(元)</div>
          <div class="stat-value warn">{{ formatAmount(statistics.usedAmount) }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat-label">锁定中(元)</div>
          <div class="stat-value info">{{ formatAmount(statistics.lockedAmount) }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat-label">可用余额(元)</div>
          <div class="stat-value success">{{ formatAmount(statistics.availableAmount) }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学年学期" prop="yearSemesterId">
        <el-select v-model="queryParams.yearSemesterId" placeholder="请选择" clearable filterable>
          <el-option
            v-for="item in yearSemesters"
            :key="item.id"
            :label="`${item.schoolYear} ${semesterLabel(item.semester)}`"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="预算项目" prop="budgetProjectName">
        <el-input
          v-model="queryParams.budgetProjectName"
          placeholder="请输入预算项目名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="经济分类" prop="economyCategory">
        <el-select v-model="queryParams.economyCategory" placeholder="请选择经济分类" clearable>
          <el-option
            v-for="dict in dict.type.sys_economy_category"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status" placeholder="请选择状态" clearable>
          <el-option
            v-for="dict in dict.type.sys_budget_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:semesterBudget:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="budgetList">
      <el-table-column label="预算项目" prop="budgetProjectName" min-width="160" show-overflow-tooltip />
      <el-table-column label="关联指标" min-width="200" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-link
            v-if="scope.row.quotaId && scope.row.quotaDocTitle"
            type="primary"
            @click.native.prevent="openQuotaDetail(scope.row)"
          >
            {{ scope.row.quotaDocTitle }}
          </el-link>
          <span v-else>-</span>
        </template>
      </el-table-column>
      <el-table-column label="指标来源" prop="quotaSourceType" width="120">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_quota_source_type" :value="scope.row.quotaSourceType" />
        </template>
      </el-table-column>
      <el-table-column label="学年/学期" min-width="150">
        <template slot-scope="scope">
          {{ scope.row.schoolYear || '-' }} {{ semesterLabel(scope.row.semester) }}
        </template>
      </el-table-column>
      <el-table-column label="经济分类" prop="economyCategory" width="120">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_economy_category" :value="scope.row.economyCategory" />
        </template>
      </el-table-column>
      <el-table-column label="预算类型" prop="budgetType" min-width="120" />
      <el-table-column label="预算总额(元)" prop="budgetAmount" width="140">
        <template slot-scope="scope">
          {{ formatAmount(scope.row.budgetAmount) }}
        </template>
      </el-table-column>
      <el-table-column label="已使用(元)" prop="usedAmount" width="140">
        <template slot-scope="scope">
          {{ formatAmount(scope.row.usedAmount) }}
        </template>
      </el-table-column>
      <el-table-column label="锁定(元)" prop="lockedAmount" width="140">
        <template slot-scope="scope">
          {{ formatAmount(scope.row.lockedAmount) }}
        </template>
      </el-table-column>
      <el-table-column label="可用余额(元)" prop="availableAmount" width="140">
        <template slot-scope="scope">
          {{ formatAmount(scope.row.availableAmount) }}
        </template>
      </el-table-column>
      <el-table-column label="状态" prop="status" width="110">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_budget_status" :value="scope.row.status" />
        </template>
      </el-table-column>
      <el-table-column label="创建时间" prop="createTime" width="170">
        <template slot-scope="scope">
          {{ parseTime(scope.row.createTime, '{y}-{m}-{d} {h}:{i}') }}
        </template>
      </el-table-column>
      <el-table-column label="操作" fixed="right" width="150" align="center">
        <template slot-scope="scope">
          <el-select
            v-model="scope.row.status"
            size="mini"
            :disabled="isStatusDisabled(scope.row)"
            @change="handleStatusChange(scope.row)"
            style="width: 100px"
            v-hasPermi="['system:semesterBudget:edit']"
          >
            <el-option
              v-for="dict in dict.type.sys_budget_status"
              :key="dict.value"
              :label="dict.label"
              :value="parseInt(dict.value)"
            />
          </el-select>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 指标详情抽屉 -->
    <el-drawer
      title="指标详情"
      :visible.sync="quotaDetailVisible"
      size="55%"
      append-to-body
      class="quota-detail-drawer"
    >
      <div v-if="quotaDetailRecord" class="quota-detail-content">
        <!-- 基本信息卡片 -->
        <el-card class="detail-info-card" shadow="never">
          <div slot="header" class="card-header">
            <i class="el-icon-document"></i>
            <span>基本信息</span>
      </div>
          <el-descriptions :column="2" border size="medium" class="detail-descriptions">
            <el-descriptions-item label="指标文号" :span="1">
              <span class="info-value">{{ quotaDetailRecord.quotaDocNo || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="指标标题" :span="1">
              <span class="info-value">{{ quotaDetailRecord.quotaDocTitle || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="学年" :span="1">
              <el-tag size="small" type="info">{{ quotaDetailRecord.schoolYear || '-' }}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="学期" :span="1">
              <el-tag size="small" type="info">{{ semesterLabel(quotaDetailRecord.semester) || '-' }}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="预算项目" :span="2">
              <span class="info-value">{{ quotaDetailRecord.budgetProjectName || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="功能分类" :span="1">
              <dict-tag :options="dict.type.sys_function_category" :value="quotaDetailRecord.functionCategory" />
            </el-descriptions-item>
            <el-descriptions-item label="预算来源" :span="1">
              <dict-tag :options="dict.type.sys_budget_source" :value="quotaDetailRecord.budgetSource" />
            </el-descriptions-item>
            <el-descriptions-item label="预算级次" :span="1">
              <dict-tag :options="dict.type.sys_budget_level" :value="quotaDetailRecord.budgetLevel" />
            </el-descriptions-item>
            <el-descriptions-item label="指标来源" :span="1">
              <dict-tag :options="dict.type.sys_quota_source_type" :value="quotaDetailRecord.quotaSourceType" />
            </el-descriptions-item>
            <el-descriptions-item label="备注" :span="2">
              <span class="info-value">{{ quotaDetailRecord.memo || '-' }}</span>
            </el-descriptions-item>
          </el-descriptions>
        </el-card>

        <!-- 经济分类明细卡片 -->
        <el-card class="detail-table-card" shadow="never">
          <div slot="header" class="card-header">
            <i class="el-icon-s-grid"></i>
            <span>经济分类明细</span>
            <span class="detail-count">（共 {{ (quotaDetailRecord.detailList || []).length }} 项）</span>
          </div>
          <el-table
            :data="(quotaDetailRecord && quotaDetailRecord.detailList) || []"
            border
            stripe
            class="detail-table"
            :header-cell-style="{ background: '#f5f7fa', color: '#303133', fontWeight: '600' }"
          >
            <el-table-column label="序号" type="index" width="60" align="center" />
            <el-table-column label="经济分类" min-width="140" align="center">
              <template slot-scope="scope">
                <dict-tag :options="dict.type.sys_economy_category" :value="scope.row.economyCategory" />
              </template>
            </el-table-column>
            <el-table-column label="总金额(元)" min-width="130" align="right">
              <template slot-scope="scope">
                <span class="amount-text">{{ formatAmount(scope.row.totalAmount) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="已分配(元)" min-width="130" align="right">
              <template slot-scope="scope">
                <span class="amount-text allocated">{{ formatAmount(scope.row.allocatedAmount) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="剩余(元)" min-width="130" align="right">
              <template slot-scope="scope">
                <span class="amount-text available">
                  {{ formatAmount(scope.row.availableAmount != null ? scope.row.availableAmount : scope.row.totalAmount - scope.row.allocatedAmount) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="备注" prop="memo" min-width="150" align="center" show-overflow-tooltip>
              <template slot-scope="scope">
                <span class="memo-text">{{ scope.row.memo || '-' }}</span>
              </template>
            </el-table-column>
          </el-table>
        </el-card>

        <!-- 指标附件卡片 -->
        <el-card class="detail-attachment-card" shadow="never">
          <div slot="header" class="card-header">
            <i class="el-icon-paperclip"></i>
            <span>指标附件</span>
            <span class="detail-count">（共 {{ (quotaDetailAttachmentList || []).length }} 个）</span>
          </div>
          <div v-if="quotaDetailAttachmentList && quotaDetailAttachmentList.length > 0" class="attachment-list">
            <div v-for="(file, index) in quotaDetailAttachmentList" :key="file.id || index" class="attachment-item">
              <i class="el-icon-document"></i>
              <span class="file-name" :title="file.name">{{ file.name }}</span>
              <span class="file-size">({{ formatFileSize(file.size) }})</span>
              <div class="actions">
                <el-button type="text" size="small" @click="handleQuotaAttachmentPreview(file)">预览</el-button>
                <el-button type="text" size="small" @click="handleQuotaAttachmentDownload(file)">下载</el-button>
              </div>
            </div>
          </div>
          <div v-else class="no-attachment">
            <i class="el-icon-document-delete"></i>
            <span>暂无附件</span>
          </div>
        </el-card>
      </div>
    </el-drawer>

    <!-- 文件预览对话框 -->
    <el-dialog
      title="文件预览"
      :visible.sync="previewDialogVisible"
      width="80%"
      append-to-body
      class="preview-dialog"
    >
      <div v-if="previewData" class="preview-content">
        <!-- PDF预览 -->
        <div v-if="previewData.previewType === 'pdf' && previewData.imageUrls" class="pdf-preview">
          <div v-for="(imageUrl, index) in previewData.imageUrls" :key="index" class="pdf-page">
            <img :src="getImageUrl(imageUrl)" :alt="'第' + (index + 1) + '页'" />
            <div class="page-number">第 {{ index + 1 }} 页</div>
          </div>
        </div>
        <!-- 图片预览 -->
        <div v-else-if="previewData.previewType === 'image'" class="image-preview">
          <img :src="getImageUrl(previewData.imageUrl)" :alt="previewData.fileName" />
        </div>
        <!-- HTML预览 -->
        <div v-else-if="previewData.previewType === 'html'" class="html-preview">
          <iframe :srcdoc="previewData.htmlContent" frameborder="0" style="width: 100%; height: 600px;"></iframe>
        </div>
        <!-- 文本预览 -->
        <div v-else-if="previewData.previewType === 'text'" class="text-preview">
          <pre>{{ previewData.textContent }}</pre>
        </div>
        <!-- 不支持预览 -->
        <div v-else class="unsupported-preview">
          <el-alert
            title="不支持预览此文件类型"
            type="warning"
            :closable="false"
            show-icon
          />
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="previewDialogVisible = false">关 闭</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import {
  listSemesterBudget,
  changeSemesterBudgetStatus,
  budgetStatistics
} from '@/api/system/semesterBudget'
import { listYearSemesters } from '@/api/system/yearSemester'
import { getSubsidyQuota } from '@/api/system/subsidyQuota'
import {
  listQuotaAttachmentByQuotaId,
  downloadQuotaAttachment,
  previewQuotaAttachment,
  previewQuotaAttachmentAsync
} from '@/api/system/quotaAttachment'

export default {
  name: 'SemesterBudget',
  dicts: ['sys_budget_status', 'sys_economy_category', 'sys_quota_source_type', 'sys_function_category', 'sys_budget_source', 'sys_budget_level'],
  data() {
    return {
      loading: false,
      showSearch: true,
      budgetList: [],
      total: 0,
      yearSemesters: [],
      statistics: {
        totalBudget: 0,
        usedAmount: 0,
        lockedAmount: 0,
        availableAmount: 0
      },
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        yearSemesterId: undefined,
        budgetProjectName: undefined,
        economyCategory: undefined,
        status: undefined
      },
      quotaDetailVisible: false,
      quotaDetailRecord: null,
      quotaDetailAttachmentList: [], // 指标详情附件列表
      previewDialogVisible: false, // 预览对话框
      previewData: null // 预览数据
    }
  },
  created() {
    this.getList()
    this.fetchYearSemesters()
  },
  methods: {
    /** 判断状态是否可修改（已使用资金时不可修改） */
    isStatusDisabled(row) {
      const usedAmount = parseFloat(row.usedAmount || 0)
      return usedAmount > 0
    },
    /** 处理状态变更 */
    handleStatusChange(row) {
      const originalStatus = row.status
      const statusText = this.getStatusLabel(row.status)
      this.$modal.confirm(`确定要将该预算状态修改为"${statusText}"吗？`).then(() => {
        return changeSemesterBudgetStatus(row.id, row.status)
      }).then(() => {
        this.$modal.msgSuccess('状态更新成功')
        this.getList()
      }).catch((error) => {
        // 如果取消或失败，恢复原状态并显示错误信息
        row.status = originalStatus
        if (error && error.message) {
          this.$modal.msgError(error.message)
        }
        this.getList()
      })
    },
    /** 获取状态标签 */
    getStatusLabel(status) {
      if (!this.dict.type.sys_budget_status) return status
      const dict = this.dict.type.sys_budget_status.find(item => parseInt(item.value) === status)
      return dict ? dict.label : status
    },
    fetchYearSemesters() {
      listYearSemesters({ pageNum: 1, pageSize: 999 }).then(res => {
        this.yearSemesters = res.rows || []
      })
    },
    getList() {
      this.loading = true
      listSemesterBudget(this.queryParams).then(res => {
        this.budgetList = res.rows || []
        this.total = res.total || 0
      }).finally(() => {
        this.loading = false
      })
      this.loadStatistics()
    },
    loadStatistics() {
      budgetStatistics(this.queryParams).then(res => {
        this.statistics = res.data || this.statistics
      })
    },
    handleQuery() {
      this.queryParams.pageNum = 1
      this.getList()
    },
    resetQuery() {
      this.resetForm('queryForm')
      this.handleQuery()
    },
    handleExport() {
      this.download('system/semesterBudget/export', { ...this.queryParams }, `semester_budget_${new Date().getTime()}.xlsx`)
    },
    formatAmount(val) {
      const num = Number(val || 0)
      return num.toFixed(2)
    },
    semesterLabel(value) {
      if (value === undefined || value === null || value === '') {
        return ''
      }
      return String(value) === '2' ? '第二学期' : '第一学期'
    },
    /** 打开指标详情 */
    openQuotaDetail(row) {
      if (!row || !row.quotaId) {
        this.$modal.msgWarning('该预算未关联指标')
        return
      }
      this.quotaDetailVisible = true
      this.quotaDetailRecord = null
      this.quotaDetailAttachmentList = []
      getSubsidyQuota(row.quotaId).then(res => {
        this.quotaDetailRecord = res.data || null
        // 加载附件列表
        this.loadQuotaDetailAttachments(row.quotaId)
      }).catch(err => {
        console.error('获取指标详情失败:', err)
        this.$modal.msgError('获取指标详情失败')
        this.quotaDetailVisible = false
      })
    },
    // 加载指标详情附件
    loadQuotaDetailAttachments(quotaId) {
      if (!quotaId) {
        this.quotaDetailAttachmentList = []
        return
      }
      listQuotaAttachmentByQuotaId(quotaId).then(res => {
        if (res.code === 200 && res.data) {
          this.quotaDetailAttachmentList = (res.data || []).map(item => ({
            id: item.id,
            name: item.fileName,
            size: item.fileSize,
            url: item.fileUrl,
            uid: item.id
          }))
        } else {
          this.quotaDetailAttachmentList = []
        }
      }).catch(err => {
        console.error('加载指标详情附件失败:', err)
        this.quotaDetailAttachmentList = []
      })
    },
    // 预览指标附件
    handleQuotaAttachmentPreview(file) {
      if (!file.id) {
        this.$modal.msgWarning('文件未上传成功，无法预览')
          return
        }
      this.$modal.loading('正在加载预览...')
      previewQuotaAttachment(file.id).then(res => {
        this.$modal.closeLoading()
        if (res.code === 200 && res.data) {
          this.previewData = res.data
          this.previewDialogVisible = true
        } else {
          // 如果同步预览失败，尝试异步预览
          this.$modal.msgWarning('文件较大，正在异步处理，请稍后...')
          setTimeout(() => {
            previewQuotaAttachmentAsync(file.id).then(asyncRes => {
              if (asyncRes.code === 200 && asyncRes.data) {
                this.previewData = asyncRes.data
                this.previewDialogVisible = true
              } else {
                this.$modal.msgError('预览失败：' + (asyncRes.msg || '未知错误'))
              }
            }).catch(err => {
              this.$modal.msgError('预览失败：' + (err.msg || err))
            })
          }, 2000)
        }
      }).catch(err => {
        this.$modal.closeLoading()
        this.$modal.msgError('预览失败：' + (err.msg || err))
      })
    },
    // 下载指标附件
    handleQuotaAttachmentDownload(file) {
      if (!file.id) {
        this.$modal.msgWarning('文件未上传成功，无法下载')
        return
      }
      downloadQuotaAttachment(file.id).then(res => {
        const blob = new Blob([res])
        const link = document.createElement('a')
        link.href = window.URL.createObjectURL(blob)
        link.download = file.name
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        window.URL.revokeObjectURL(link.href)
        this.$modal.msgSuccess('下载成功')
      }).catch(err => {
        this.$modal.msgError('下载失败：' + (err.msg || err))
      })
    },
    // 格式化文件大小
    formatFileSize(size) {
      if (!size) return '0 B'
      if (size < 1024) return size + ' B'
      if (size < 1024 * 1024) return (size / 1024).toFixed(2) + ' KB'
      if (size < 1024 * 1024 * 1024) return (size / (1024 * 1024)).toFixed(2) + ' MB'
      return (size / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
    },
    // 获取基础URL
    getBaseURL() {
      return process.env.VUE_APP_BASE_API || ''
    },
    // 获取图片完整URL
    getImageUrl(imageUrl) {
      if (!imageUrl) return ''
      if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
        return imageUrl
      }
      return this.getBaseURL() + imageUrl
    }
  }
}
</script>

<style scoped>
.stats-row {
  margin-bottom: 20px;
}
.stat-label {
  color: #909399;
  font-size: 13px;
}
.stat-value {
  font-size: 22px;
  font-weight: 600;
  margin-top: 6px;
}
.stat-value.primary {
  color: #1890ff;
}
.stat-value.warn {
  color: #e6a23c;
}
.stat-value.info {
  color: #606266;
}
.stat-value.success {
  color: #67c23a;
}

/* 指标详情抽屉样式 */
.quota-detail-drawer {
  font-size: 14px;
}

.quota-detail-content {
  padding: 0;
}

.detail-info-card,
.detail-table-card {
  margin-bottom: 20px;
}

.detail-info-card:last-child,
.detail-table-card:last-child {
  margin-bottom: 0;
}

.card-header {
  display: flex;
  align-items: center;
  font-weight: 600;
  font-size: 15px;
  color: #303133;
}

.card-header i {
  margin-right: 8px;
  font-size: 16px;
  color: #409eff;
}

.detail-descriptions {
  margin-top: 10px;
}

.info-value {
  color: #303133;
  font-weight: 500;
}

.amount-stats {
  margin-top: 10px;
}

.amount-item {
  text-align: center;
  padding: 15px 0;
}

.amount-label {
  font-size: 13px;
  color: #909399;
  margin-bottom: 8px;
}

.amount-value {
  font-size: 24px;
  font-weight: 600;
  line-height: 1.2;
}

.amount-value.primary {
  color: #409eff;
}

.amount-value.warning {
  color: #e6a23c;
}

.amount-value.success {
  color: #67c23a;
}

.detail-count {
  font-size: 13px;
  color: #909399;
  font-weight: normal;
  margin-left: 8px;
}

.detail-table {
  margin-top: 10px;
}

.amount-text {
  font-weight: 500;
  color: #303133;
}

.amount-text.allocated {
  color: #e6a23c;
}

.amount-text.available {
  color: #67c23a;
}

.memo-text {
  color: #606266;
  font-size: 13px;
}

/* 详情页附件样式 */
.detail-attachment-card {
  margin-top: 20px;
}

.attachment-list {
  margin-top: 10px;
  border: 1px solid #DCDFE6;
  border-radius: 4px;
  padding: 10px;
  background-color: #FAFAFA;
}

.attachment-item {
  display: flex;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px dashed #EBEEF5;
}

.attachment-item:last-child {
  border-bottom: none;
}

.attachment-item .el-icon-document {
  color: #909399;
  margin-right: 8px;
  font-size: 18px;
}

.attachment-item .file-name {
  flex: 1;
  color: #606266;
  font-size: 14px;
  margin-right: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.attachment-item .file-size {
  color: #909399;
  font-size: 12px;
  margin-right: 15px;
}

.attachment-item .actions {
  margin-left: auto;
}

.attachment-item .actions .el-button {
  padding: 0 5px;
  font-size: 13px;
}

.no-attachment {
  text-align: center;
  padding: 40px 20px;
  color: #909399;
  font-size: 14px;
}

.no-attachment .el-icon-document-delete {
  font-size: 48px;
  display: block;
  margin-bottom: 10px;
  opacity: 0.5;
}
</style>
