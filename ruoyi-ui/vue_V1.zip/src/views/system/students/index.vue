<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学年学期" prop="yearSemesterId">
        <el-select v-model="queryParams.yearSemesterId" placeholder="请选择学年学期" clearable style="width: 200px">
          <el-option
            v-for="item in yearSemesterOptions"
            :key="item.id"
            :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="姓名" prop="name">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入姓名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="身份证号" prop="idCardNo">
        <el-input
          v-model="queryParams.idCardNo"
          placeholder="请输入身份证号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="民族" prop="ethnicity">
        <el-select v-model="queryParams.ethnicity" placeholder="请选择民族" clearable>
          <el-option
            v-for="dict in dict.type.sys_student_ethnicity"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="所属年级" prop="gradeId">
        <el-select v-model="queryParams.gradeId" placeholder="请选择年级" clearable>
          <el-option
            v-for="item in allGradeOptions"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="困难类型" prop="difficultyTypeId">
        <el-select v-model="queryParams.difficultyTypeId" placeholder="请选择困难类型" clearable>
          <el-option
            v-for="dict in dict.type.sys_difficulty_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="脱贫户" prop="isPovertyReliefFamily">
        <el-select v-model="queryParams.isPovertyReliefFamily" placeholder="是否脱贫户" clearable>
          <el-option label="是" value="1" />
          <el-option label="否" value="0" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:students:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['system:students:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:students:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:students:export']"
        >导出</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="info"
          plain
          icon="el-icon-edit-outline"
          size="mini"
          :disabled="multiple"
          @click="handleBatchDifficulty"
          v-hasPermi="['system:students:edit']"
        >批量认定</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="studentsList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="id" width="80" />
      <el-table-column label="姓名" align="center" prop="name" width="100" />
      <el-table-column label="身份证号" align="center" prop="idCardNo" width="160" show-overflow-tooltip />
      <el-table-column label="性别" align="center" prop="gender" width="70">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_student_gender" :value="scope.row.gender"/>
        </template>
      </el-table-column>
      <el-table-column label="民族" align="center" prop="ethnicity" width="80">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_student_ethnicity" :value="scope.row.ethnicity"/>
        </template>
      </el-table-column>
      <el-table-column label="户籍所在地" align="center" prop="domicile" width="180" show-overflow-tooltip>
        <template slot-scope="scope">
          {{ formatDomicile(scope.row.domicile) }}
        </template>
      </el-table-column>
      <el-table-column label="学籍号" align="center" prop="studentNo" width="140" show-overflow-tooltip />
      <el-table-column label="当前学年学期" align="center" width="150">
        <template slot-scope="scope">
          <span v-if="scope.row.currentSchoolYear">
            {{ scope.row.currentSchoolYear }} {{ scope.row.currentSemester === 1 ? '第一学期' : scope.row.currentSemester === 2 ? '第二学期' : '' }}
          </span>
          <span v-else style="color: #909399;">未设置</span>
        </template>
      </el-table-column>
      <el-table-column label="所属学制" align="center" prop="schoolingYears" width="100">
        <template slot-scope="scope">
          {{ scope.row.schoolingYears }}
        </template>
      </el-table-column>
      <el-table-column label="年级/班级" align="center" width="180">
        <template slot-scope="scope">
          {{ formatGradeAndClass(scope.row) }}
        </template>
      </el-table-column>
      <el-table-column label="就读状态" align="center" prop="studyStatus" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_study_status" :value="scope.row.studyStatus"/>
        </template>
      </el-table-column>
      <el-table-column label="困难类型" align="center" prop="difficultyTypeId" width="220">
        <template slot-scope="scope">
          <span>{{ formatSupportInfo(scope.row) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="困难等级" align="center" prop="difficultyLevelId" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.difficultyLevelId" class="difficulty-pill">
            {{ formatDifficultyLevel(scope.row.difficultyLevelId) }}
          </span>
          <span v-else>-</span>
        </template>
      </el-table-column>
      <el-table-column label="备注" align="center" prop="memo" width="150" show-overflow-tooltip />
      <el-table-column label="操作" align="center" width="150" fixed="right">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:students:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:students:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改困难学生基础信息对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="1000px" append-to-body :close-on-click-modal="false">
      <el-alert
        class="form-tip"
        title="提示：学生基础信息是全系统的唯一权威数据，请仔细确认后再保存。"
        type="info"
        show-icon
        :closable="false"
      />
      <div class="section-nav">
        <el-button
          v-for="anchor in sectionAnchors"
          :key="anchor.id"
          type="text"
          :icon="anchor.icon"
          @click="scrollToSection(anchor.ref)"
        >
          {{ anchor.label }}
        </el-button>
      </div>
      <div class="form-scroll" ref="formScroll">
        <el-form ref="form" :model="form" :rules="rules" label-width="110px">
          <!-- 学期信息 -->
          <el-card shadow="never" class="form-card" ref="semesterSection">
            <div slot="header" class="card-header">
              <i class="el-icon-date"></i>
              <span>学期信息</span>
            </div>
            <el-row :gutter="20">
              <el-col :span="8">
                <el-form-item label="学年学期" prop="yearSemesterId">
                  <el-select v-model="form.yearSemesterId" placeholder="请选择学年学期" style="width: 100%">
                    <el-option
                      v-for="item in yearSemesterOptions"
                      :key="item.id"
                      :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
                      :value="item.id"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </el-card>

          <!-- 基本信息 -->
          <el-card shadow="never" class="form-card" ref="basicSection">
            <div slot="header" class="card-header">
              <i class="el-icon-user"></i>
              <span>基本信息</span>
            </div>
            <el-row :gutter="20">
              <el-col :span="8">
                <el-form-item label="姓名" prop="name">
                  <el-input v-model="form.name" placeholder="请输入姓名" maxlength="50" />
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="性别" prop="gender">
                  <el-select v-model="form.gender" placeholder="请选择性别" style="width: 100%">
                    <el-option
                      v-for="dict in dict.type.sys_student_gender"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="民族" prop="ethnicity">
                  <el-select v-model="form.ethnicity" placeholder="请选择民族" filterable style="width: 100%">
                    <el-option
                      v-for="dict in dict.type.sys_student_ethnicity"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="身份证号" prop="idCardNo">
                  <el-input v-model="form.idCardNo" placeholder="请输入18位身份证号" maxlength="18" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="学籍号" prop="studentNo">
                  <el-input v-model="form.studentNo" placeholder="请输入学籍号" maxlength="32" />
                </el-form-item>
              </el-col>
            </el-row>
          </el-card>

          <!-- 户籍信息 -->
          <el-card shadow="never" class="form-card" ref="domicileSection">
            <div slot="header" class="card-header">
              <i class="el-icon-location"></i>
              <span>户籍信息</span>
            </div>
            <el-row :gutter="20">
              <el-col :span="24">
                <el-form-item label="户籍所在地" prop="domicile">
                  <div v-if="form.id && form.domicile && !isEditingAddress" class="domicile-preview">
                    <el-input
                      :value="form.domicile"
                      readonly
                      style="width: 70%"
                    />
                    <el-button
                      type="text"
                      icon="el-icon-edit"
                      style="margin-left: 10px;"
                      @click="isEditingAddress = true"
                    >修改地址</el-button>
                  </div>
                  <div v-else class="domicile-inputs">
                    <el-cascader
                      v-model="form.regionCodes"
                      :options="guangxiRegions"
                      :props="{
                        value: 'value',
                        label: 'label',
                        children: 'children',
                        checkStrictly: true,
                        expandTrigger: 'hover'
                      }"
                      placeholder="请选择市/县/乡镇"
                      clearable
                      filterable
                      style="width: 40%"
                      @change="handleRegionChange"
                    />
                    <el-input
                      v-model="form.village"
                      placeholder="请输入村/社区"
                      maxlength="50"
                      style="width: 28%; margin-left: 10px"
                    />
                    <el-input
                      v-model="form.hamlet"
                      placeholder="请输入屯/组"
                      maxlength="50"
                      style="width: 28%; margin-left: 10px"
                    />
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
          </el-card>

          <!-- 学籍信息 -->
          <el-card shadow="never" class="form-card" ref="academicSection">
            <div slot="header" class="card-header">
              <i class="el-icon-reading"></i>
              <span>学籍信息</span>
            </div>
            <el-row :gutter="20">
              <el-col :span="8">
                <el-form-item label="所属学制" prop="schoolingPlanId">
                  <el-select v-model="form.schoolingPlanId" placeholder="请选择学制" @change="handleSchoolPlanChange" style="width: 100%">
                    <el-option
                      v-for="item in schoolPlanOptions"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="所属年级" prop="gradeId">
                  <el-select v-model="form.gradeId" placeholder="请选择年级" @change="handleGradeChange" style="width: 100%" :disabled="!form.schoolingPlanId">
                    <el-option
                      v-for="item in gradeOptions"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="所属班级" prop="classId">
                  <el-select v-model="form.classId" placeholder="请选择班级" style="width: 100%" :disabled="!form.gradeId">
                    <el-option
                      v-for="item in classOptions"
                      :key="item.classId"
                      :label="item.className"
                      :value="item.classId"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="24">
                <el-form-item label="就读状态" prop="studyStatus">
                  <el-select v-model="form.studyStatus" placeholder="请选择就读状态" style="width: 100%">
                    <el-option
                      v-for="dict in dict.type.sys_study_status"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </el-card>

          <!-- 困难认定 -->
          <el-card shadow="never" class="form-card" ref="difficultySection">
            <div slot="header" class="card-header">
              <i class="el-icon-warning-outline"></i>
              <span>困难认定</span>
            </div>
            <el-row :gutter="20">
              <el-col :span="12">
              <el-form-item label="困难类型" prop="difficultyTypeId">
                <el-select v-model="form.difficultyTypeId" placeholder="请选择困难类型" style="width: 100%">
                    <el-option
                      v-for="dict in dict.type.sys_difficulty_type"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="困难等级" prop="difficultyLevelId">
                  <el-select v-model="form.difficultyLevelId" placeholder="请选择困难等级" style="width: 100%">
                    <el-option
                      v-for="dict in dict.type.sys_difficulty_level"
                      :key="dict.value"
                      :label="dict.label"
                      :value="dict.value"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="是否脱贫户" prop="isPovertyReliefFamily">
                  <el-switch
                    v-model="form.isPovertyReliefFamily"
                    active-value="1"
                    inactive-value="0"
                    @change="handlePovertyFlagChange"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20" v-if="showPovertyReliefYear">
              <el-col :span="12">
                <el-form-item label="脱贫年份" prop="povertyReliefYear">
                  <el-date-picker
                    v-model="form.povertyReliefYear"
                    type="year"
                    placeholder="请选择脱贫年份"
                    value-format="yyyy"
                    style="width: 100%"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-card>

          <!-- 备注信息 -->
          <el-card shadow="never" class="form-card" ref="memoSection">
            <div slot="header" class="card-header">
              <i class="el-icon-edit-outline"></i>
              <span>备注信息</span>
            </div>
            <el-row :gutter="20">
              <el-col :span="24">
                <el-form-item label="备注" prop="memo">
                  <el-input
                    v-model="form.memo"
                    type="textarea"
                    :rows="3"
                    placeholder="请输入备注信息"
                    maxlength="500"
                    show-word-limit
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-card>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 批量认定困难类型对话框 -->
    <el-dialog title="批量认定困难类型" :visible.sync="batchDifficultyOpen" width="500px" append-to-body>
      <el-form ref="batchDifficultyForm" :model="batchDifficultyForm" label-width="120px">
        <el-alert
          :title="`已选择 ${selectedStudentNames.length} 名学生，将批量更新选中学生的困难认定信息，未填写的字段将保持不变。`"
          type="info"
          show-icon
          :closable="false"
          style="margin-bottom: 15px"
        />
        <div v-if="selectedStudentNames.length > 0" style="margin-bottom: 20px; padding: 10px; background: #f5f7fa; border-radius: 4px;">
          <div style="font-weight: 600; margin-bottom: 8px; color: #303133;">已选择的学生：</div>
          <div style="color: #606266; line-height: 1.8;">
            <span v-for="(name, index) in selectedStudentNames" :key="index" style="display: inline-block; margin-right: 10px;">
              {{ name }}<span v-if="index < selectedStudentNames.length - 1">、</span>
            </span>
          </div>
        </div>
        <el-form-item label="困难类型" prop="difficultyTypeId">
          <el-select v-model="batchDifficultyForm.difficultyTypeId" placeholder="请选择困难类型（留空则不更新）" clearable style="width: 100%">
            <el-option
              v-for="dict in dict.type.sys_difficulty_type"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="困难等级" prop="difficultyLevelId">
          <el-select v-model="batchDifficultyForm.difficultyLevelId" placeholder="请选择困难等级（留空则不更新）" clearable style="width: 100%">
            <el-option
              v-for="dict in dict.type.sys_difficulty_level"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="是否脱贫户" prop="isPovertyReliefFamily">
          <el-select v-model="batchDifficultyForm.isPovertyReliefFamily" placeholder="请选择（留空则不更新）" clearable style="width: 100%">
            <el-option label="是" value="1" />
            <el-option label="否" value="0" />
          </el-select>
        </el-form-item>
        <el-form-item label="脱贫年份" prop="povertyReliefYear" v-if="batchDifficultyForm.isPovertyReliefFamily === '1'">
          <el-date-picker
            v-model="batchDifficultyForm.povertyReliefYear"
            type="year"
            placeholder="请选择脱贫年份"
            value-format="yyyy"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitBatchDifficulty">确 定</el-button>
        <el-button @click="cancelBatchDifficulty">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  listStudents, getStudents, delStudents, addStudents, updateStudents,
  getSchoolPlanList, getGradeList, getClassList, batchUpdateDifficulty
} from "@/api/system/students";
import {
  listStudentRecords, getStudentRecord, delStudentRecords, addStudentRecord, updateStudentRecord,
  listStudentsBase, getStudentsBase, addStudentsBase, updateStudentsBase
} from "@/api/system/studentRecord";
import { listYearSemesters } from "@/api/system/baseconfig";
import guangxiRegions from "@/assets/data/guangxi-region.js";

export default {
  name: "Students",
  dicts: ['sys_student_gender', 'sys_student_ethnicity', 'sys_study_status', 'sys_difficulty_type', 'sys_difficulty_level'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 困难学生基础信息表格数据
      studentsList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 学年学期选项
      yearSemesterOptions: [],
      // 学制选项
      schoolPlanOptions: [],
      // 年级选项
      gradeOptions: [],
      // 所有年级选项（用于查询条件）
      allGradeOptions: [],
      // 班级选项
      classOptions: [],
      // 广西行政区划数据
      guangxiRegions: guangxiRegions,
      // 是否正在编辑地址
      isEditingAddress: false,
      // 是否显示脱贫年份字段
      showPovertyReliefYear: false,
      currentYearSemesterId: null,
      // 批量认定对话框
      batchDifficultyOpen: false,
      selectedStudentNames: [],
      batchDifficultyForm: {
        difficultyTypeId: null,
        difficultyLevelId: null,
        isPovertyReliefFamily: null,
        povertyReliefYear: null
      },
      sectionAnchors: [
        { id: 'semester', label: '学期信息', icon: 'el-icon-date', ref: 'semesterSection' },
        { id: 'basic', label: '基本信息', icon: 'el-icon-user', ref: 'basicSection' },
        { id: 'domicile', label: '户籍信息', icon: 'el-icon-location', ref: 'domicileSection' },
        { id: 'academic', label: '学籍信息', icon: 'el-icon-reading', ref: 'academicSection' },
        { id: 'difficulty', label: '困难认定', icon: 'el-icon-warning-outline', ref: 'difficultySection' },
        { id: 'memo', label: '备注信息', icon: 'el-icon-edit-outline', ref: 'memoSection' }
      ],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        yearSemesterId: null,
        name: null,
        idCardNo: null,
        ethnicity: null,
        gradeId: null,
        difficultyTypeId: null,
        isPovertyReliefFamily: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        yearSemesterId: [
          { required: true, message: "学年学期不能为空", trigger: "change" }
        ],
        name: [
          { required: true, message: "姓名不能为空", trigger: "blur" }
        ],
        idCardNo: [
          { required: true, message: "身份证号不能为空", trigger: "blur" },
          { validator: this.validateIdCardNo, trigger: "blur" }
        ],
        gender: [
          { required: true, message: "性别不能为空", trigger: "blur" }
        ],
        ethnicity: [
          { required: true, message: "民族不能为空", trigger: "change" }
        ],
        domicile: [
          { required: true, message: "户籍所在地不能为空", trigger: "blur" }
        ],
        studentNo: [
          { required: true, message: "学籍号不能为空", trigger: "blur" },
          { validator: this.validateStudentNo, trigger: "blur" }
        ],
        schoolingPlanId: [
          { required: true, message: "所属学制不能为空", trigger: "blur" }
        ],
        gradeId: [
          { required: true, message: "所属年级不能为空", trigger: "blur" }
        ],
        classId: [
          { required: true, message: "所属班级不能为空", trigger: "blur" }
        ],
        studyStatus: [
          { required: true, message: "就读状态不能为空", trigger: "change" }
        ],
        difficultyLevelId: [
          { required: true, message: "困难等级不能为空", trigger: "change" }
        ],
        isPovertyReliefFamily: [
          { required: true, message: "请选择是否脱贫户", trigger: "change" }
        ],
        povertyReliefYear: [
          { validator: this.validatePovertyYear, trigger: "change" }
        ]
      }
    }
  },
  created() {
    this.getList();
    this.getYearSemesterList();
    this.getSchoolPlanList();
    this.getAllGradeList();
  },
  methods: {
    /** 查询学年学期列表 */
    getYearSemesterList() {
      listYearSemesters({ status: 1 }).then(response => {
        this.yearSemesterOptions = response.rows || response.data || [];
        // 默认选中当前学期
        const currentSemester = this.yearSemesterOptions.find(item => item.isCurrent === 1);
        if (currentSemester) {
          this.currentYearSemesterId = currentSemester.id;
          if (!this.queryParams.yearSemesterId) {
            this.queryParams.yearSemesterId = currentSemester.id;
          }
          this.applyCurrentSemesterToForm();
        }
      });
    },
    /** 验证身份证号唯一性 */
    validateIdCardNo(rule, value, callback) {
      if (!value) {
        callback();
        return;
      }

      // 如果是编辑模式，且身份证号没有变化，则不验证
      if (this.form.id) {
        callback();
        return;
      }

      // 检查身份证号是否已存在
      listStudentsBase({ idCardNo: value }).then(response => {
        if (response.rows && response.rows.length > 0) {
          callback(new Error('该身份证号已存在，请检查'));
        } else {
          callback();
        }
      }).catch(() => {
        callback();
      });
    },
    /** 验证学籍号唯一性 */
    validateStudentNo(rule, value, callback) {
      if (!value) {
        callback();
        return;
      }

      // 如果是编辑模式，且学籍号没有变化，则不验证
      if (this.form.id) {
        callback();
        return;
      }

      // 检查学籍号是否已存在
      listStudentsBase({ studentNo: value }).then(response => {
        if (response.rows && response.rows.length > 0) {
          callback(new Error('该学籍号已存在，请检查'));
        } else {
          callback();
        }
      }).catch(() => {
        callback();
      });
    },
    validatePovertyYear(rule, value, callback) {
      if (this.form.isPovertyReliefFamily === '1' && !value) {
        callback(new Error('脱贫年份不能为空'));
      } else {
        callback();
      }
    },
    /** 查询困难学生基础信息列表 */
    getList() {
      this.loading = true
      listStudents(this.queryParams).then(response => {
        this.studentsList = response.rows
        this.total = response.total
        this.loading = false
      })
    },
    // 取消按钮
    cancel() {
      this.open = false
      this.reset()
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        yearSemesterId: this.currentYearSemesterId,
        currentYearSemesterId: this.currentYearSemesterId,
        studentBaseId: null,
        name: null,
        idCardNo: null,
        gender: null,
        ethnicity: null,
        domicile: null,
        regionCodes: [],
        village: null,
        hamlet: null,
        studentNo: null,
        schoolingPlanId: null,
        gradeId: null,
        classId: null,
        studyStatus: null,
        difficultyTypeId: null,
        difficultyLevelId: null,
        isPovertyReliefFamily: '0',
        povertyReliefYear: null,
        memo: null
      }
      this.isEditingAddress = false
      this.showPovertyReliefYear = false
      this.applyCurrentSemesterToForm()
    },
    applyCurrentSemesterToForm() {
      if (!this.form) {
        this.form = {}
      }
      if (this.currentYearSemesterId && !this.form.yearSemesterId) {
        this.$set(this.form, 'yearSemesterId', this.currentYearSemesterId)
      }
      if (this.currentYearSemesterId && !this.form.currentYearSemesterId) {
        this.$set(this.form, 'currentYearSemesterId', this.currentYearSemesterId)
      }
    },
    formatSupportInfo(row) {
      if (!row) {
        return ''
      }
      const parts = []
      if (row.isPovertyReliefFamily === '1') {
        const yearText = row.povertyReliefYear ? `${row.povertyReliefYear}年` : ''
        parts.push(`${yearText}脱贫户`)
      }
      const difficultyLabel = this.selectDictLabel(this.dict.type.sys_difficulty_type, row.difficultyTypeId)
      if (difficultyLabel && difficultyLabel !== '无') {
        parts.push(difficultyLabel)
      }
      return parts.length ? parts.join('、') : ''
    },
    formatGradeAndClass(row) {
      if (!row) {
        return '-'
      }
      const grade = row.gradeName || ''
      const clazz = row.className || ''
      const combined = `${grade}${clazz}`
      return combined || '-'
    },
    formatDifficultyLevel(value) {
      return this.selectDictLabel(this.dict.type.sys_difficulty_level, value) || value || '-'
    },
    scrollToSection(refName) {
      this.$nextTick(() => {
        const scrollWrapper = this.$refs.formScroll
        const target = this.$refs[refName]
        if (!scrollWrapper || !target) {
          return
        }
        const wrapperEl = scrollWrapper instanceof HTMLElement ? scrollWrapper : scrollWrapper.$el
        const targetEl = target.$el || target
        if (!wrapperEl || !targetEl) return
        const offset = targetEl.offsetTop - wrapperEl.offsetTop
        wrapperEl.scrollTo({
          top: offset,
          behavior: 'smooth'
        })
      })
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1
      this.getList()
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm")
      this.handleQuery()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset()
      this.open = true
      this.title = "添加困难学生基础信息"
      // 清空级联选项
      this.gradeOptions = []
      this.classOptions = []
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset()
      const id = row.id || this.ids
      getStudents(id).then(response => {
        this.form = response.data
        const resolvedSemesterId = this.form.currentYearSemesterId || this.form.yearSemesterId || this.currentYearSemesterId
        this.$set(this.form, 'yearSemesterId', resolvedSemesterId)
        this.$set(this.form, 'currentYearSemesterId', resolvedSemesterId || null)
        // 编辑时，默认显示原有地址，不显示级联选择器
        this.isEditingAddress = false
        // 判断是否显示脱贫年份
        this.form.isPovertyReliefFamily = this.form.isPovertyReliefFamily || '0'
        this.showPovertyReliefYear = this.form.isPovertyReliefFamily === '1'
        // 如果有学制ID，加载对应的年级列表
        if (this.form.schoolingPlanId) {
          getGradeList(this.form.schoolingPlanId).then(res => {
            this.gradeOptions = res.data || []
          }).catch(error => {
            console.error('获取年级列表失败:', error)
            this.gradeOptions = []
          })
        }
        // 如果有年级ID，加载对应的班级列表
        if (this.form.gradeId) {
          getClassList(this.form.gradeId).then(res => {
            this.classOptions = res.data || []
          }).catch(error => {
            console.error('获取班级列表失败:', error)
            this.classOptions = []
          })
        }
        this.open = true
        this.title = "修改困难学生基础信息"
      }).catch(error => {
        console.error('获取学生记录失败:', error)
        this.$modal.msgError('获取学生记录失败')
      })
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.form.currentYearSemesterId = this.form.yearSemesterId || null
          // 只有在新增或修改地址时才拼接完整的户籍地址
          if (!this.form.id || this.isEditingAddress) {
            if (this.form.domicile) {
              let fullAddress = this.form.domicile;
              if (this.form.village) {
                fullAddress += this.form.village;
              }
              if (this.form.hamlet) {
                fullAddress += this.form.hamlet;
              }
              this.form.domicile = fullAddress;
            }
          }

          if (this.form.id != null) {
            updateStudents(this.form).then(response => {
              this.$modal.msgSuccess("修改成功")
              this.open = false
              this.getList()
            })
          } else {
            addStudents(this.form).then(response => {
              this.$modal.msgSuccess("新增成功")
              this.open = false
              this.getList()
            })
          }
        }
      })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids
      this.$modal.confirm('是否确认删除困难学生基础信息编号为"' + ids + '"的数据项？').then(function() {
        return delStudents(ids)
      }).then(() => {
        this.getList()
        this.$modal.msgSuccess("删除成功")
      }).catch(() => {})
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/students/export', {
        ...this.queryParams
      }, `students_${new Date().getTime()}.xlsx`)
    },
    /** 获取学制列表 */
    getSchoolPlanList() {
      getSchoolPlanList().then(response => {
        this.schoolPlanOptions = response.data;
      });
    },
    /** 获取所有年级列表（用于查询条件） */
    getAllGradeList() {
      // 调用基础配置的年级接口获取所有年级
      import('@/api/system/baseconfig').then(module => {
        module.listGrades().then(response => {
          this.allGradeOptions = response.data;
        });
      });
    },
    /** 学制改变时触发 */
    handleSchoolPlanChange(value) {
      // 清空年级和班级选择
      this.form.gradeId = null;
      this.form.classId = null;
      this.gradeOptions = [];
      this.classOptions = [];

      // 如果选择了学制，则加载对应的年级列表
      if (value) {
        getGradeList(value).then(response => {
          this.gradeOptions = response.data || [];
        }).catch(error => {
          console.error('获取年级列表失败:', error);
          this.$modal.msgError('获取年级列表失败');
        });
      }
    },
    /** 年级改变时触发 */
    handleGradeChange(value) {
      this.form.classId = null;
      this.classOptions = [];
      if (value) {
        getClassList(value).then(response => {
          this.classOptions = response.data;
        });
      }
    },
    /** 行政区划改变时触发 */
    handleRegionChange(value) {
      // value 是数组，如 ['450100', '450102', '450102001']
      if (value && value.length > 0) {
        // 获取选中的各级名称
        const labels = this.getRegionLabels(value);
        // 拼接完整地址：广西壮族自治区 + 市 + 县 + 乡镇
        const baseAddress = '广西壮族自治区' + labels.join('');
        // 如果有村和屯，会在提交时拼接
        this.form.domicile = baseAddress;
      } else {
        this.form.domicile = null;
      }
    },
    /** 获取区划名称 */
    getRegionLabels(codes) {
      const labels = [];
      let currentLevel = this.guangxiRegions;

      for (let i = 0; i < codes.length; i++) {
        const code = codes[i];
        const item = currentLevel.find(region => region.value === code);
        if (item) {
          labels.push(item.label);
          currentLevel = item.children || [];
        }
      }

      return labels;
    },
    /** 是否脱贫户变化 */
    handlePovertyFlagChange(value) {
      this.showPovertyReliefYear = value === '1'
      if (!this.showPovertyReliefYear) {
        this.form.povertyReliefYear = null
      }
    },
    /** 格式化户籍所在地，隐藏"自治区"等字样 */
    formatDomicile(domicile) {
      if (!domicile) return ''
      // 移除常见的行政区划后缀和民族名称
      return domicile
        .replace(/壮族/g, '')
        .replace(/回族/g, '')
        .replace(/维吾尔/g, '')
        .replace(/自治区/g, '')
        .replace(/省/g, '')
        .replace(/特别行政区/g, '')
    },
    /** 批量认定困难类型 */
    handleBatchDifficulty() {
      if (this.ids.length === 0) {
        this.$modal.msgWarning('请先选择要认定的学生');
        return;
      }
      // 根据选中的ids获取学生名字
      this.selectedStudentNames = this.studentsList
        .filter(student => this.ids.includes(student.id))
        .map(student => student.name)
        .filter(name => name) // 过滤空名字
      this.batchDifficultyForm = {
        difficultyTypeId: null,
        difficultyLevelId: null,
        isPovertyReliefFamily: null,
        povertyReliefYear: null
      }
      this.batchDifficultyOpen = true
    },
    /** 提交批量认定 */
    submitBatchDifficulty() {
      this.$refs["batchDifficultyForm"].validate(valid => {
        if (valid) {
          // 验证脱贫年份
          if (this.batchDifficultyForm.isPovertyReliefFamily === '1' && !this.batchDifficultyForm.povertyReliefYear) {
            this.$modal.msgError('选择脱贫户时必须填写脱贫年份');
            return;
          }

          const params = {
            ids: this.ids,
            difficultyTypeId: this.batchDifficultyForm.difficultyTypeId || null,
            difficultyLevelId: this.batchDifficultyForm.difficultyLevelId || null,
            isPovertyReliefFamily: this.batchDifficultyForm.isPovertyReliefFamily || null,
            povertyReliefYear: this.batchDifficultyForm.povertyReliefYear ? parseInt(this.batchDifficultyForm.povertyReliefYear) : null
          }

          batchUpdateDifficulty(params).then(response => {
            this.$modal.msgSuccess('批量认定成功')
            this.batchDifficultyOpen = false
            this.getList()
          }).catch(() => {
            this.$modal.msgError('批量认定失败')
          })
        }
      })
    },
    /** 取消批量认定 */
    cancelBatchDifficulty() {
      this.batchDifficultyOpen = false
      this.selectedStudentNames = []
      this.batchDifficultyForm = {
        difficultyTypeId: null,
        difficultyLevelId: null,
        isPovertyReliefFamily: null,
        povertyReliefYear: null
      }
    }
  }
}
</script>

<style scoped lang="scss">
// 表单卡片样式
.form-card {
  margin-bottom: 20px;
  border-radius: 8px;
  border: 1px solid #e4e7ed;

  ::v-deep .el-card__header {
    padding: 12px 20px;
    background: #f5f7fa;
    border-bottom: 1px solid #e4e7ed;
  }

  ::v-deep .el-card__body {
    padding: 20px;
  }

  &:last-of-type {
    margin-bottom: 0;
  }
}

.form-tip {
  margin-bottom: 15px;
}

.section-nav {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
  background: #f5f7fa;
  padding: 8px 12px;
  border-radius: 6px;
}

.section-nav .el-button {
  color: #1890ff;
  padding: 0 8px;
  font-size: 13px;
}

.form-scroll {
  max-height: 520px;
  overflow-y: auto;
  padding-right: 8px;
}

.domicile-preview,
.domicile-inputs {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}

.difficulty-pill {
  display: inline-block;
  padding: 0 10px;
  line-height: 22px;
  border: 1px solid #1890ff;
  border-radius: 6px;
  color: #1890ff;
  background: #ecf5ff;
  font-size: 12px;
}

.card-header {
  display: flex;
  align-items: center;
  font-size: 14px;
  font-weight: 600;
  color: #303133;

  i {
    margin-right: 8px;
    font-size: 16px;
    color: #409EFF;
  }
}

// 对话框样式优化
::v-deep .el-dialog__body {
  padding: 20px;
  max-height: 65vh;
  overflow-y: auto;
}

::v-deep .el-dialog__footer {
  padding: 15px 20px;
  text-align: right;
  border-top: 1px solid #e4e7ed;
}

// 表单项间距
::v-deep .el-form-item {
  margin-bottom: 18px;
}

// 响应式设计
@media (max-width: 768px) {
  ::v-deep .el-dialog {
    width: 95% !important;
  }
}
</style>
