<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="学生姓名" prop="studentName">
        <el-input
          v-model="queryParams.studentName"
          placeholder="请输入学生姓名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="身份证号" prop="idCard">
        <el-input
          v-model="queryParams.idCard"
          placeholder="请输入身份证号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="困难类型" prop="difficultyTypeId">
        <el-select v-model="queryParams.difficultyTypeId" placeholder="请选择困难类型" clearable>
          <el-option
            v-for="dict in dict.type.sys_difficulty_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="困难等级" prop="difficultyLevelId">
        <el-select v-model="queryParams.difficultyLevelId" placeholder="请选择困难等级" clearable>
          <el-option
            v-for="dict in dict.type.sys_difficulty_level"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="脱贫户" prop="isPovertyReliefFamily">
        <el-select v-model="queryParams.isPovertyReliefFamily" placeholder="是否脱贫户" clearable>
          <el-option label="是" value="1" />
          <el-option label="否" value="0" />
        </el-select>
      </el-form-item>
      <el-form-item label="学年" prop="academicYear">
        <el-input
          v-model="queryParams.academicYear"
          placeholder="默认为当前学年，可手动输入查询历史"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="学期" prop="semester">
        <el-select v-model="queryParams.semester" placeholder="默认为当前学期" clearable>
          <el-option
            v-for="item in semesterOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8 action-row">
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:aidedStudent:export']"
        >导出</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-refresh"
          size="mini"
          @click="handleSync"
          v-hasPermi="['system:aidedStudent:sync']"
        >同步基础数据</el-button>
      </el-col>
      <el-col :span="5" class="current-semester-tip">
        <el-tag
          :type="currentSemester ? 'info' : 'warning'"
          effect="plain"
          size="small"
          class="semester-tag"
        >
          <span v-if="currentSemester">当前学期：{{ currentSemesterDisplay }}</span>
          <span v-else>当前学期未设置</span>
        </el-tag>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table
      class="aided-table"
      v-loading="loading"
      :data="aidedStudentList"
    >
      <el-table-column label="编号" align="center" prop="id" />
      <el-table-column label="学生姓名" align="center" prop="studentName" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-link type="primary" :underline="false" @click="openStudentDetailDialog(scope.row)">
            {{ scope.row.studentName }}
          </el-link>
        </template>
      </el-table-column>
      <el-table-column label="身份证号" align="center" prop="idCard" show-overflow-tooltip />
      <el-table-column label="性别" align="center" prop="gender">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_student_gender" :value="scope.row.gender"/>
        </template>
      </el-table-column>
      <el-table-column label="民族" align="center" prop="nationName">
        <template slot-scope="scope">
          {{ scope.row.nationName || scope.row.nation || '-' }}
        </template>
      </el-table-column>
      <el-table-column label="年级班级" align="center" width="180">
        <template slot-scope="scope">
          {{ formatGradeAndClass(scope.row) }}
        </template>
      </el-table-column>
      <el-table-column label="困难类型" align="center" prop="difficultyTypeId" class-name="support-column" width="220">
        <template slot-scope="scope">
          <span>{{ formatSupportInfo(scope.row) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="困难等级" align="center" prop="difficultyLevelId" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.difficultyLevelId" class="difficulty-pill">
            {{ formatDifficultyLevel(scope.row.difficultyLevelId) }}
          </span>
          <span v-else>-</span>
        </template>
      </el-table-column>
      <el-table-column label="学年学期" align="center" width="170">
        <template slot-scope="scope">
          {{ formatAcademicYearAndSemester(scope.row) }}
        </template>
      </el-table-column>
      <el-table-column label="资助金额/元" align="center" width="200">
        <template slot-scope="scope">
          <div v-if="scope.row.scholarshipAmount || scope.row.tuitionWaiverAmount" style="line-height: 1.8;">
            <div v-if="scope.row.scholarshipAmount && scope.row.scholarshipAmount > 0" class="subsidy-amount-text">
              助学金：￥{{ formatAmount(scope.row.scholarshipAmount) }}
            </div>
            <div v-if="scope.row.tuitionWaiverAmount && scope.row.tuitionWaiverAmount > 0" class="subsidy-amount-text">
              免学杂费：￥{{ formatAmount(scope.row.tuitionWaiverAmount) }}
            </div>
          </div>
          <span v-else style="color: #909399;">-</span>
        </template>
      </el-table-column>
      <el-table-column label="审批状态" align="center" width="100">
        <template slot-scope="scope">
          <span v-if="scope.row.approvalStatus === 1" style="color: #67c23a; font-weight: 600;">通过</span>
          <dict-tag
            v-else-if="scope.row.approvalStatus != null"
            :options="dict.type.sys_approval_status"
            :value="scope.row.approvalStatus"
          />
          <span v-else style="color: #909399;">-</span>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" align="center" prop="createTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width op-column">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-refresh"
            @click="syncSingleStudent(scope.row.studentId)"
            v-hasPermi="['system:aidedStudent:sync']"
          >同步</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-plus"
            @click="openSubsidyDialog(scope.row)"
            v-hasPermi="['system:subsidy:create']"
          >录入补助</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 录入补助对话框 -->
    <el-dialog
      title="录入补助"
      :visible.sync="subsidyDialogVisible"
      width="600px"
      append-to-body
      @closed="handleSubsidyDialogClosed"
    >
      <el-form
        ref="subsidyFormRef"
        :model="subsidyForm"
        :rules="subsidyFormRules"
        label-width="110px"
      >
        <el-card class="student-info-card" shadow="never">
          <div slot="header" class="student-info-header">
            <i class="el-icon-user"></i>
            <span>学生信息</span>
          </div>
          <el-descriptions :column="2" border size="small">
            <el-descriptions-item label="姓名" :span="1">
              <span class="info-value">{{ (selectedStudent && selectedStudent.studentName) || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="证件号" :span="1">
              <span class="info-value">{{ (selectedStudent && selectedStudent.idCard) || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="年级" :span="1">
              <span class="info-value">{{ (selectedStudent && (selectedStudent.grade || selectedStudent.gradeName)) || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="班级" :span="1">
              <span class="info-value">{{ (selectedStudent && (selectedStudent.clazzName || selectedStudent.className)) || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="困难类型" :span="2">
              <el-tag type="warning" size="small" v-if="formatSupportInfo(selectedStudent)">
                {{ formatSupportInfo(selectedStudent) }}
              </el-tag>
              <span v-else class="info-value">未认定</span>
            </el-descriptions-item>
          </el-descriptions>
        </el-card>
        <el-form-item label="资金来源" prop="budgetSourceType">
          <el-radio-group v-model="subsidyForm.budgetSourceType" @change="handleBudgetSourceChange">
            <el-radio
              v-for="option in budgetSourceOptions"
              :key="option.value"
              :label="option.value"
            >
              {{ option.label }}
            </el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="预算选择" prop="budgetId">
          <el-select
            v-model="subsidyForm.budgetId"
            placeholder="请先选择资金来源，然后选择预算"
            filterable
            style="width: 100%"
            :loading="subsidyDialogLoading"
            popper-class="budget-select-dropdown"
            @change="handleBudgetChange"
          >
            <el-option
              v-for="item in displayBudgets"
              :key="item.id"
              :label="getBudgetOptionLabel(item)"
              :value="item.id"
              :disabled="item.status != null && parseInt(item.status) !== 1"
            >
              <div style="line-height: 1.6;">
                <div style="font-weight: 500; color: #303133; display: flex; align-items: center;">
                  <span>{{ item.budgetProjectName || item.budgetType || '未命名预算' }}</span>
                  <span
                    :style="{
                      marginLeft: '8px',
                      padding: '2px 6px',
                      borderRadius: '2px',
                      fontSize: '11px',
                      fontWeight: '600',
                      backgroundColor: getBudgetSourceTypeColor(item),
                      color: '#fff'
                    }"
                  >
                    {{ getBudgetSourceTypeLabel(item) }}
                  </span>
                  <span
                    v-if="item.status != null && parseInt(item.status) !== 1"
                    :style="{
                      marginLeft: '8px',
                      padding: '2px 6px',
                      borderRadius: '2px',
                      fontSize: '11px',
                      fontWeight: '600',
                      backgroundColor: parseInt(item.status) === 2 ? '#E6A23C' : '#F56C6C',
                      color: '#fff'
                    }"
                  >
                    {{ getBudgetStatusLabel(item.status) }}
                  </span>
                </div>
                <div style="font-size: 12px; color: #606266; margin-top: 4px;">
                  <span v-if="item.quotaDocNo">指标：{{ item.quotaDocNo }}</span>
                  <span v-if="item.quotaSourceType" style="margin-left: 8px;">
                    （{{ getQuotaSourceTypeLabel(item.quotaSourceType) }}）
                  </span>
                </div>
                <div style="font-size: 12px; color: #909399; margin-top: 2px;">
                  {{ getEconomyCategoryLabel(item.economyCategory) }} |
                  {{ getFunctionCategoryLabel(item.functionCategory) }} |
                  可用余额：<span style="color: #67c23a; font-weight: 600;">￥{{ formatAmount(item.availableAmount) }}</span>
                </div>
                <div style="font-size: 12px; color: #909399; margin-top: 2px;">
                  学年学期：{{ item.schoolYear || '' }} {{ getSemesterLabel(item.semester) }}
                </div>
                <div v-if="item.status != null && parseInt(item.status) !== 1" style="font-size: 12px; color: #F56C6C; margin-top: 4px; font-weight: 600;">
                  {{ getBudgetStatusMessage(parseInt(item.status)) }}
                </div>
              </div>
            </el-option>
          </el-select>
          <div class="form-tip" v-if="displayBudgets.length === 0 && subsidyForm.budgetSourceType">
            <i class="el-icon-warning"></i>
            暂无可用的预算，请检查：1.是否有匹配的预算（功能分类：{{ getFunctionCategoryLabel(getFunctionCategoryBySchoolingPlan()) }}）2.预算是否有可用余额
          </div>
        </el-form-item>
        <el-form-item label="补助套餐" prop="packageId">
          <el-select
            v-model="subsidyForm.packageId"
            :placeholder="selectedBudget ? '请选择补助套餐' : '请先选择预算'"
            filterable
            style="width: 100%"
            :disabled="!selectedBudget"
            @change="handlePackageChange"
          >
            <el-option
              v-for="item in filteredSubsidyPackages"
              :key="item.id"
              :label="`${item.packageName}（￥${formatAmount(item.subsidyAmount || 0)}/学期）`"
              :value="item.id"
            />
          </el-select>
          <div class="form-tip" v-if="selectedBudget && filteredSubsidyPackages.length === 0">
            <i class="el-icon-warning"></i>
            暂无可用的补助套餐，请检查：1.是否有匹配的套餐（经济分类：{{ getEconomyCategoryLabel(selectedBudget.economyCategory) }}，学制：{{ getSchoolingPlanLabel() }}）2.套餐是否已启用
          </div>
        </el-form-item>
        <el-form-item label="补助金额">
          <div style="line-height: 32px; font-size: 16px;">
            <span v-if="currentPackage" class="subsidy-amount-display">
              {{ formatAmount(currentPackage.subsidyAmount || 0) }}元
            </span>
            <span v-else style="color: #909399;">请先选择补助套餐</span>
          </div>
        </el-form-item>
        <el-form-item label="备注">
          <el-input
            type="textarea"
            v-model="subsidyForm.memo"
            placeholder="请输入备注"
            :rows="3"
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitSubsidy" :loading="subsidySubmitting">确 定</el-button>
        <el-button @click="subsidyDialogVisible = false">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 学生详情对话框 -->
    <el-dialog
      title="学生详情"
      :visible.sync="studentDetailDialogVisible"
      width="800px"
      append-to-body
      @closed="handleStudentDetailDialogClosed"
    >
      <div v-if="selectedStudentDetail" class="student-detail-content">
        <!-- 学生基本信息 -->
        <el-card class="detail-card" shadow="never">
          <div slot="header" class="card-header">
            <i class="el-icon-user"></i>
            <span>基本信息</span>
          </div>
          <el-descriptions :column="2" border size="small">
            <el-descriptions-item label="姓名" :span="1">
              <span class="info-value">{{ selectedStudentDetail.studentName || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="年级" :span="1">
              <span class="info-value">{{ selectedStudentDetail.grade || selectedStudentDetail.gradeName || '-' }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="困难类型" :span="2">
              <el-tag type="warning" size="small" v-if="formatSupportInfo(selectedStudentDetail)">
                {{ formatSupportInfo(selectedStudentDetail) }}
              </el-tag>
              <span v-else class="info-value">未认定</span>
            </el-descriptions-item>
          </el-descriptions>
        </el-card>

        <!-- 受助记录 -->
        <el-card class="detail-card" shadow="never" style="margin-top: 20px;">
          <div slot="header" class="card-header">
            <i class="el-icon-document"></i>
            <span>受助记录（已审核通过）</span>
          </div>
          <el-table
            v-loading="subsidyRecordsLoading"
            :data="subsidyRecords"
            border
            size="small"
            style="width: 100%"
          >
            <el-table-column label="序号" type="index" width="60" align="center" />
            <el-table-column label="学年/学期" align="center" width="150">
              <template slot-scope="scope">
                {{ formatAcademicYearAndSemester(scope.row) }}
              </template>
            </el-table-column>
            <el-table-column label="补助类型" align="center" prop="subsidyType" width="120" />
            <el-table-column label="补助金额" align="center" width="120">
              <template slot-scope="scope">
                <span class="subsidy-amount-text">
                  ￥{{ formatAmount(scope.row.subsidyAmount) }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="经济分类" align="center" width="120">
              <template slot-scope="scope">
                {{ getEconomyCategoryLabel(scope.row.economyCategory) }}
              </template>
            </el-table-column>
            <el-table-column label="审批时间" align="center" width="180">
              <template slot-scope="scope">
                {{ parseTime(scope.row.approvalDate, '{y}-{m}-{d} {h}:{i}:{s}') || '-' }}
              </template>
            </el-table-column>
            <el-table-column label="发放状态" align="center" width="100">
              <template slot-scope="scope">
                <dict-tag
                  :options="dict.type.sys_payment_status"
                  :value="scope.row.paymentStatus"
                />
              </template>
            </el-table-column>
            <el-table-column label="备注" align="center" prop="memo" show-overflow-tooltip />
          </el-table>
          <div v-if="!subsidyRecordsLoading && subsidyRecords.length === 0" class="empty-tip">
            <i class="el-icon-info"></i>
            <span>暂无已审核通过的受助记录</span>
          </div>
        </el-card>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="studentDetailDialogVisible = false">关 闭</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { listAidedStudentInfo, syncStudentToAidedTable, syncAllStudentsToAidedTable } from "@/api/system/aidedStudentInfo";
import { getCurrentYearSemester } from "@/api/system/yearSemester";
import { getSubsidyPackages, getAvailableBudgets, getHistoricalBudgets, createSubsidy } from "@/api/system/subsidy";
import { getStudents } from "@/api/system/students";
import { listSubsidyRecord } from "@/api/system/subsidyRecord";

export default {
  name: "AidedStudent",
  dicts: ['sys_student_gender', 'sys_difficulty_type', 'sys_difficulty_level', 'sys_quota_source_type', 'sys_economy_category', 'sys_function_category', 'sys_approval_status', 'sys_payment_status', 'sys_budget_status'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 受助学生信息表格数据
      aidedStudentList: [],
      // 当前学期信息
      currentSemester: null,
      semesterOptions: [
        { value: '1', label: '第一学期' },
        { value: '2', label: '第二学期' }
      ],
      // 补助录入
      subsidyDialogVisible: false,
      subsidyDialogLoading: false,
      subsidySubmitting: false,
      selectedStudent: null,
      subsidyPackages: [], // 所有套餐（根据学制加载）
      filteredSubsidyPackages: [], // 过滤后的套餐（根据预算经济分类过滤）
      currentPackage: null,
      selectedBudget: null, // 当前选中的预算
      availableBudgets: [],
      historicalBudgets: [],
      budgetSourceOptions: [
        { label: '当前学期预算', value: 'CURRENT' },
        { label: '历史结余', value: 'HISTORY' }
      ],
      subsidyForm: {
        studentSemesterRecordIds: [], // 向后兼容旧版本
        studentInfos: [], // 新版本：学生信息列表
        packageId: null,
        budgetSourceType: 'CURRENT',
        budgetId: null,
        sourceSemesterId: null,
        memo: ''
      },
      subsidyFormRules: {
        packageId: [{ required: true, message: '请选择补助套餐', trigger: 'change' }],
        budgetSourceType: [{ required: true, message: '请选择资金来源', trigger: 'change' }],
        budgetId: [{ required: true, message: '请选择预算', trigger: 'change' }]
      },
      studentPlanCache: {},
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        studentName: null,
        idCard: null,
        difficultyTypeId: null,
        difficultyLevelId: null,
        isPovertyReliefFamily: null,
        academicYear: null,
        semester: null
      },
      // 学生详情对话框
      studentDetailDialogVisible: false,
      selectedStudentDetail: null,
      subsidyRecords: [],
      subsidyRecordsLoading: false
    };
  },
  computed: {
    currentSemesterDisplay() {
      if (!this.currentSemester) {
        return '未设置';
      }
      const year = this.currentSemester.schoolYear || '';
      const semesterLabel = this.getSemesterLabel(this.currentSemester.semester);
      return `${year} ${semesterLabel}`.trim();
    },
    displayBudgets() {
      if (this.subsidyForm.budgetSourceType === 'HISTORY') {
        // 历史结余：包括两部分
        // 1. 历史学期的结余预算（year_semester_id < 当前学期ID）
        // 2. 当前学期中，从历史学期结转过来的预算（year_semester_id = 当前学期ID 且 quota_source_type = 2）
        const carryOverBudgets = this.availableBudgets.filter(budget => {
          return budget.quotaSourceType === 2; // 上学期结转的预算
        });
        // 合并历史学期预算和结转预算
        return [...this.historicalBudgets, ...carryOverBudgets];
      } else {
        // 当前学期预算：只显示本学期新下达的预算（quota_source_type = 1），排除上学期结转的预算（quota_source_type = 2）
        return this.availableBudgets.filter(budget => {
          // 只显示指标来源为"本学期新下达"的预算（quota_source_type = 1）
          // 排除"上学期结转"的预算（quotaSourceType = 2）
          // 如果 quotaSourceType 为空或为 1，则显示
          return !budget.quotaSourceType || budget.quotaSourceType === 1;
        });
      }
    }
  },
  created() {
    this.initializePage();
  },
  methods: {
    /** 初始化页面，拉取当前学期并查询受助数据 */
    initializePage() {
      this.loadCurrentSemester().then(() => {
        this.getList();
      });
    },
    /** 加载当前学年学期 */
    loadCurrentSemester() {
      return getCurrentYearSemester()
        .then(response => {
          const data = response.data;
          if (data) {
            this.currentSemester = data;
            this.applyCurrentSemesterToFilters(true);
          } else {
            this.currentSemester = null;
            this.$modal.msgWarning("尚未设置当前学年学期，请先在学年学期管理中设置。");
          }
        })
        .catch(() => {
          this.currentSemester = null;
          this.$modal.msgError("获取当前学年学期失败，请稍后重试。");
        });
    },
    /** 将当前学期默认写入查询条件 */
    applyCurrentSemesterToFilters(force = false) {
      if (!this.currentSemester) {
        return;
      }
      if (force || !this.queryParams.academicYear) {
        this.queryParams.academicYear = this.currentSemester.schoolYear || null;
      }
      if (force || !this.queryParams.semester) {
        this.queryParams.semester = this.currentSemester.semester != null ? String(this.currentSemester.semester) : null;
      }
    },
    /** 确认当前学期是否可用 */
    ensureCurrentSemesterReady() {
      if (!this.currentSemester || !this.currentSemester.schoolYear || this.currentSemester.semester == null) {
        this.$modal.msgWarning("请先在学年学期管理中设置当前学年学期");
        return false;
      }
      return true;
    },
    /** 获取同步操作需要的学年学期参数 */
    getSyncParams() {
      if (!this.ensureCurrentSemesterReady()) {
        return null;
      }
      return {
        academicYear: this.currentSemester.schoolYear,
        semester: String(this.currentSemester.semester)
      };
    },
    /** 查询受助学生信息列表 */
    getList() {
      if (!this.queryParams.academicYear || !this.queryParams.semester) {
        this.applyCurrentSemesterToFilters();
      }
      if (!this.queryParams.academicYear || !this.queryParams.semester) {
        this.loading = false;
        return;
      }
      this.loading = true;
      listAidedStudentInfo(this.queryParams).then(response => {
        this.aidedStudentList = response.rows;
        this.total = response.total;
      }).finally(() => {
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.applyCurrentSemesterToFilters(true);
      this.handleQuery();
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/aidedStudentInfo/export', {
        ...this.queryParams
      }, `aidedStudentInfo_${new Date().getTime()}.xlsx`)
    },
    /** 同步学生数据 */
    handleSync() {
      const params = this.getSyncParams();
      if (!params) {
        return;
      }
      this.$modal.confirm('是否确认同步所有学生数据？').then(() => {
        return syncAllStudentsToAidedTable(params.academicYear, params.semester);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("同步成功");
      }).catch(() => {
        this.$modal.msgError("同步失败");
      });
    },
    /** 同步单个学生数据 */
    syncSingleStudent(studentId) {
      const params = this.getSyncParams();
      if (!params) {
        return;
      }
      syncStudentToAidedTable(studentId, params.academicYear, params.semester).then(() => {
        this.$modal.msgSuccess("同步成功");
        this.getList();
      }).catch(error => {
        console.error(error);
        this.$modal.msgError("同步失败");
      });
    },
    /** 学期文本转换 */
    getSemesterLabel(value) {
      if (value === '第二学期' || value === 2 || value === '2') {
        return '第二学期';
      }
      if (value === '第一学期' || value === 1 || value === '1') {
        return '第一学期';
      }
      return value || '';
    },
    formatSupportInfo(row) {
      if (!row) {
        return '';
      }
      const parts = [];
      if (row.isPovertyReliefFamily === '1') {
        const yearText = row.povertyReliefYear ? `${row.povertyReliefYear}年` : '';
        parts.push(`${yearText}脱贫户`);
      }
      const difficultyLabel = this.selectDictLabel(this.dict.type.sys_difficulty_type, row.difficultyTypeId);
      if (difficultyLabel && difficultyLabel !== '无') {
        parts.push(difficultyLabel);
      }
      return parts.length ? parts.join('、') : '';
    },
    formatGradeAndClass(row) {
      if (!row) {
        return '-';
      }
      const grade = row.grade || '';
      const clazz = row.clazzName || '';
      const combined = `${grade}${clazz}`;
      return combined || '-';
    },
    formatAcademicYearAndSemester(row) {
      if (!row) {
        return '-';
      }
      const year = row.academicYear || '';
      const semester = this.getSemesterLabel(row.semester) || '';
      const combined = `${year}${semester ? ` ${semester}` : ''}`.trim();
      return combined || '-';
    },
    formatDifficultyLevel(value) {
      return this.selectDictLabel(this.dict.type.sys_difficulty_level, value) || value || '-';
    },
    /** 获取学期记录ID */
    resolveSemesterRecordId(row) {
      const info = row || {};
      return info.studentSemesterRecordId
        || info.semesterRecordId
        || info.studentSemesterId
        || info.studentRecordId
        || info.id;
    },
    /** 解析学生学制 */
    async resolveSchoolingPlanId(row) {
      const info = row || {};
      const directPlanId = info.schoolingPlanId
        || (info.schoolingPlan && info.schoolingPlan.id)
        || info.planId;
      if (directPlanId) {
        return directPlanId;
      }
      if (!info.studentId) {
        return null;
      }
      if (this.studentPlanCache[info.studentId]) {
        return this.studentPlanCache[info.studentId];
      }
      try {
        const res = await getStudents(info.studentId);
        const data = res && res.data ? res.data : {};
        const fetchedPlanId = data.schoolingPlanId
          || (data.schoolingPlan && data.schoolingPlan.id)
          || data.planId;
        if (fetchedPlanId) {
          this.$set(this.studentPlanCache, info.studentId, fetchedPlanId);
        }
        return fetchedPlanId || null;
      } catch (error) {
        console.error('resolveSchoolingPlanId error:', error);
        this.$modal.msgError("获取学生学制信息失败，请稍后再试");
        return null;
      }
    },
    /** 打开补助录入弹窗 */
    async openSubsidyDialog(row) {
      // 使用新版本：传递学生信息而不是学期记录ID
      if (!row.studentId || !row.academicYear || !row.semester) {
        this.$modal.msgWarning("当前数据缺少学生信息（studentId、academicYear、semester），无法录入补助");
        return;
      }
      if (!this.ensureCurrentSemesterReady()) {
        return;
      }
      const schoolingPlanId = await this.resolveSchoolingPlanId(row);
      if (!schoolingPlanId) {
        this.$modal.msgWarning("缺少学制信息，无法匹配补助套餐");
        return;
      }
      row.schoolingPlanId = schoolingPlanId;
      this.selectedStudent = row;
      this.resetSubsidyForm(false);
      // 使用新版本：传递学生信息
      this.subsidyForm.studentInfos = [{
        studentId: row.studentId,
        academicYear: row.academicYear,
        semester: row.semester
      }];
      this.subsidyForm.sourceSemesterId = (this.currentSemester && this.currentSemester.id) || null;
      this.subsidyDialogVisible = true;
      // 先加载所有套餐（根据学制），但不显示，等选择预算后再过滤
      this.fetchSubsidyPackages(schoolingPlanId);
      // 加载预算列表
      this.loadBudgets();
    },
    /** 重置补助表单 */
    resetSubsidyForm(clearSelection = true) {
      if (this.$refs.subsidyFormRef) {
        this.$refs.subsidyFormRef.resetFields();
      }
      this.subsidyForm = {
        studentSemesterRecordIds: [], // 向后兼容旧版本
        studentInfos: [], // 新版本：学生信息列表
        packageId: null,
        budgetSourceType: 'CURRENT',
        budgetId: null,
        sourceSemesterId: (this.currentSemester && this.currentSemester.id) || null,
        memo: ''
      };
      this.subsidyPackages = [];
      this.filteredSubsidyPackages = [];
      this.availableBudgets = [];
      this.historicalBudgets = [];
      this.currentPackage = null;
      this.selectedBudget = null;
      this.subsidyDialogLoading = false;
      this.subsidySubmitting = false;
      if (clearSelection) {
        this.selectedStudent = null;
      }
    },
    handleSubsidyDialogClosed() {
      this.resetSubsidyForm(true);
    },
    /** 获取补助套餐（根据学制加载所有套餐） */
    fetchSubsidyPackages(schoolingPlanId) {
      this.subsidyDialogLoading = true;
      getSubsidyPackages({ schoolingPlanId })
        .then(res => {
          this.subsidyPackages = res.data || [];
          if (!this.subsidyPackages.length) {
            this.$modal.msgWarning("该学制暂无可用补助套餐，请先在后台配置。");
          }
          // 不自动选择套餐，等选择预算后再过滤显示
          this.filterSubsidyPackagesByBudget();
        })
        .finally(() => {
          this.subsidyDialogLoading = false;
        });
    },
    /** 根据预算的经济分类过滤补助套餐 */
    filterSubsidyPackagesByBudget() {
      if (!this.selectedBudget || !this.selectedBudget.economyCategory) {
        // 如果没有选择预算，清空过滤后的套餐列表
        this.filteredSubsidyPackages = [];
        this.currentPackage = null;
        this.subsidyForm.packageId = null;
        return;
      }

      // 获取预算的经济分类（可能是字典值或标签）
      const budgetEconomyCategory = this.selectedBudget.economyCategory;

      // 将预算的经济分类转换为字典值（如果它是标签的话）
      let budgetEconomyCategoryValue = budgetEconomyCategory;
      if (budgetEconomyCategory && isNaN(Number(budgetEconomyCategory))) {
        // 是标签，需要查找对应的字典值
        const dict = this.dict.type.sys_economy_category || [];
        const found = dict.find(d => d.label === budgetEconomyCategory);
        if (found) {
          budgetEconomyCategoryValue = found.value;
        }
      }

      // 过滤套餐：匹配经济分类
      this.filteredSubsidyPackages = this.subsidyPackages.filter(pkg => {
        // 获取套餐的经济分类（可能是字典值或标签）
        let pkgEconomyCategory = pkg.economyCategory;

        // 如果套餐的经济分类是标签，转换为字典值
        if (pkgEconomyCategory && isNaN(Number(pkgEconomyCategory))) {
          const dict = this.dict.type.sys_economy_category || [];
          const found = dict.find(d => d.label === pkgEconomyCategory);
          if (found) {
            pkgEconomyCategory = found.value;
          }
        }

        // 比较经济分类（都转换为字典值后比较）
        return String(pkgEconomyCategory) === String(budgetEconomyCategoryValue);
      });

      // 如果过滤后只有一个套餐，自动选择
      if (this.filteredSubsidyPackages.length === 1) {
        this.currentPackage = this.filteredSubsidyPackages[0];
        this.subsidyForm.packageId = this.currentPackage.id;
      } else {
        // 清空已选择的套餐
        this.currentPackage = null;
        this.subsidyForm.packageId = null;
      }
    },
    handlePackageChange(value) {
      this.currentPackage = this.filteredSubsidyPackages.find(item => item.id === value) || null;
    },
    handleBudgetSourceChange() {
      this.subsidyForm.budgetId = null;
      this.selectedBudget = null;
      // 清空套餐选择
      this.currentPackage = null;
      this.subsidyForm.packageId = null;
      this.filteredSubsidyPackages = [];
      // 切换资金来源时，重新加载预算
      this.loadBudgets();
    },
    handleBudgetChange(value) {
      if (!value) {
        this.subsidyForm.sourceSemesterId = this.subsidyForm.budgetSourceType === 'CURRENT'
          ? ((this.currentSemester && this.currentSemester.id) || null)
          : null;
        this.selectedBudget = null;
        // 清空套餐选择
        this.currentPackage = null;
        this.subsidyForm.packageId = null;
        this.filterSubsidyPackagesByBudget();
        return;
      }
      const budget = this.displayBudgets.find(item => item.id === value);
      if (budget) {
        // 验证预算状态，只有启用状态（status=1）可以选择
        // 使用 parseInt 确保类型一致，并处理 undefined/null 的情况
        const budgetStatus = budget.status != null ? parseInt(budget.status) : null;
        if (budgetStatus !== 1) {
          this.$modal.msgError(this.getBudgetStatusMessage(budgetStatus));
          // 清空选择
          this.$nextTick(() => {
            this.subsidyForm.budgetId = null;
          });
          return;
        }
        this.subsidyForm.sourceSemesterId = budget.yearSemesterId;
        this.selectedBudget = budget;
        // 根据预算的经济分类过滤套餐
        this.filterSubsidyPackagesByBudget();
      }
    },
    /** 获取预算状态标签 */
    getBudgetStatusLabel(status) {
      if (!this.dict.type.sys_budget_status) return ''
      const dict = this.dict.type.sys_budget_status.find(item => parseInt(item.value) === status)
      return dict ? dict.label : ''
    },
    /** 获取预算状态提示信息 */
    getBudgetStatusMessage(status) {
      if (status === 2) {
        return '该指标已被冻结！'
      } else if (status === 3) {
        return '该指标已无可用资金！'
      }
      return '该指标状态异常，无法选择！'
    },
    loadBudgets() {
      if (!this.ensureCurrentSemesterReady()) {
        return;
      }

      // 获取学生学制对应的功能分类
      const functionCategory = this.getFunctionCategoryBySchoolingPlan();

      if (!functionCategory) {
        this.$modal.msgError('无法确定学生的功能分类，请检查学生学制信息是否正确');
        this.subsidyDialogLoading = false;
        return;
      }

      // 不再根据套餐的经济分类过滤预算，而是查询所有匹配功能分类的预算
      // 用户选择预算后，再根据预算的经济分类过滤套餐
      const params = {
        currentSemesterId: this.currentSemester.id,
        functionCategory: functionCategory
        // 不传递经济分类参数，查询所有经济分类的预算
      };

      this.subsidyDialogLoading = true;
      Promise.all([
        getAvailableBudgets(params),
        getHistoricalBudgets(params)
      ]).then(([availableRes, historyRes]) => {
        this.availableBudgets = (availableRes && availableRes.data) ? availableRes.data : [];
        this.historicalBudgets = (historyRes && historyRes.data) ? historyRes.data : [];

        // 统计当前学期新下达的预算数量（用于显示）
        const currentSemesterNewBudgets = this.availableBudgets.filter(b => !b.quotaSourceType || b.quotaSourceType === 1);
        const currentSemesterCarryOverBudgets = this.availableBudgets.filter(b => b.quotaSourceType === 2);

        // 根据当前选择的资金来源类型，检查是否有可用预算
        const displayBudgetsCount = this.subsidyForm.budgetSourceType === 'HISTORY'
          ? (this.historicalBudgets.length + currentSemesterCarryOverBudgets.length)
          : currentSemesterNewBudgets.length;

        if (displayBudgetsCount === 0) {
          const sourceTypeLabel = this.subsidyForm.budgetSourceType === 'HISTORY' ? '历史结余' : '当前学期预算';
          this.$modal.msgWarning(`暂未查询到可用的${sourceTypeLabel}，请检查：1.是否有匹配的预算（功能分类：${this.getFunctionCategoryLabel(functionCategory)}）2.预算是否有可用余额`);
        }
      }).catch(error => {
        console.error('加载预算失败:', error);
        this.$modal.msgError('加载预算失败，请稍后再试');
      }).finally(() => {
        this.subsidyDialogLoading = false;
      });
    },
    // 根据学制ID获取功能分类
    getFunctionCategoryBySchoolingPlan() {
      if (!this.selectedStudent || !this.selectedStudent.schoolingPlanId) {
        console.warn('getFunctionCategoryBySchoolingPlan: selectedStudent 或 schoolingPlanId 为空', {
          selectedStudent: this.selectedStudent,
          schoolingPlanId: this.selectedStudent ? this.selectedStudent.schoolingPlanId : null
        });
        return null;
      }
      // 学制ID映射到功能分类：1=小学(1), 2=初中(2), 3=高中(3)
      // 支持数字和字符串类型
      const planId = this.selectedStudent.schoolingPlanId;
      const planIdNum = Number(planId);
      const planIdStr = String(planId).trim();

      console.log('getFunctionCategoryBySchoolingPlan: planId =', planId, 'planIdNum =', planIdNum, 'planIdStr =', planIdStr);

      // 支持多种格式：数字 1,2,3 或字符串 '1','2','3'
      if (planIdNum === 1 || planIdStr === '1') {
        console.log('匹配到功能分类: 1 (小学教育)');
        return '1';
      }
      if (planIdNum === 2 || planIdStr === '2') {
        console.log('匹配到功能分类: 2 (初中教育)');
        return '2';
      }
      if (planIdNum === 3 || planIdStr === '3') {
        console.log('匹配到功能分类: 3 (高中教育)');
        return '3';
      }

      console.warn('getFunctionCategoryBySchoolingPlan: 未匹配到功能分类，planId =', planId, 'planIdNum =', planIdNum);
      return null;
    },
    // 获取经济分类标签
    getEconomyCategoryLabel(value) {
      if (!value) return '-';
      const dict = this.dict.type.sys_economy_category || [];
      const found = dict.find(d => String(d.value) === String(value));
      return found ? found.label : value;
    },
    // 获取功能分类标签
    getFunctionCategoryLabel(value) {
      if (!value) return '-';
      const dict = this.dict.type.sys_function_category || [];
      const found = dict.find(d => String(d.value) === String(value));
      return found ? found.label : value;
    },
    // 获取指标来源类型标签
    getQuotaSourceTypeLabel(value) {
      if (!value) return '-';
      const dict = this.dict.type.sys_quota_source_type || [];
      const found = dict.find(d => String(d.value) === String(value));
      return found ? found.label : '未知';
    },
    // 获取学制标签（用于提示信息）
    getSchoolingPlanLabel() {
      if (!this.selectedStudent || !this.selectedStudent.schoolingPlanId) {
        return '-';
      }
      const planId = Number(this.selectedStudent.schoolingPlanId);
      if (planId === 1) return '小学';
      if (planId === 2) return '初中';
      if (planId === 3) return '高中';
      return '-';
    },
    // 格式化金额
    formatAmount(val) {
      const num = Number(val || 0);
      return num.toFixed(2);
    },
    getBudgetOptionLabel(item) {
      // 简化显示，详细信息在 option 的 slot 中显示
      const title = item.budgetProjectName || item.budgetType || '未命名预算';
      const amount = this.formatAmount(item.availableAmount);
      const sourceType = item.quotaSourceType ? `（${this.getQuotaSourceTypeLabel(item.quotaSourceType)}）` : '';
      const budgetSourceLabel = this.getBudgetSourceTypeLabel(item);
      return `${title}${sourceType} [${budgetSourceLabel}] - 可用￥${amount}`;
    },
    // 获取预算来源类型标签（当前学期预算/历史结余）
    getBudgetSourceTypeLabel(item) {
      if (!item || !item.yearSemesterId || !this.currentSemester) {
        return '未知';
      }
      // 如果预算的学期ID等于当前学期ID，则是当前学期预算
      if (item.yearSemesterId === this.currentSemester.id) {
        return '当前学期';
      }
      // 否则是历史结余
      return '历史结余';
    },
    // 获取预算来源类型颜色
    getBudgetSourceTypeColor(item) {
      if (!item || !item.yearSemesterId || !this.currentSemester) {
        return '#909399';
      }
      // 当前学期预算用蓝色，历史结余用橙色
      if (item.yearSemesterId === this.currentSemester.id) {
        return '#409EFF';
      }
      return '#E6A23C';
    },
    submitSubsidy() {
      if (!this.$refs.subsidyFormRef) {
        return;
      }
      this.$refs.subsidyFormRef.validate(valid => {
        if (!valid) {
          return;
        }

        // 验证预算可用余额
        if (this.selectedBudget && this.currentPackage) {
          const subsidyAmount = this.currentPackage.subsidyAmount || 0;
          const availableAmount = Number(this.selectedBudget.availableAmount || 0);
          if (subsidyAmount > availableAmount) {
            this.$modal.msgError(`预算可用余额不足！可用余额：￥${this.formatAmount(availableAmount)}，补助金额：￥${this.formatAmount(subsidyAmount)}`);
            return;
          }
        }

        // 验证学生信息（新版本）或学期记录ID（旧版本）
        if ((!this.subsidyForm.studentInfos || this.subsidyForm.studentInfos.length === 0)
            && (!this.subsidyForm.studentSemesterRecordIds || this.subsidyForm.studentSemesterRecordIds.length === 0)) {
          this.$modal.msgWarning("缺少学生信息或学生学期记录，无法提交。");
          return;
        }
        const payload = { ...this.subsidyForm };
        if (payload.budgetSourceType === 'CURRENT') {
          payload.sourceSemesterId = (this.currentSemester && this.currentSemester.id) || payload.sourceSemesterId;
        }
        if (!payload.sourceSemesterId) {
          this.$modal.msgWarning("无法确定资金来源学期，请重新选择预算。");
          return;
        }
        this.subsidySubmitting = true;
        createSubsidy(payload)
          .then(() => {
            this.$modal.msgSuccess("补助录入成功，已进入待审批。");
            this.subsidyDialogVisible = false;
            this.getList();
          })
          .finally(() => {
            this.subsidySubmitting = false;
          });
      });
    },
    /** 打开学生详情对话框 */
    openStudentDetailDialog(row) {
      this.selectedStudentDetail = { ...row };
      this.studentDetailDialogVisible = true;
      this.loadStudentSubsidyRecords(row);
    },
    /** 加载学生的受助记录（已审核通过） */
    loadStudentSubsidyRecords(row) {
      if (!row || !row.studentName) {
        this.subsidyRecords = [];
        return;
      }
      this.subsidyRecordsLoading = true;
      // 查询该学生的所有已审核通过的受助记录
      listSubsidyRecord({
        studentName: row.studentName,
        approvalStatus: 1 // 只查询已审核通过的记录
      })
        .then(response => {
          this.subsidyRecords = response.rows || [];
        })
        .catch(error => {
          console.error('加载受助记录失败:', error);
          this.$modal.msgError('加载受助记录失败，请稍后再试');
          this.subsidyRecords = [];
        })
        .finally(() => {
          this.subsidyRecordsLoading = false;
        });
    },
    /** 关闭学生详情对话框 */
    handleStudentDetailDialogClosed() {
      this.selectedStudentDetail = null;
      this.subsidyRecords = [];
    }
  }
};
</script>

<style scoped>
.current-semester-tip {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: #606266;
  margin-top: 3px;
}

.semester-tag {
  border-color: #1890ff;
  color: #1890ff;
}

.action-row {
  align-items: center;
}

.aided-table ::v-deep .cell {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.aided-table ::v-deep .support-column .cell {
  overflow: visible;
  text-overflow: clip;
}

.difficulty-pill {
  display: inline-block;
  padding: 0 10px;
  line-height: 22px;
  border: 1px solid #1890ff;
  border-radius: 6px;
  color: #1890ff;
  background: #ecf5ff;
  font-size: 12px;
}

.aided-table ::v-deep .op-column .cell {
  white-space: nowrap;
  overflow: visible;
  text-overflow: clip;
}

.student-summary {
  font-size: 13px;
  line-height: 22px;
  color: #606266;
}

/* 学生信息卡片样式 */
.student-info-card {
  margin-bottom: 20px;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
}

.student-info-header {
  display: flex;
  align-items: center;
  font-weight: 600;
  font-size: 15px;
  color: #303133;
}

.student-info-header i {
  margin-right: 8px;
  font-size: 18px;
  color: #409EFF;
}

.student-info-card ::v-deep .el-card__body {
  padding: 15px;
}

.student-info-card ::v-deep .el-descriptions__label {
  font-weight: 500;
  color: #606266;
  width: 90px;
}

.student-info-card .info-value {
  color: #303133;
  font-size: 14px;
}

/* 补助金额显示样式 */
.subsidy-amount-display {
  color: #f56c6c;
  font-weight: 600;
  font-size: 18px;
}

/* 表格中资助金额显示样式 */
.subsidy-amount-text {
  color: #f56c6c;
  font-weight: 600;
  font-size: 14px;
}

.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 6px;
  line-height: 1.5;
}

.form-tip i {
  margin-right: 4px;
  color: #409EFF;
}

/* 预算选项样式优化 */
::v-deep .el-select-dropdown__item {
  padding: 10px 20px;
  line-height: 1.6;
  white-space: normal;
}

.subsidy-entry-dialog ::v-deep .el-dialog__body {
  padding: 20px;
}
</style>

<style>
/* 预算选择下拉框样式（全局样式，因为 popper 是挂载到 body 的） */
.budget-select-dropdown {
  max-height: 600px !important;
}

.budget-select-dropdown .el-select-dropdown__wrap {
  max-height: 600px !important;
}

.budget-select-dropdown .el-scrollbar__wrap {
  max-height: 600px !important;
  overflow-y: auto !important;
}

/* 优化选项样式，让内容更紧凑 */
.budget-select-dropdown .el-select-dropdown__item {
  padding: 8px 15px !important;
  line-height: 1.5 !important;
  white-space: normal !important;
  height: auto !important;
  min-height: 60px !important;
}

.budget-select-dropdown .el-select-dropdown__item:hover {
  background-color: #f5f7fa !important;
}

/* 学生详情对话框样式 */
.student-detail-content {
  padding: 0;
}

.detail-card {
  border: 1px solid #e4e7ed;
  border-radius: 4px;
}

.detail-card .card-header {
  display: flex;
  align-items: center;
  font-weight: 600;
  font-size: 15px;
  color: #303133;
}

.detail-card .card-header i {
  margin-right: 8px;
  font-size: 18px;
  color: #409EFF;
}

.detail-card ::v-deep .el-card__body {
  padding: 15px;
}

.detail-card ::v-deep .el-descriptions__label {
  font-weight: 500;
  color: #606266;
  width: 90px;
}

.detail-card .info-value {
  color: #303133;
  font-size: 14px;
}

.empty-tip {
  text-align: center;
  padding: 40px 0;
  color: #909399;
  font-size: 14px;
}

.empty-tip i {
  margin-right: 8px;
  font-size: 16px;
}
</style>
