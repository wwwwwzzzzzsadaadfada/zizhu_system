const state = {
  shouldRefreshSubsidyList: false
}

const mutations = {
  SET_SHOULD_REFRESH_SUBSIDY_LIST: (state, shouldRefresh) => {
    state.shouldRefreshSubsidyList = shouldRefresh
  }
}

const actions = {
  setShouldRefreshSubsidyList({ commit }, shouldRefresh) {
    commit('SET_SHOULD_REFRESH_SUBSIDY_LIST', shouldRefresh)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}