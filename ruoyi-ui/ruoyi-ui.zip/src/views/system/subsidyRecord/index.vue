<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学生姓名" prop="studentName">
        <el-input
          v-model="queryParams.studentName"
          placeholder="请输入学生姓名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="审批状态" prop="approvalStatus">
        <el-select v-model="queryParams.approvalStatus" placeholder="审批状态" clearable>
          <el-option
            v-for="dict in dict.type.sys_approval_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="发放状态" prop="paymentStatus">
        <el-select v-model="queryParams.paymentStatus" placeholder="发放状态" clearable>
          <el-option
            v-for="dict in dict.type.sys_payment_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:subsidyRecord:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['system:subsidyRecord:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:subsidyRecord:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:subsidyRecord:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="recordList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="id" width="80" />
      <el-table-column label="学生姓名" align="center" prop="studentName" width="100" />
      <el-table-column label="学号" align="center" prop="studentNo" width="120" />
      <el-table-column label="班级" align="center" prop="className" width="150" show-overflow-tooltip />
      <el-table-column label="补助金额" align="center" prop="subsidyAmount" width="120">
        <template slot-scope="scope">
          ¥{{ parseFloat(scope.row.subsidyAmount).toFixed(2) }}
        </template>
      </el-table-column>
      <el-table-column label="申请时间" align="center" prop="createTime" width="160" />
      <el-table-column label="审批状态" align="center" prop="approvalStatus" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_approval_status" :value="scope.row.approvalStatus"/>
        </template>
      </el-table-column>
      <el-table-column label="审批人" align="center" prop="approver" width="100" />
      <el-table-column label="审批时间" align="center" prop="approvalTime" width="160" />
      <el-table-column label="发放状态" align="center" prop="paymentStatus" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_payment_status" :value="scope.row.paymentStatus"/>
        </template>
      </el-table-column>
      <el-table-column label="备注" align="center" prop="memo" show-overflow-tooltip />
      <el-table-column label="操作" align="center" width="280" fixed="right">
        <template slot-scope="scope">
          <el-button
            v-if="scope.row.approvalStatus == 0"
            size="mini"
            type="text"
            icon="el-icon-check"
            @click="handleApprove(scope.row, 1)"
            v-hasPermi="['system:subsidyRecord:approve']"
          >通过</el-button>
          <el-button
            v-if="scope.row.approvalStatus == 0"
            size="mini"
            type="text"
            icon="el-icon-close"
            @click="handleApprove(scope.row, 2)"
            v-hasPermi="['system:subsidyRecord:approve']"
          >驳回</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:subsidyRecord:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:subsidyRecord:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改补助记录对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="600px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="学生" prop="studentId">
          <el-select 
            v-model="form.studentId" 
            placeholder="请选择学生" 
            filterable 
            remote
            :remote-method="searchStudent"
            :loading="studentLoading"
            style="width: 100%"
          >
            <el-option
              v-for="item in studentOptions"
              :key="item.id"
              :label="item.studentName + ' (' + item.studentNo + ')'"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="预算来源" prop="budgetId">
          <el-select v-model="form.budgetId" placeholder="请选择预算来源" filterable style="width: 100%">
            <el-option
              v-for="item in budgetOptions"
              :key="item.id"
              :label="item.budgetProjectName + ' (可用: ¥' + item.availableAmount + ')'"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="补助金额" prop="subsidyAmount">
          <el-input-number v-model="form.subsidyAmount" :precision="2" :min="0" :max="99999" style="width: 100%" />
        </el-form-item>
        <el-form-item label="发放状态" prop="paymentStatus">
          <el-select v-model="form.paymentStatus" placeholder="请选择发放状态" style="width: 100%">
            <el-option
              v-for="dict in dict.type.sys_payment_status"
              :key="dict.value"
              :label="dict.label"
              :value="parseInt(dict.value)"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="memo">
          <el-input v-model="form.memo" type="textarea" placeholder="请输入内容" :rows="3" maxlength="500" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 审批对话框 -->
    <el-dialog :title="approveTitle" :visible.sync="approveOpen" width="500px" append-to-body>
      <el-form ref="approveForm" :model="approveForm" label-width="100px">
        <el-form-item label="学生姓名">
          <span>{{ approveForm.studentName }}</span>
        </el-form-item>
        <el-form-item label="补助金额">
          <span style="color: #E6A23C; font-weight: bold;">¥{{ approveForm.subsidyAmount }}</span>
        </el-form-item>
        <el-form-item label="审批意见" prop="approvalMemo">
          <el-input v-model="approveForm.approvalMemo" type="textarea" placeholder="请输入审批意见" :rows="4" maxlength="500" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitApprove">确 定</el-button>
        <el-button @click="approveOpen = false">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listSubsidyRecord, getSubsidyRecord, delSubsidyRecord, addSubsidyRecord, updateSubsidyRecord, approveSubsidy } from "@/api/system/subsidyRecord";
import { listSemesterBudget } from "@/api/system/semesterBudget";
import { listStudentSemester } from "@/api/system/studentSemester";

export default {
  name: "SubsidyRecord",
  dicts: ['sys_approval_status', 'sys_payment_status'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 学生搜索加载
      studentLoading: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 补助记录表格数据
      recordList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 审批弹出层标题
      approveTitle: "",
      // 是否显示审批弹出层
      approveOpen: false,
      // 学生选项
      studentOptions: [],
      // 预算选项
      budgetOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        studentName: null,
        approvalStatus: null,
        paymentStatus: null
      },
      // 表单参数
      form: {},
      // 审批表单
      approveForm: {},
      // 表单校验
      rules: {
        studentId: [
          { required: true, message: "学生不能为空", trigger: "change" }
        ],
        budgetId: [
          { required: true, message: "预算来源不能为空", trigger: "change" }
        ],
        subsidyAmount: [
          { required: true, message: "补助金额不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
    this.getBudgetList();
  },
  methods: {
    /** 查询补助记录列表 */
    getList() {
      this.loading = true;
      listSubsidyRecord(this.queryParams).then(response => {
        this.recordList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    /** 获取预算列表 */
    getBudgetList() {
      listSemesterBudget({pageNum: 1, pageSize: 1000, status: 1}).then(response => {
        this.budgetOptions = response.rows || [];
      });
    },
    /** 搜索学生 */
    searchStudent(query) {
      if (query !== '') {
        this.studentLoading = true;
        listStudentSemester({studentName: query, pageNum: 1, pageSize: 20}).then(response => {
          this.studentOptions = response.rows || [];
          this.studentLoading = false;
        });
      } else {
        this.studentOptions = [];
      }
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        studentId: null,
        budgetId: null,
        subsidyAmount: null,
        approvalStatus: 0,
        paymentStatus: 0,
        memo: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加补助记录";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getSubsidyRecord(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改补助记录";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateSubsidyRecord(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addSubsidyRecord(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除补助记录编号为"' + ids + '"的数据项？').then(function() {
        return delSubsidyRecord(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 审批按钮操作 */
    handleApprove(row, status) {
      this.approveForm = {
        id: row.id,
        studentName: row.studentName,
        subsidyAmount: parseFloat(row.subsidyAmount).toFixed(2),
        approvalStatus: status,
        approvalMemo: ''
      };
      this.approveTitle = status === 1 ? "审批通过" : "审批驳回";
      this.approveOpen = true;
    },
    /** 提交审批 */
    submitApprove() {
      approveSubsidy(this.approveForm.id, this.approveForm.approvalStatus, this.approveForm.approvalMemo).then(response => {
        this.$modal.msgSuccess("审批成功");
        this.approveOpen = false;
        this.getList();
      });
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/subsidyRecord/export', {
        ...this.queryParams
      }, `subsidy_record_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
