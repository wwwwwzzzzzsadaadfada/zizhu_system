<template>
  <div class="app-container">
    <!-- 查询条件 -->
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学年学期" prop="yearSemesterId">
        <el-select v-model="queryParams.yearSemesterId" placeholder="请选择学年学期" clearable style="width: 200px">
          <el-option
            v-for="item in yearSemesterOptions"
            :key="item.id"
            :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="姓名" prop="name">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入姓名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="身份证号" prop="idCardNo">
        <el-input
          v-model="queryParams.idCardNo"
          placeholder="请输入身份证号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="困难类型" prop="difficultyTypeId">
        <el-select v-model="queryParams.difficultyTypeId" placeholder="请选择困难类型" clearable>
          <el-option
            v-for="dict in dict.type.sys_difficulty_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="就读状态" prop="studyStatus">
        <el-select v-model="queryParams.studyStatus" placeholder="请选择就读状态" clearable>
          <el-option
            v-for="dict in dict.type.sys_study_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <!-- 操作按钮 -->
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-refresh"
          size="mini"
          @click="handleSync"
          v-hasPermi="['system:studentRecords:add']"
        >同步学生</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:studentRecords:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <!-- 列表 -->
    <el-table v-loading="loading" :data="studentList" @selection-change="handleSelectionChange" border stripe>
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="id" width="70" />
      <el-table-column label="姓名" align="center" prop="name" width="100" show-overflow-tooltip />
      <el-table-column label="性别" align="center" prop="gender" width="60">
        <template slot-scope="scope">
          {{ scope.row.gender === '1' ? '男' : scope.row.gender === '0' ? '女' : '未知' }}
        </template>
      </el-table-column>
      <el-table-column label="身份证号" align="center" prop="idCardNo" min-width="160" show-overflow-tooltip />
      <el-table-column label="年级班级" align="center" min-width="120">
        <template slot-scope="scope">
          {{ scope.row.gradeName || '-' }} {{ scope.row.className || '' }}
        </template>
      </el-table-column>
      <el-table-column label="困难类型" align="center" prop="difficultyTypeId" min-width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.difficultyTypeId">
            {{ getDictLabel(dict.type.sys_difficulty_type, scope.row.difficultyTypeId) }}
          </span>
          <span v-else style="color: #ccc;">待录入</span>
        </template>
      </el-table-column>
      <el-table-column label="困难等级" align="center" prop="difficultyLevelId" min-width="120">
        <template slot-scope="scope">
          <dict-tag v-if="scope.row.difficultyLevelId" :options="dict.type.sys_difficulty_level" :value="scope.row.difficultyLevelId"/>
          <span v-else style="color: #ccc;">待录入</span>
        </template>
      </el-table-column>
      <el-table-column label="就读状态" align="center" prop="studyStatus" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_study_status" :value="scope.row.studyStatus"/>
        </template>
      </el-table-column>
      <el-table-column label="受助金额" align="center" width="150">
        <template slot-scope="scope">
          <el-link 
            v-if="scope.row.subsidyAmount && scope.row.subsidyAmount > 0" 
            type="success" 
            :underline="false"
            @click="handleSubsidy(scope.row)"
            style="font-weight: bold; font-size: 14px;"
          >
            ¥ {{ parseFloat(scope.row.subsidyAmount).toFixed(2) }}
          </el-link>
          <el-link 
            v-else 
            type="info" 
            :underline="false"
            @click="handleSubsidy(scope.row)"
            v-hasPermi="['system:studentRecords:edit']"
          >
            <i class="el-icon-circle-plus-outline"></i> 录入金额
          </el-link>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="150">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="handleDetail(scope.row)"
            v-hasPermi="['system:studentRecords:query']"
          >详情</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:studentRecords:edit']"
          >编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 详情对话框 -->
    <el-dialog title="学生详情" :visible.sync="detailOpen" width="900px" append-to-body>
      <el-tabs v-model="activeTab" type="border-card">
        <!-- 基本信息 -->
        <el-tab-pane label="基本信息" name="basic">
          <el-descriptions :column="2" border>
            <el-descriptions-item label="姓名">{{ detailData.name }}</el-descriptions-item>
            <el-descriptions-item label="性别">
              {{ detailData.gender === '1' ? '男' : detailData.gender === '0' ? '女' : '未知' }}
            </el-descriptions-item>
            <el-descriptions-item label="身份证号">{{ detailData.idCardNo }}</el-descriptions-item>
            <el-descriptions-item label="学籍号">{{ detailData.studentNo }}</el-descriptions-item>
            <el-descriptions-item label="民族">
              <dict-tag v-if="detailData.ethnicity" :options="dict.type.sys_user_nation" :value="detailData.ethnicity"/>
            </el-descriptions-item>
            <el-descriptions-item label="户籍地">{{ detailData.domicile }}</el-descriptions-item>
            <el-descriptions-item label="学制">{{ detailData.schoolingPlanName }}</el-descriptions-item>
            <el-descriptions-item label="年级">{{ detailData.gradeName }}</el-descriptions-item>
            <el-descriptions-item label="班级">{{ detailData.className }}</el-descriptions-item>
            <el-descriptions-item label="就读状态">
              <dict-tag :options="dict.type.sys_study_status" :value="detailData.studyStatus"/>
            </el-descriptions-item>
          </el-descriptions>
        </el-tab-pane>
        
        <!-- 困难认定信息 -->
        <el-tab-pane label="困难认定" name="difficulty">
          <el-descriptions :column="2" border>
            <el-descriptions-item label="困难类型">
              <span v-if="detailData.difficultyTypeId">
                <dict-tag :options="dict.type.sys_difficulty_type" :value="detailData.difficultyTypeId"/>
              </span>
              <span v-else style="color: #ccc;">未录入</span>
            </el-descriptions-item>
            <el-descriptions-item label="困难等级">
              <dict-tag v-if="detailData.difficultyLevelId" :options="dict.type.sys_difficulty_level" :value="detailData.difficultyLevelId"/>
              <span v-else style="color: #ccc;">未录入</span>
            </el-descriptions-item>
            <el-descriptions-item label="脱贫年份">
              {{ detailData.povertyReliefYear || '-' }}
            </el-descriptions-item>
            <el-descriptions-item label="认定时间">
              {{ detailData.createdAt || '-' }}
            </el-descriptions-item>
          </el-descriptions>
        </el-tab-pane>
        
        <!-- 资助信息 -->
        <el-tab-pane label="资助信息" name="subsidy">
          <el-descriptions :column="2" border>
            <el-descriptions-item label="资助状态">
              <el-tag v-if="detailData.subsidyAmount && detailData.subsidyAmount > 0" type="success">已录入</el-tag>
              <el-tag v-else type="info">待录入</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="受助金额">
              <span v-if="detailData.subsidyAmount" style="font-size: 16px; font-weight: bold; color: #67C23A;">
                ¥ {{ parseFloat(detailData.subsidyAmount).toFixed(2) }}
              </span>
              <span v-else style="color: #ccc;">未录入</span>
            </el-descriptions-item>
            <el-descriptions-item label="学期预算">
              {{ detailData.budgetName || '-' }}
            </el-descriptions-item>
            <el-descriptions-item label="资助指标">
              {{ detailData.quotaName || '-' }}
            </el-descriptions-item>
            <el-descriptions-item label="审批状态">
              <dict-tag v-if="detailData.approvalStatus !== null" :options="approvalStatusOptions" :value="detailData.approvalStatus"/>
              <span v-else>-</span>
            </el-descriptions-item>
            <el-descriptions-item label="更新时间">
              {{ detailData.updatedAt || '-' }}
            </el-descriptions-item>
            <el-descriptions-item label="备注" :span="2">
              {{ detailData.memo || '-' }}
            </el-descriptions-item>
          </el-descriptions>
        </el-tab-pane>
      </el-tabs>
      <div slot="footer" class="dialog-footer">
        <el-button @click="detailOpen = false">关 闭</el-button>
      </div>
    </el-dialog>

    <!-- 编辑对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="600px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="姓名">
          <el-input v-model="form.name" disabled />
        </el-form-item>
        <el-form-item label="身份证号">
          <el-input v-model="form.idCardNo" disabled />
        </el-form-item>
        <el-form-item label="困难类型" prop="difficultyTypeId">
          <el-select v-model="form.difficultyTypeId" placeholder="请选择困难类型" style="width: 100%">
            <el-option
              v-for="dict in dict.type.sys_difficulty_type"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="困难等级" prop="difficultyLevelId">
          <el-select v-model="form.difficultyLevelId" placeholder="请选择困难等级" style="width: 100%">
            <el-option
              v-for="dict in dict.type.sys_difficulty_level"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="脱贫年份" prop="povertyReliefYear">
          <el-date-picker
            v-model="form.povertyReliefYear"
            type="year"
            placeholder="选择年份"
            value-format="yyyy"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="备注" prop="memo">
          <el-input v-model="form.memo" type="textarea" :rows="3" placeholder="请输入备注" maxlength="500" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 录入受助金额对话框 -->
    <el-dialog title="录入受助金额" :visible.sync="subsidyOpen" width="600px" append-to-body>
      <el-form ref="subsidyForm" :model="subsidyForm" :rules="subsidyRules" label-width="100px">
        <!-- 基本信息 -->
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="姓名">
              <el-input v-model="subsidyForm.name" disabled />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="身份证号">
              <el-input v-model="subsidyForm.idCardNo" disabled />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="困难类型">
              <el-input v-model="subsidyForm.difficultyTypeName" disabled />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="困难等级">
              <el-input v-model="subsidyForm.difficultyLevelName" disabled />
            </el-form-item>
          </el-col>
        </el-row>
        
        <el-divider content-position="left">受助信息</el-divider>
        
        <!-- 选择学期预算 -->
        <el-form-item label="学期预算" prop="budgetId">
          <el-select v-model="subsidyForm.budgetId" placeholder="请选择学期预算" style="width: 100%" @change="handleBudgetChange">
            <el-option
              v-for="budget in budgetOptions"
              :key="budget.id"
              :label="getBudgetLabel(budget)"
              :value="budget.id"
            >
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span>{{ getBudgetLabel(budget) }}</span>
                <span style="color: #67C23A; font-size: 12px; margin-left: 10px;">
                  剩余: ¥{{ parseFloat((budget.budgetAmount || 0) - (budget.usedAmount || 0) - (budget.lockedAmount || 0)).toFixed(2) }}
                </span>
              </div>
            </el-option>
          </el-select>
        </el-form-item>
        
        <!-- 选择经济分类 -->
        <el-form-item label="经济分类" prop="economyCategory">
          <el-select 
            v-model="subsidyForm.economyCategory" 
            placeholder="请先选择学期预算" 
            style="width: 100%"
            :disabled="!subsidyForm.budgetId || economyCategoryOptions.length === 0"
          >
            <el-option
              v-for="dict in economyCategoryOptions"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            />
          </el-select>
          <div v-if="subsidyForm.budgetId && economyCategoryOptions.length === 0" style="color: #909399; font-size: 12px; margin-top: 5px;">
            该预算暂无可用的经济分类
          </div>
        </el-form-item>
        
        <!-- 输入受助金额 -->
        <el-form-item label="受助金额" prop="subsidyAmount">
          <el-input-number 
            v-model="subsidyForm.subsidyAmount" 
            :precision="2" 
            :step="100" 
            :min="0" 
            style="width: 100%" 
            placeholder="请输入受助金额" 
          />
        </el-form-item>
        
        <!-- 备注 -->
        <el-form-item label="备注">
          <el-input v-model="subsidyForm.memo" type="textarea" :rows="3" placeholder="请输入备注" maxlength="500" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitSubsidyForm">确 定</el-button>
        <el-button @click="subsidyOpen = false">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listStudentRecords, getStudentRecord, updateStudentRecord, syncStudents } from "@/api/system/studentRecord";
import { listYearSemesters } from "@/api/system/yearSemester";
import { listSemesterBudget } from "@/api/system/semesterBudget";

export default {
  name: "AidedStudent",
  dicts: ['sys_difficulty_type', 'sys_difficulty_level', 'sys_study_status', 'sys_user_nation', 'sys_economy_category'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 学生列表
      studentList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 详情弹出层
      detailOpen: false,
      // 详情数据
      detailData: {},
      // 详情页活动标签页
      activeTab: 'basic',
      // 受助金额弹出层
      subsidyOpen: false,
      // 学年学期选项
      yearSemesterOptions: [],
      // 学期预算选项
      budgetOptions: [],
      // 经济分类选项（根据预算动态过滤）
      economyCategoryOptions: [],
      // 审批状态选项
      approvalStatusOptions: [
        { label: '待审核', value: '0' },
        { label: '已通过', value: '1' },
        { label: '未通过', value: '2' }
      ],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        yearSemesterId: null,
        name: null,
        idCardNo: null,
        difficultyTypeId: null,
        studyStatus: null
      },
      // 表单参数
      form: {},
      // 受助金额表单
      subsidyForm: {},
      // 表单校验
      rules: {
        difficultyTypeId: [
          { required: true, message: "困难类型不能为空", trigger: "change" }
        ],
        difficultyLevelId: [
          { required: true, message: "困难等级不能为空", trigger: "change" }
        ]
      },
      // 受助金额表单校验
      subsidyRules: {
        budgetId: [
          { required: true, message: "请选择学期预算", trigger: "change" }
        ],
        economyCategory: [
          { required: true, message: "请选择经济分类", trigger: "change" }
        ],
        subsidyAmount: [
          { required: true, message: "请输入受助金额", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getYearSemesterList();
    this.getList();
  },
  methods: {
    /** 查询学年学期列表 */
    getYearSemesterList() {
      listYearSemesters({status: 1, pageNum: 1, pageSize: 100}).then(response => {
        this.yearSemesterOptions = response.rows || [];
        // 默认选择当前学年学期
        const currentSemester = this.yearSemesterOptions.find(item => item.isCurrent === 1);
        if (currentSemester && !this.queryParams.yearSemesterId) {
          this.queryParams.yearSemesterId = currentSemester.id;
        }
      });
    },
    /** 查询学生列表 */
    getList() {
      this.loading = true;
      listStudentRecords(this.queryParams).then(response => {
        this.studentList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 详情按钮操作 */
    handleDetail(row) {
      const id = row.id || this.ids
      getStudentRecord(id).then(response => {
        this.detailData = response.data;
        this.detailOpen = true;
      });
    },
    /** 编辑按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getStudentRecord(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改困难认定信息";
      });
    },
    /** 录入受助金额按钮操作 */
    handleSubsidy(row) {
      if (!row.difficultyTypeId || !row.difficultyLevelId) {
        this.$modal.msgWarning("请先完善困难认定信息");
        return;
      }
      this.subsidyForm = {
        id: row.id,
        name: row.name,
        idCardNo: row.idCardNo,
        difficultyTypeName: this.getDictLabel(this.dict.type.sys_difficulty_type, row.difficultyTypeId),
        difficultyLevelName: this.getDictLabel(this.dict.type.sys_difficulty_level, row.difficultyLevelId),
        budgetId: row.budgetId,
        economyCategory: null,
        subsidyAmount: row.subsidyAmount,
        memo: row.memo
      };
      this.economyCategoryOptions = [];
      // 获取当前学年学期的学期预算列表
      this.getBudgetList();
      this.subsidyOpen = true;
    },
    /** 获取学期预算列表 */
    getBudgetList() {
      if (!this.queryParams.yearSemesterId) {
        this.$modal.msgWarning("请先选择学年学期");
        return;
      }
      listSemesterBudget({ yearSemesterId: this.queryParams.yearSemesterId, status: 1 }).then(response => {
        this.budgetOptions = response.rows || [];
      });
    },
    /** 学期预算变更 */
    handleBudgetChange(budgetId) {
      const budget = this.budgetOptions.find(item => item.id === budgetId);
      if (budget) {
        // 计算剩余金额并提示
        const availableAmount = budget.budgetAmount - (budget.usedAmount || 0) - (budget.lockedAmount || 0);
        if (availableAmount <= 0) {
          this.$modal.msgWarning("该预算剩余金额不足，请选择其他预算");
        }
        
        // 自动带出该预算对应的经济分类
        if (budget.economyCategory) {
          this.subsidyForm.economyCategory = budget.economyCategory;
          // 只显示该预算对应的经济分类（禁止修改）
          this.economyCategoryOptions = this.dict.type.sys_economy_category.filter(
            item => item.value === budget.economyCategory
          );
        } else {
          // 如果预算没有指定经济分类，清空并允许手动选择
          this.subsidyForm.economyCategory = null;
          this.economyCategoryOptions = this.dict.type.sys_economy_category;
        }
      } else {
        this.economyCategoryOptions = [];
        this.subsidyForm.economyCategory = null;
      }
    },
    /** 取消按钮 */
    cancel() {
      this.open = false;
      this.reset();
    },
    /** 表单重置 */
    reset() {
      this.form = {
        id: null,
        difficultyTypeId: null,
        difficultyLevelId: null,
        povertyReliefYear: null,
        memo: null
      };
      this.resetForm("form");
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          updateStudentRecord(this.form).then(response => {
            this.$modal.msgSuccess("保存成功");
            this.open = false;
            this.getList();
          });
        }
      });
    },
    /** 提交受助金额表单 */
    submitSubsidyForm() {
      this.$refs["subsidyForm"].validate(valid => {
        if (valid) {
          // 后端会自动验证预算剩余金额
          updateStudentRecord(this.subsidyForm).then(response => {
            this.$modal.msgSuccess("录入成功");
            this.subsidyOpen = false;
            this.getList();
          }).catch(error => {
            // 显示后端返回的错误信息
            console.error(error);
          });
        }
      });
    },
    /** 同步学生按钮操作 */
    handleSync() {
      if (!this.queryParams.yearSemesterId) {
        this.$modal.msgWarning("请先选择学年学期");
        return;
      }
      this.$modal.confirm('是否确认同步当前学年学期的学生数据？').then(() => {
        return syncStudents(this.queryParams.yearSemesterId);
      }).then((response) => {
        this.getList();
        this.$modal.msgSuccess(response.msg);
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/studentRecord/export', {
        ...this.queryParams
      }, `受助学生_${new Date().getTime()}.xlsx`)
    },
    /** 获取字典标签 */
    getDictLabel(dicts, value) {
      if (!dicts || !value) return '';
      const dict = dicts.find(item => item.value === value);
      return dict ? dict.label : value;
    },
    /** 获取学期预算显示标签 */
    getBudgetLabel(budget) {
      if (!budget) return '';
      // 优先显示指标文标题，其次是预算项目名称，最后是预算类型
      let label = budget.quotaDocTitle || budget.budgetProjectName || budget.budgetType || `预算${budget.id}`;
      
      // 添加经济分类标识，便于区分助学金和免学杂费
      if (budget.economyCategory) {
        const categoryName = this.getDictLabel(this.dict.type.sys_economy_category, budget.economyCategory);
        if (categoryName) {
          label = `${label} - ${categoryName}`;
        }
      }
      
      return label;
    }
  }
};
</script>
