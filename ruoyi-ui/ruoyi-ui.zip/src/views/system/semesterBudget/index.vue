<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学年学期" prop="yearSemesterId">
        <el-select v-model="queryParams.yearSemesterId" placeholder="请选择学年学期" clearable style="width: 200px">
          <el-option
            v-for="item in yearSemesterOptions"
            :key="item.id"
            :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="预算类型" prop="budgetType">
        <el-input
          v-model="queryParams.budgetType"
          placeholder="请输入预算类型"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status" placeholder="预算状态" clearable>
          <el-option
            v-for="dict in dict.type.sys_budget_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:semesterBudget:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['system:semesterBudget:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:semesterBudget:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:semesterBudget:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="budgetList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="id" width="80" />
      <el-table-column label="学年" align="center" prop="schoolYear" width="110" />
      <el-table-column label="学期" align="center" prop="semester" width="100">
        <template slot-scope="scope">
          {{ scope.row.semester === 1 ? '第一学期' : '第二学期' }}
        </template>
      </el-table-column>
      <el-table-column label="指标文标题" align="center" prop="quotaDocTitle" width="200" show-overflow-tooltip />
      <el-table-column label="预算项目" align="center" prop="budgetProjectName" width="180" show-overflow-tooltip />
      <el-table-column label="经济分类" align="center" prop="economyCategory" width="120">
        <template slot-scope="scope">
          <dict-tag v-if="scope.row.economyCategory" :options="dict.type.sys_economy_category" :value="scope.row.economyCategory"/>
          <span v-else>-</span>
        </template>
      </el-table-column>
      <el-table-column label="功能分类" align="center" prop="functionCategory" width="120">
        <template slot-scope="scope">
          <dict-tag v-if="scope.row.functionCategory" :options="dict.type.sys_function_category" :value="scope.row.functionCategory"/>
          <span v-else>-</span>
        </template>
      </el-table-column>
      <el-table-column label="预算类型" align="center" prop="budgetType" width="120" />
      <el-table-column label="预算总额" align="center" prop="budgetAmount" width="120">
        <template slot-scope="scope">
          ¥{{ parseFloat(scope.row.budgetAmount).toFixed(2) }}
        </template>
      </el-table-column>
      <el-table-column label="已使用" align="center" prop="usedAmount" width="120">
        <template slot-scope="scope">
          ¥{{ parseFloat(scope.row.usedAmount).toFixed(2) }}
        </template>
      </el-table-column>
      <el-table-column label="锁定金额" align="center" prop="lockedAmount" width="120">
        <template slot-scope="scope">
          ¥{{ parseFloat(scope.row.lockedAmount).toFixed(2) }}
        </template>
      </el-table-column>
      <el-table-column label="可用金额" align="center" prop="availableAmount" width="120">
        <template slot-scope="scope">
          <span :style="{color: scope.row.availableAmount > 0 ? '#67C23A' : '#F56C6C'}">
            ¥{{ parseFloat(scope.row.availableAmount).toFixed(2) }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="状态" align="center" prop="status" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_budget_status" :value="scope.row.status"/>
        </template>
      </el-table-column>
      <el-table-column label="备注" align="center" prop="memo" show-overflow-tooltip />
      <el-table-column label="操作" align="center" width="180" fixed="right">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:semesterBudget:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:semesterBudget:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改学期预算对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="600px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="学年学期" prop="yearSemesterId">
          <el-select 
            v-model="form.yearSemesterId" 
            placeholder="请选择学年学期" 
            style="width: 100%"
            @change="handleYearSemesterChange"
          >
            <el-option
              v-for="item in yearSemesterOptions"
              :key="item.id"
              :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="关联指标" prop="quotaId">
          <el-select 
            v-model="form.quotaId" 
            placeholder="请先选择学年学期后选择指标文号" 
            filterable 
            style="width: 100%"
            :disabled="!form.yearSemesterId"
            @change="handleQuotaChange"
          >
            <el-option
              v-for="item in filteredQuotaOptions"
              :key="item.id"
              :label="item.quotaDocNo + ' - ' + item.quotaDocTitle"
              :value="item.id"
            >
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="flex: 1; overflow: hidden;">
                  <div style="font-size: 14px; font-weight: 500; color: #303133; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    {{ item.quotaDocNo }}
                  </div>
                  <div style="font-size: 12px; color: #606266;">
                    {{ item.quotaDocTitle }}
                  </div>
                </div>
                <div style="margin-left: 10px; text-align: right;">
                  <div style="font-size: 11px; color: #909399;">
                    {{ item.detailList ? item.detailList.length : 0 }} 个经济分类
                  </div>
                </div>
              </div>
            </el-option>
          </el-select>
        </el-form-item>
        
        <!-- 第二步：选择经济分类明细 -->
        <el-form-item label="经济分类" prop="quotaDetailId" v-if="form.quotaId && quotaDetailOptions.length > 0">
          <el-select 
            v-model="form.quotaDetailId" 
            placeholder="请选择经济分类" 
            style="width: 100%"
            @change="handleDetailChange"
          >
            <el-option
              v-for="detail in quotaDetailOptions"
              :key="detail.id"
              :label="getDictLabel(dict.type.sys_economy_category, detail.economyCategory)"
              :value="detail.id"
            >
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 5px 0;">
                <div style="flex: 1;">
                  <el-tag size="small" :type="detail.availableAmount > 0 ? 'success' : 'danger'">
                    {{ getDictLabel(dict.type.sys_economy_category, detail.economyCategory) }}
                  </el-tag>
                </div>
                <div style="margin-left: 10px; text-align: right;">
                  <div style="font-size: 13px; color: #67C23A; font-weight: 600;">
                    剩余: ￥{{ parseFloat(detail.availableAmount || 0).toFixed(2) }}
                  </div>
                  <div style="font-size: 11px; color: #909399; margin-top: 2px;">
                    总额: ￥{{ parseFloat(detail.totalAmount || 0).toFixed(2) }}
                  </div>
                </div>
              </div>
            </el-option>
          </el-select>
        </el-form-item>
        
        <!-- 选中经济分类后显示详细信息卡片 -->
        <el-form-item v-if="selectedDetailInfo" label="明细信息">
          <el-card shadow="never" style="background-color: #f5f7fa;">
            <el-descriptions :column="2" size="small" border>
              <el-descriptions-item label="指标文号" :span="2">
                <span style="font-weight: 500;">{{ selectedQuotaInfo.quotaDocNo }}</span>
              </el-descriptions-item>
              <el-descriptions-item label="指标文标题" :span="2">
                <span style="font-weight: 500;">{{ selectedQuotaInfo.quotaDocTitle }}</span>
              </el-descriptions-item>
              <el-descriptions-item label="预算项目">
                {{ selectedQuotaInfo.budgetProjectName || '-' }}
              </el-descriptions-item>
              <el-descriptions-item label="功能分类">
                <dict-tag v-if="selectedQuotaInfo.functionCategory" :options="dict.type.sys_function_category" :value="selectedQuotaInfo.functionCategory"/>
                <span v-else>-</span>
              </el-descriptions-item>
              <el-descriptions-item label="经济分类">
                <dict-tag :options="dict.type.sys_economy_category" :value="selectedDetailInfo.economyCategory"/>
              </el-descriptions-item>
              <el-descriptions-item label="总金额">
                <span style="color: #E6A23C; font-weight: bold;">￥{{ parseFloat(selectedDetailInfo.totalAmount).toFixed(2) }}</span>
              </el-descriptions-item>
              <el-descriptions-item label="已分配">
                <span>￥{{ parseFloat(selectedDetailInfo.allocatedAmount || 0).toFixed(2) }}</span>
              </el-descriptions-item>
              <el-descriptions-item label="剩余金额">
                <span :style="{color: selectedDetailInfo.availableAmount > 0 ? '#67C23A' : '#F56C6C', fontWeight: 'bold'}">
                  ￥{{ parseFloat(selectedDetailInfo.availableAmount || 0).toFixed(2) }}
                </span>
              </el-descriptions-item>
            </el-descriptions>
          </el-card>
        </el-form-item>
        <el-form-item label="预算类型" prop="budgetType">
          <el-input v-model="form.budgetType" placeholder="请输入预算类型" maxlength="50" />
        </el-form-item>
        <el-form-item label="预算总额" prop="budgetAmount">
          <el-input-number v-model="form.budgetAmount" :precision="2" :min="0" :max="99999999" style="width: 100%" />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-select v-model="form.status" placeholder="请选择状态" style="width: 100%">
            <el-option
              v-for="dict in dict.type.sys_budget_status"
              :key="dict.value"
              :label="dict.label"
              :value="parseInt(dict.value)"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="memo">
          <el-input v-model="form.memo" type="textarea" placeholder="请输入内容" :rows="3" maxlength="500" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listSemesterBudget, getSemesterBudget, delSemesterBudget, addSemesterBudget, updateSemesterBudget } from "@/api/system/semesterBudget";
import { listYearSemesters } from "@/api/system/yearSemester";
import { listSubsidyQuotaWithUsage } from "@/api/system/subsidyQuota";

export default {
  name: "SemesterBudget",
  dicts: ['sys_budget_status', 'sys_function_category', 'sys_economy_category', 'sys_budget_source', 'sys_budget_level'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 学期预算表格数据
      budgetList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 学年学期选项
      yearSemesterOptions: [],
      // 指标选项（全部）
      quotaOptions: [],
      // 当前选中的指标详情
      selectedQuotaInfo: null,
      // 当前选中的明细详情
      selectedDetailInfo: null,
      // 经济分类明细选项（当前指标下的）
      quotaDetailOptions: [],
      // 经济分类字典
      economyCategoryDict: [],
      // 功能分类字典
      functionCategoryDict: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        yearSemesterId: null,
        budgetType: null,
        status: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        yearSemesterId: [
          { required: true, message: "学年学期不能为空", trigger: "change" }
        ],
        quotaId: [
          { required: true, message: "请选择关联指标", trigger: "change" }
        ],
        quotaDetailId: [
          { required: true, message: "请选择经济分类", trigger: "change" }
        ],
        budgetAmount: [
          { required: true, message: "预算总额不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
    this.getYearSemesterList();
    this.getQuotaList();
    this.loadDictionaries();
  },
  computed: {
    // 根据选择的学年学期过滤指标选项
    filteredQuotaOptions() {
      if (!this.form.yearSemesterId) {
        return [];
      }
      
      return this.quotaOptions
        .filter(item => item.yearSemesterId === this.form.yearSemesterId)
        .filter(item => item.detailList && item.detailList.length > 0); // 只显示有明细的指标
    }
  },
  methods: {
    /** 查询学期预算列表 */
    getList() {
      this.loading = true;
      listSemesterBudget(this.queryParams).then(response => {
        this.budgetList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    /** 获取学年学期列表 */
    getYearSemesterList() {
      // 只获取状态为"进行中"的学年学期 (status=1)
      // 不分页，获取所有数据
      listYearSemesters({status: 1, pageNum: 1, pageSize: 100}).then(response => {
        this.yearSemesterOptions = response.rows || [];
      });
    },
    /** 获取指标列表 */
    getQuotaList() {
      // 获取所有进行中学年学期的指标，包含经济分类和功能分类信息
      // 使用 listSubsidyQuotaWithUsage 获取完整的指标信息
      listSubsidyQuotaWithUsage({pageNum: 1, pageSize: 1000, status: 1}).then(response => {
        this.quotaOptions = response.rows || [];
      });
    },
    /** 加载字典数据 */
    loadDictionaries() {
      // 加载经济分类字典
      if (this.dict.type.sys_economy_category) {
        this.economyCategoryDict = this.dict.type.sys_economy_category;
      }
      // 加载功能分类字典
      if (this.dict.type.sys_function_category) {
        this.functionCategoryDict = this.dict.type.sys_function_category;
      }
    },
    /** 获取字典标签 */
    getDictLabel(dictData, value) {
      if (!dictData || !value) return '';
      const dict = dictData.find(item => item.value === value);
      return dict ? dict.label : value;
    },
    /** 学年学期变化时清空关联指标 */
    handleYearSemesterChange() {
      // 学年学期变化时，清空已选择的指标和明细
      this.form.quotaId = null;
      this.form.quotaDetailId = null;
      this.selectedQuotaInfo = null;
      this.selectedDetailInfo = null;
      this.quotaDetailOptions = [];
    },
    /** 指标变化时加载明细列表 */
    handleQuotaChange(quotaId) {
      // 清空明细选择
      this.form.quotaDetailId = null;
      this.selectedDetailInfo = null;
      
      if (quotaId) {
        // 从过滤后的选项中找到选中的指标
        this.selectedQuotaInfo = this.filteredQuotaOptions.find(item => item.id === quotaId);
        
        // 加载该指标下的所有经济分类明细
        if (this.selectedQuotaInfo && this.selectedQuotaInfo.detailList) {
          this.quotaDetailOptions = this.selectedQuotaInfo.detailList;
        } else {
          this.quotaDetailOptions = [];
        }
      } else {
        this.selectedQuotaInfo = null;
        this.quotaDetailOptions = [];
      }
    },
    /** 明细变化时加载详细信息 */
    handleDetailChange(detailId) {
      if (detailId) {
        // 从明细选项中找到选中的明细
        this.selectedDetailInfo = this.quotaDetailOptions.find(item => item.id === detailId);
      } else {
        this.selectedDetailInfo = null;
      }
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        yearSemesterId: null,
        quotaId: null,
        quotaDetailId: null,
        budgetType: null,
        budgetAmount: null,
        usedAmount: 0,
        lockedAmount: 0,
        status: 1,
        memo: null
      };
      this.selectedQuotaInfo = null;
      this.selectedDetailInfo = null;
      this.quotaDetailOptions = [];
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加学期预算";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getSemesterBudget(id).then(response => {
        this.form = response.data;
        // 加载选中的指标详情
        if (this.form.quotaId) {
          this.handleQuotaChange(this.form.quotaId);
          // 如果有明细ID，加载明细详情
          if (this.form.quotaDetailId) {
            this.$nextTick(() => {
              this.handleDetailChange(this.form.quotaDetailId);
            });
          }
        }
        this.open = true;
        this.title = "修改学期预算";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateSemesterBudget(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
              this.getQuotaList(); // 刷新指标列表
            });
          } else {
            addSemesterBudget(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
              this.getQuotaList(); // 刷新指标列表
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除学期预算编号为"' + ids + '"的数据项？').then(function() {
        return delSemesterBudget(ids);
      }).then(() => {
        this.getList();
        this.getQuotaList(); // 刷新指标列表
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/semesterBudget/export', {
        ...this.queryParams
      }, `semester_budget_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
