import request from '@/utils/request'

// 查询资助指标下达列表
export function listSubsidyQuota(query) {
  return request({
    url: '/system/subsidyQuota/list',
    method: 'get',
    params: query
  })
}

// 查询资助指标使用情况列表
export function listSubsidyQuotaWithUsage(query) {
  return request({
    url: '/system/subsidyQuota/listWithUsage',
    method: 'get',
    params: query
  })
}

// 查询资助指标下达详细
export function getSubsidyQuota(id) {
  return request({
    url: '/system/subsidyQuota/' + id,
    method: 'get'
  })
}

// 新增资助指标下达
export function addSubsidyQuota(data) {
  return request({
    url: '/system/subsidyQuota',
    method: 'post',
    data: data
  })
}

// 修改资助指标下达
export function updateSubsidyQuota(data) {
  return request({
    url: '/system/subsidyQuota',
    method: 'put',
    data: data
  })
}

// 删除资助指标下达
export function delSubsidyQuota(id) {
  return request({
    url: '/system/subsidyQuota/' + id,
    method: 'delete'
  })
}
