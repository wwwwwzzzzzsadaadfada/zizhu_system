<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学年学期" prop="yearSemesterId">
        <el-select v-model="queryParams.yearSemesterId" placeholder="请选择学年学期" clearable style="width: 200px">
          <el-option
            v-for="item in yearSemesterOptions"
            :key="item.id"
            :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="指标文号" prop="quotaDocNo">
        <el-input
          v-model="queryParams.quotaDocNo"
          placeholder="请输入指标文号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="功能分类" prop="functionCategory">
        <el-select v-model="queryParams.functionCategory" placeholder="功能分类" clearable>
          <el-option
            v-for="dict in dict.type.sys_function_category"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status" placeholder="状态" clearable>
          <el-option label="启用" value="1" />
          <el-option label="停用" value="0" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:subsidyQuota:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['system:subsidyQuota:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:subsidyQuota:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:subsidyQuota:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="quotaList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="id" width="80" />
      <el-table-column label="学年" align="center" prop="schoolYear" width="110" />
      <el-table-column label="学期" align="center" prop="semester" width="100">
        <template slot-scope="scope">
          {{ scope.row.semester === 1 ? '第一学期' : '第二学期' }}
        </template>
      </el-table-column>
      <el-table-column label="发文时间" align="center" prop="issueDate" width="120" />
      <el-table-column label="指标文标题" align="center" prop="quotaDocTitle" width="200" show-overflow-tooltip />
      <el-table-column label="指标文号" align="center" prop="quotaDocNo" width="150" show-overflow-tooltip />
      <el-table-column label="预算项目" align="center" prop="budgetProjectName" width="180" show-overflow-tooltip />
      <el-table-column label="功能分类" align="center" prop="functionCategory" width="120">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_function_category" :value="scope.row.functionCategory"/>
        </template>
      </el-table-column>
      <el-table-column label="经济分类明细" align="center" width="150">
        <template slot-scope="scope">
          <div v-if="scope.row.detailList && scope.row.detailList.length > 0">
            <el-tag 
              v-for="(detail, index) in scope.row.detailList" 
              :key="index" 
              type="info" 
              size="small"
              style="margin: 2px;"
            >
              {{ getDictLabel(dict.type.sys_economy_category, detail.economyCategory) }}
            </el-tag>
          </div>
          <span v-else style="color: #909399;">-</span>
        </template>
      </el-table-column>
      <el-table-column label="总指标" align="center" prop="totalQuota" width="130">
        <template slot-scope="scope">
          <span style="color: #E6A23C; font-weight: bold;">¥{{ parseFloat(scope.row.totalQuota || 0).toFixed(2) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="已分配指标" align="center" prop="allocatedAmount" width="130">
        <template slot-scope="scope">
          ¥{{ parseFloat(scope.row.allocatedAmount || 0).toFixed(2) }}
        </template>
      </el-table-column>
      <el-table-column label="指标结余" align="center" width="130">
        <template slot-scope="scope">
          <span :style="{color: (scope.row.totalQuota - (scope.row.allocatedAmount || 0)) > 0 ? '#67C23A' : '#F56C6C'}">
            ¥{{ parseFloat((scope.row.totalQuota || 0) - (scope.row.allocatedAmount || 0)).toFixed(2) }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="状态" align="center" prop="status" width="80">
        <template slot-scope="scope">
          <el-tag :type="scope.row.status == 1 ? 'success' : 'danger'">
            {{ scope.row.status == 1 ? '启用' : '停用' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="200" fixed="right">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="handleView(scope.row)"
            v-hasPermi="['system:subsidyQuota:query']"
          >明细</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:subsidyQuota:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:subsidyQuota:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改指标下达对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="900px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="130px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="学年学期" prop="yearSemesterId">
              <el-select v-model="form.yearSemesterId" placeholder="请选择学年学期" style="width: 100%">
                <el-option
                  v-for="item in yearSemesterOptions"
                  :key="item.id"
                  :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="发文时间" prop="issueDate">
              <el-date-picker
                v-model="form.issueDate"
                type="date"
                value-format="yyyy-MM-dd"
                placeholder="选择发文时间"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        
        <el-row>
          <el-col :span="12">
            <el-form-item label="上级文号名称" prop="superiorDocNo">
              <el-input v-model="form.superiorDocNo" placeholder="请输入上级文号" maxlength="100" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="指标文号名称" prop="quotaDocNo">
              <el-input v-model="form.quotaDocNo" placeholder="请输入指标文号" maxlength="100" />
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="指标文标题" prop="quotaDocTitle">
          <el-autocomplete
            v-model="form.quotaDocTitle"
            :fetch-suggestions="queryQuotaTitles"
            placeholder="请输入或选择指标文标题"
            style="width: 100%"
            maxlength="200"
            @select="handleQuotaTitleSelect"
          >
            <template slot-scope="{ item }">
              <div>{{ item.value }}</div>
            </template>
          </el-autocomplete>
        </el-form-item>

        <el-row>
          <el-col :span="12">
            <el-form-item label="预算项目编码" prop="budgetProjectCode">
              <el-input v-model="form.budgetProjectCode" placeholder="请输入预算项目编码" maxlength="50" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="预算项目名称" prop="budgetProjectName">
              <el-autocomplete
                v-model="form.budgetProjectName"
                :fetch-suggestions="queryBudgetProjectNames"
                placeholder="请输入或选择预算项目名称"
                style="width: 100%"
                maxlength="100"
                @select="handleBudgetProjectNameSelect"
              >
                <template slot-scope="{ item }">
                  <div>{{ item.value }}</div>
                </template>
              </el-autocomplete>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="指标摘要" prop="quotaSummary">
          <el-input v-model="form.quotaSummary" type="textarea" placeholder="请输入指标摘要" :rows="3" maxlength="500" />
        </el-form-item>

        <el-row>
          <el-col :span="12">
            <el-form-item label="功能分类" prop="functionCategory">
              <el-select v-model="form.functionCategory" placeholder="请选择功能分类" style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_function_category"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="预算来源" prop="budgetSource">
              <el-select v-model="form.budgetSource" placeholder="请选择预算来源" style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_budget_source"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="12">
            <el-form-item label="预算级次" prop="budgetLevel">
              <el-select v-model="form.budgetLevel" placeholder="请选择预算级次" style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_budget_level"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="状态" prop="status">
              <el-radio-group v-model="form.status">
                <el-radio :label="1">启用</el-radio>
                <el-radio :label="0">停用</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        
        <!-- 经济分类明细 -->
        <el-divider content-position="left">经济分类明细</el-divider>
        <el-table :data="form.detailList" border style="margin-bottom: 20px">
          <el-table-column label="序号" type="index" width="60" align="center" />
          <el-table-column label="经济分类" align="center" width="250">
            <template slot-scope="scope">
              <el-select v-model="scope.row.economyCategory" placeholder="请选择" style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_economy_category"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                  style="white-space: normal; line-height: 1.5;"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="总金额（元）" align="center">
            <template slot-scope="scope">
              <el-input-number 
                v-model="scope.row.totalAmount" 
                :precision="2" 
                :min="0" 
                :max="999999999" 
                placeholder="请输入金额"
                style="width: 100%" 
              />
            </template>
          </el-table-column>
          <el-table-column label="已分配指标" align="center" width="150" v-if="form.id">
            <template slot-scope="scope">
              <span style="color: #E6A23C;">¥{{ parseFloat(scope.row.allocatedAmount || 0).toFixed(2) }}</span>
            </template>
          </el-table-column>
          <el-table-column label="备注" align="center">
            <template slot-scope="scope">
              <el-input v-model="scope.row.memo" placeholder="选填" maxlength="200" />
            </template>
          </el-table-column>
          <el-table-column label="操作" align="center" width="100">
            <template slot-scope="scope">
              <el-button
                type="text"
                icon="el-icon-delete"
                size="mini"
                @click="handleDeleteDetail(scope.$index)"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-button type="primary" icon="el-icon-plus" size="small" @click="handleAddDetail">添加经济分类</el-button>

        <el-form-item label="备注" prop="memo">
          <el-input v-model="form.memo" type="textarea" placeholder="请输入备注" :rows="2" maxlength="500" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 详情对话框 -->
    <el-dialog title="指标明细" :visible.sync="viewOpen" width="1000px" append-to-body>
      <el-descriptions :column="2" border>
        <el-descriptions-item label="学年学期">
          {{ viewData.schoolYear }} {{ viewData.semester === 1 ? '第一学期' : '第二学期' }}
        </el-descriptions-item>
        <el-descriptions-item label="发文时间">{{ viewData.issueDate }}</el-descriptions-item>
        <el-descriptions-item label="上级文号">{{ viewData.superiorDocNo }}</el-descriptions-item>
        <el-descriptions-item label="指标文号">{{ viewData.quotaDocNo }}</el-descriptions-item>
        <el-descriptions-item label="指标文标题" :span="2">{{ viewData.quotaDocTitle }}</el-descriptions-item>
        <el-descriptions-item label="预算项目编码">{{ viewData.budgetProjectCode }}</el-descriptions-item>
        <el-descriptions-item label="预算项目名称">{{ viewData.budgetProjectName }}</el-descriptions-item>
        <el-descriptions-item label="指标摘要" :span="2">{{ viewData.quotaSummary }}</el-descriptions-item>
        <el-descriptions-item label="功能分类">
          <dict-tag :options="dict.type.sys_function_category" :value="viewData.functionCategory"/>
        </el-descriptions-item>
        <el-descriptions-item label="预算来源">
          <dict-tag :options="dict.type.sys_budget_source" :value="viewData.budgetSource"/>
        </el-descriptions-item>
        <el-descriptions-item label="预算级次">
          <dict-tag :options="dict.type.sys_budget_level" :value="viewData.budgetLevel"/>
        </el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="viewData.status == 1 ? 'success' : 'danger'">
            {{ viewData.status == 1 ? '启用' : '停用' }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="备注" :span="2">{{ viewData.memo }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{ viewData.createTime }}</el-descriptions-item>
        <el-descriptions-item label="更新时间">{{ viewData.updateTime }}</el-descriptions-item>
      </el-descriptions>
      
      <!-- 经济分类明细 -->
      <el-divider content-position="left">经济分类明细</el-divider>
      <el-table :data="viewData.detailList" border v-if="viewData.detailList && viewData.detailList.length > 0">
        <el-table-column label="序号" type="index" width="60" align="center" />
        <el-table-column label="经济分类" align="center" width="200">
          <template slot-scope="scope">
            <dict-tag :options="dict.type.sys_economy_category" :value="scope.row.economyCategory" style="white-space: normal; line-height: 1.5;"/>
          </template>
        </el-table-column>
        <el-table-column label="总金额" align="center" width="150">
          <template slot-scope="scope">
            <span style="color: #E6A23C; font-weight: bold;">¥{{ parseFloat(scope.row.totalAmount || 0).toFixed(2) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="已分配指标" align="center" width="150">
          <template slot-scope="scope">
            <span style="color: #409EFF;">¥{{ parseFloat(scope.row.allocatedAmount || 0).toFixed(2) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="指标结余" align="center" width="150">
          <template slot-scope="scope">
            <span :style="{color: scope.row.availableAmount > 0 ? '#67C23A' : '#F56C6C', fontWeight: 'bold'}">
              ¥{{ parseFloat(scope.row.availableAmount || 0).toFixed(2) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="备注" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            {{ scope.row.memo || '-' }}
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-else description="暂无经济分类明细" :image-size="100"></el-empty>
      
      <div slot="footer" class="dialog-footer">
        <el-button @click="viewOpen = false">关 闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listSubsidyQuotaWithUsage, getSubsidyQuota, delSubsidyQuota, addSubsidyQuota, updateSubsidyQuota } from "@/api/system/subsidyQuota";
import { listYearSemesters } from "@/api/system/yearSemester";

export default {
  name: "SubsidyQuota",
  dicts: ['sys_function_category', 'sys_economy_category', 'sys_budget_source', 'sys_budget_level', 'sys_quota_doc_title', 'sys_budget_project_name'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 指标下达表格数据
      quotaList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 是否显示详情弹出层
      viewOpen: false,
      // 详情数据
      viewData: {},
      // 学年学期选项
      yearSemesterOptions: [],
      // 指标文标题选项（字典数据）
      quotaTitleOptions: [],
      // 预算项目名称选项（字典数据）
      budgetProjectNameOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        yearSemesterId: null,
        quotaDocNo: null,
        functionCategory: null,
        status: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        yearSemesterId: [
          { required: true, message: "学年学期不能为空", trigger: "change" }
        ],
        issueDate: [
          { required: true, message: "发文时间不能为空", trigger: "change" }
        ],
        quotaDocTitle: [
          { required: true, message: "指标文标题不能为空", trigger: "blur" }
        ],
        detailList: [
          { type: 'array', required: true, message: "至少添加一个经济分类明细", trigger: "change" }
        ]
      }
    };
  },
  created() {
    this.getList();
    this.getYearSemesterList();
  },
  watch: {
    // 监听指标文标题字典数据加载完成
    'dict.type.sys_quota_doc_title': {
      handler(newVal) {
        if (newVal && newVal.length > 0) {
          this.loadQuotaTitles();
        }
      },
      immediate: true,
      deep: true
    },
    // 监听预算项目名称字典数据加载完成
    'dict.type.sys_budget_project_name': {
      handler(newVal) {
        if (newVal && newVal.length > 0) {
          this.loadBudgetProjectNames();
        }
      },
      immediate: true,
      deep: true
    }
  },
  methods: {
    /** 查询指标下达列表 */
    getList() {
      this.loading = true;
      listSubsidyQuotaWithUsage(this.queryParams).then(response => {
        this.quotaList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    /** 获取学年学期列表 */
    getYearSemesterList() {
      // 只获取状态为"进行中"的学年学期 (status=1)
      // 不分页，获取所有数据
      listYearSemesters({status: 1, pageNum: 1, pageSize: 100}).then(response => {
        this.yearSemesterOptions = response.rows || [];
      });
    },
    /** 加载指标文标题字典 */
    loadQuotaTitles() {
      // 从字典中获取指标文标题选项
      if (this.dict.type.sys_quota_doc_title && this.dict.type.sys_quota_doc_title.length > 0) {
        this.quotaTitleOptions = this.dict.type.sys_quota_doc_title.map(item => ({
          value: item.label,
          label: item.label,
          data: item
        }));
      }
    },
    /** 查询指标文标题（模糊搜索） */
    queryQuotaTitles(queryString, cb) {
      let results = this.quotaTitleOptions;
      
      if (queryString) {
        // 模糊搜索：包含关键字即可
        results = this.quotaTitleOptions.filter(item => 
          item.value.includes(queryString)
        );
      }
      
      // 调用 callback 返回建议列表的数据
      cb(results);
    },
    /** 选择指标文标题后的处理 */
    handleQuotaTitleSelect(item) {
      this.form.quotaDocTitle = item.value;
    },
    /** 加载预算项目名称字典 */
    loadBudgetProjectNames() {
      if (this.dict.type.sys_budget_project_name && this.dict.type.sys_budget_project_name.length > 0) {
        this.budgetProjectNameOptions = this.dict.type.sys_budget_project_name.map(item => ({
          value: item.label,
          label: item.label,
          data: item
        }));
      }
    },
    /** 查询预算项目名称（模糊搜索） */
    queryBudgetProjectNames(queryString, cb) {
      let results = this.budgetProjectNameOptions;
      
      if (queryString) {
        results = this.budgetProjectNameOptions.filter(item => 
          item.value.includes(queryString)
        );
      }
      
      cb(results);
    },
    /** 选择预算项目名称后的处理 */
    handleBudgetProjectNameSelect(item) {
      this.form.budgetProjectName = item.value;
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        yearSemesterId: null,
        issueDate: null,
        superiorDocNo: null,
        quotaDocTitle: null,
        quotaDocNo: null,
        budgetProjectCode: null,
        budgetProjectName: null,
        quotaSummary: null,
        functionCategory: null,
        budgetSource: null,
        budgetLevel: null,
        status: 1,
        memo: null,
        detailList: []  // 明细列表
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      // 默认添加一个空明细
      this.form.detailList = [{ economyCategory: null, totalAmount: null, memo: null }];
      this.open = true;
      this.title = "添加指标下达";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getSubsidyQuota(id).then(response => {
        this.form = response.data;
        // 如果没有明细列表，初始化为空数组
        if (!this.form.detailList || this.form.detailList.length === 0) {
          this.form.detailList = [{ economyCategory: null, totalAmount: null, memo: null }];
        }
        this.open = true;
        this.title = "修改指标下达";
      });
    },
    /** 查看详情 */
    handleView(row) {
      getSubsidyQuota(row.id).then(response => {
        this.viewData = response.data;
        this.viewOpen = true;
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          // 验证明细列表
          if (!this.form.detailList || this.form.detailList.length === 0) {
            this.$modal.msgWarning("请至少添加一个经济分类明细");
            return;
          }
          
          // 验证每个明细是否完整
          for (let i = 0; i < this.form.detailList.length; i++) {
            const detail = this.form.detailList[i];
            if (!detail.economyCategory) {
              this.$modal.msgWarning(`第 ${i + 1} 条明细请选择经济分类`);
              return;
            }
            if (!detail.totalAmount || detail.totalAmount <= 0) {
              this.$modal.msgWarning(`第 ${i + 1} 条明细请输入总金额`);
              return;
            }
          }
          
          // 验证经济分类不能重复
          const categories = this.form.detailList.map(d => d.economyCategory);
          const uniqueCategories = [...new Set(categories)];
          if (categories.length !== uniqueCategories.length) {
            this.$modal.msgWarning("经济分类不能重复，请检查");
            return;
          }
          
          if (this.form.id != null) {
            updateSubsidyQuota(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addSubsidyQuota(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除指标下达编号为"' + ids + '"的数据项？').then(function() {
        return delSubsidyQuota(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/subsidyQuota/export', {
        ...this.queryParams
      }, `subsidy_quota_${new Date().getTime()}.xlsx`)
    },
    /** 添加经济分类明细 */
    handleAddDetail() {
      this.form.detailList.push({
        economyCategory: null,
        totalAmount: null,
        memo: null
      });
    },
    /** 删除经济分类明细 */
    handleDeleteDetail(index) {
      this.form.detailList.splice(index, 1);
    },
    /** 获取字典标签 */
    getDictLabel(dictOptions, value) {
      if (!dictOptions || !value) return '-';
      const dict = dictOptions.find(item => item.value === value);
      return dict ? dict.label : value;
    }
  }
};
</script>
