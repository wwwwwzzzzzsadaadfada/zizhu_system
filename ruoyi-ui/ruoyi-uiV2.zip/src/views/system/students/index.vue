<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学年学期" prop="yearSemesterId">
        <el-select v-model="queryParams.yearSemesterId" placeholder="请选择学年学期" clearable style="width: 200px">
          <el-option
            v-for="item in yearSemesterOptions"
            :key="item.id"
            :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="姓名" prop="name">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入姓名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="身份证号" prop="idCardNo">
        <el-input
          v-model="queryParams.idCardNo"
          placeholder="请输入身份证号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="民族" prop="ethnicity">
        <el-select v-model="queryParams.ethnicity" placeholder="请选择民族" clearable>
          <el-option
            v-for="dict in dict.type.sys_student_ethnicity"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="所属年级" prop="gradeId">
        <el-select v-model="queryParams.gradeId" placeholder="请选择年级" clearable>
          <el-option
            v-for="item in allGradeOptions"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="困难类型" prop="difficultyTypeId">
        <el-select v-model="queryParams.difficultyTypeId" placeholder="请选择困难类型" clearable>
          <el-option
            v-for="dict in dict.type.sys_difficulty_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:students:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['system:students:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:students:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:students:export']"
        >导出</el-button>
      </el-col>
      <!-- 添加同步学生按钮 -->
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-refresh"
          size="mini"
          @click="handleSync"
          v-hasPermi="['system:students:add']"
        >同步学生</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="studentsList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="id" width="80" />
      <el-table-column label="学年" align="center" prop="schoolYear" width="110" />
      <el-table-column label="学期" align="center" prop="semester" width="100">
        <template slot-scope="scope">
          {{ scope.row.semester === 1 ? '第一学期' : '第二学期' }}
        </template>
      </el-table-column>
      <el-table-column label="姓名" align="center" prop="name" width="100" />
      <el-table-column label="身份证号" align="center" prop="idCardNo" width="160" show-overflow-tooltip />
      <el-table-column label="性别" align="center" prop="gender" width="70">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_student_gender" :value="scope.row.gender"/>
        </template>
      </el-table-column>
      <el-table-column label="民族" align="center" prop="ethnicity" width="80">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_student_ethnicity" :value="scope.row.ethnicity"/>
        </template>
      </el-table-column>
      <el-table-column label="户籍所在地" align="center" prop="domicile" width="180" show-overflow-tooltip>
        <template slot-scope="scope">
          {{ formatDomicile(scope.row.domicile) }}
        </template>
      </el-table-column>
      <el-table-column label="学籍号" align="center" prop="studentNo" width="140" show-overflow-tooltip />
      <el-table-column label="所属学制" align="center" prop="schoolingYears" width="100">
        <template slot-scope="scope">
          {{ scope.row.schoolingYears }}年制
        </template>
      </el-table-column>
      <el-table-column label="所属年级" align="center" prop="gradeName" width="100" />
      <el-table-column label="所属班级" align="center" prop="className" width="100" />
      <el-table-column label="就读状态" align="center" prop="studyStatus" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_study_status" :value="scope.row.studyStatus"/>
        </template>
      </el-table-column>
      <el-table-column label="困难类型" align="center" prop="difficultyTypeId" width="140">
        <template slot-scope="scope">
          <span v-if="scope.row.difficultyTypeId === '1' && scope.row.povertyReliefYear">
            {{ scope.row.povertyReliefYear }}年脱贫户
          </span>
          <span v-else>
            {{ getDictLabel(dict.type.sys_difficulty_type, scope.row.difficultyTypeId) }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="困难等级" align="center" prop="difficultyLevelId" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_difficulty_level" :value="scope.row.difficultyLevelId"/>
        </template>
      </el-table-column>
      <el-table-column label="备注" align="center" prop="memo" width="150" show-overflow-tooltip />
      <el-table-column label="操作" align="center" width="150" fixed="right">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:students:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:students:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改困难学生基础信息对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="1000px" append-to-body :close-on-click-modal="false">
      <el-form ref="form" :model="form" :rules="rules" label-width="110px">
        <!-- 学期信息 -->
        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-date"></i>
            <span>学期信息</span>
          </div>
          <el-row :gutter="20">
            <el-col :span="8">
              <el-form-item label="学年学期" prop="yearSemesterId">
                <el-select v-model="form.yearSemesterId" placeholder="请选择学年学期" style="width: 100%">
                  <el-option
                    v-for="item in yearSemesterOptions"
                    :key="item.id"
                    :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
                    :value="item.id"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-card>

        <!-- 基本信息 -->
        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-user"></i>
            <span>基本信息</span>
          </div>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="姓名" prop="name">
              <el-input v-model="form.name" placeholder="请输入姓名" maxlength="50" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="性别" prop="gender">
              <el-select v-model="form.gender" placeholder="请选择性别" style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_student_gender"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="民族" prop="ethnicity">
              <el-select v-model="form.ethnicity" placeholder="请选择民族" filterable style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_student_ethnicity"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="身份证号" prop="idCardNo">
              <el-input v-model="form.idCardNo" placeholder="请输入18位身份证号" maxlength="18" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学籍号" prop="studentNo">
              <el-input v-model="form.studentNo" placeholder="请输入学籍号" maxlength="32" />
            </el-form-item>
          </el-col>
        </el-row>
        </el-card>

        <!-- 户籍信息 -->
        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-location"></i>
            <span>户籍信息</span>
          </div>
        <el-row :gutter="20">
          <el-col :span="24">
            <el-form-item label="户籍所在地" prop="domicile">
              <!-- 编辑时显示原有地址 -->
              <div v-if="form.id && form.domicile && !isEditingAddress" style="display: flex; align-items: center;">
                <el-input 
                  :value="form.domicile" 
                  readonly
                  style="width: 70%"
                />
                <el-button 
                  type="text" 
                  icon="el-icon-edit" 
                  style="margin-left: 10px;"
                  @click="isEditingAddress = true"
                >修改地址</el-button>
              </div>
              <!-- 新增或修改地址时显示级联选择器 -->
              <div v-else>
                <el-cascader
                  v-model="form.regionCodes"
                  :options="guangxiRegions"
                  :props="{ 
                    value: 'value', 
                    label: 'label', 
                    children: 'children',
                    checkStrictly: true,
                    expandTrigger: 'hover'
                  }"
                  placeholder="请选择市/县/乡镇"
                  clearable
                  filterable
                  style="width: 40%"
                  @change="handleRegionChange"
                />
                <el-input 
                  v-model="form.village" 
                  placeholder="请输入村/社区" 
                  maxlength="50"
                  style="width: 28%; margin-left: 10px"
                />
                <el-input 
                  v-model="form.hamlet" 
                  placeholder="请输入屯/组" 
                  maxlength="50"
                  style="width: 28%; margin-left: 10px"
                />
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        </el-card>

        <!-- 学籍信息 -->
        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-reading"></i>
            <span>学籍信息</span>
          </div>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="所属学制" prop="schoolingPlanId">
              <el-select v-model="form.schoolingPlanId" placeholder="请选择学制" @change="handleSchoolPlanChange" style="width: 100%">
                <el-option
                  v-for="item in schoolPlanOptions"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="所属年级" prop="gradeId">
              <el-select v-model="form.gradeId" placeholder="请选择年级" @change="handleGradeChange" style="width: 100%" :disabled="!form.schoolingPlanId">
                <el-option
                  v-for="item in gradeOptions"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="所属班级" prop="classId">
              <el-select v-model="form.classId" placeholder="请选择班级" style="width: 100%" :disabled="!form.gradeId">
                <el-option
                  v-for="item in classOptions"
                  :key="item.classId"
                  :label="item.className"
                  :value="item.classId"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="24">
            <el-form-item label="就读状态" prop="studyStatus">
              <el-select v-model="form.studyStatus" placeholder="请选择就读状态" style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_study_status"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        </el-card>

        <!-- 困难认定 -->
        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-warning-outline"></i>
            <span>困难认定</span>
          </div>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="困难类型" prop="difficultyTypeId">
              <el-select v-model="form.difficultyTypeId" placeholder="请选择困难类型" style="width: 100%" @change="handleDifficultyTypeChange">
                <el-option
                  v-for="dict in dict.type.sys_difficulty_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="困难等级" prop="difficultyLevelId">
              <el-select v-model="form.difficultyLevelId" placeholder="请选择困难等级" style="width: 100%">
                <el-option
                  v-for="dict in dict.type.sys_difficulty_level"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20" v-if="showPovertyReliefYear">
          <el-col :span="12">
            <el-form-item label="脱贫年份" prop="povertyReliefYear">
              <el-date-picker
                v-model="form.povertyReliefYear"
                type="year"
                placeholder="请选择脱贫年份"
                value-format="yyyy"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>
        </el-row>
        </el-card>

        <!-- 备注信息 -->
        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-edit-outline"></i>
            <span>备注信息</span>
          </div>
        <el-row :gutter="20">
          <el-col :span="24">
            <el-form-item label="备注" prop="memo">
              <el-input 
                v-model="form.memo" 
                type="textarea" 
                :rows="3"
                placeholder="请输入备注信息" 
                maxlength="500"
                show-word-limit
              />
            </el-form-item>
          </el-col>
        </el-row>
        </el-card>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { 
  listStudentRecords, getStudentRecord, delStudentRecords, addStudentRecord, updateStudentRecord,
  listStudentsBase, getStudentsBase, addStudentsBase, updateStudentsBase,
  getSchoolPlanList, getGradeList, getClassList,
  syncStudents
} from "@/api/system/studentRecord"
import { listYearSemesters } from "@/api/system/baseconfig"
import guangxiRegions from "@/assets/data/guangxi-region.js"

export default {
  name: "Students",
  dicts: ['sys_student_gender', 'sys_student_ethnicity', 'sys_study_status', 'sys_difficulty_type', 'sys_difficulty_level'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 困难学生基础信息表格数据
      studentsList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 学年学期选项
      yearSemesterOptions: [],
      // 学制选项
      schoolPlanOptions: [],
      // 年级选项
      gradeOptions: [],
      // 所有年级选项（用于查询条件）
      allGradeOptions: [],
      // 班级选项
      classOptions: [],
      // 广西行政区划数据
      guangxiRegions: guangxiRegions,
      // 是否正在编辑地址
      isEditingAddress: false,
      // 是否显示脱贫年份字段
      showPovertyReliefYear: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        yearSemesterId: null,
        name: null,
        idCardNo: null,
        ethnicity: null,
        gradeId: null,
        difficultyTypeId: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        yearSemesterId: [
          { required: true, message: "学年学期不能为空", trigger: "change" }
        ],
        name: [
          { required: true, message: "姓名不能为空", trigger: "blur" }
        ],
        idCardNo: [
          { required: true, message: "身份证号不能为空", trigger: "blur" },
          { validator: this.validateIdCardNo, trigger: "blur" }
        ],
        gender: [
          { required: true, message: "性别不能为空", trigger: "blur" }
        ],
        ethnicity: [
          { required: true, message: "民族不能为空", trigger: "change" }
        ],
        domicile: [
          { required: true, message: "户籍所在地不能为空", trigger: "blur" }
        ],
        studentNo: [
          { required: true, message: "学籍号不能为空", trigger: "blur" },
          { validator: this.validateStudentNo, trigger: "blur" }
        ],
        schoolingPlanId: [
          { required: true, message: "所属学制不能为空", trigger: "blur" }
        ],
        gradeId: [
          { required: true, message: "所属年级不能为空", trigger: "blur" }
        ],
        classId: [
          { required: true, message: "所属班级不能为空", trigger: "blur" }
        ],
        studyStatus: [
          { required: true, message: "就读状态不能为空", trigger: "change" }
        ],
        difficultyTypeId: [
          { required: true, message: "困难类型不能为空", trigger: "change" }
        ],
        difficultyLevelId: [
          { required: true, message: "困难等级不能为空", trigger: "change" }
        ]
      }
    }
  },
  created() {
    this.getList();
    this.getYearSemesterList();
    this.getSchoolPlanList();
    this.getAllGradeList();
  },
  methods: {
    /** 查询学年学期列表 */
    getYearSemesterList() {
      listYearSemesters({ status: 1 }).then(response => {
        this.yearSemesterOptions = response.rows || response.data || [];
        // 默认选中当前学期
        const currentSemester = this.yearSemesterOptions.find(item => item.isCurrent === 1);
        if (currentSemester) {
          this.queryParams.yearSemesterId = currentSemester.id;
          this.form.yearSemesterId = currentSemester.id;
        }
      });
    },
    /** 验证身份证号唯一性 */
    validateIdCardNo(rule, value, callback) {
      if (!value) {
        callback();
        return;
      }
      
      // 如果是编辑模式，且身份证号没有变化，则不验证
      if (this.form.id) {
        callback();
        return;
      }
      
      // 检查身份证号是否已存在
      listStudentsBase({ idCardNo: value }).then(response => {
        if (response.rows && response.rows.length > 0) {
          callback(new Error('该身份证号已存在，请检查'));
        } else {
          callback();
        }
      }).catch(() => {
        callback();
      });
    },
    /** 验证学籍号唯一性 */
    validateStudentNo(rule, value, callback) {
      if (!value) {
        callback();
        return;
      }
      
      // 如果是编辑模式，且学籍号没有变化，则不验证
      if (this.form.id) {
        callback();
        return;
      }
      
      // 检查学籍号是否已存在
      listStudentsBase({ studentNo: value }).then(response => {
        if (response.rows && response.rows.length > 0) {
          callback(new Error('该学籍号已存在，请检查'));
        } else {
          callback();
        }
      }).catch(() => {
        callback();
      });
    },
    /** 查询困难学生基础信息列表 */
    getList() {
      this.loading = true
      listStudentRecords(this.queryParams).then(response => {
        this.studentsList = response.rows
        this.total = response.total
        this.loading = false
      })
    },
    // 取消按钮
    cancel() {
      this.open = false
      this.reset()
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        yearSemesterId: null,
        studentBaseId: null,
        name: null,
        idCardNo: null,
        gender: null,
        ethnicity: null,
        domicile: null,
        regionCodes: [],
        village: null,
        hamlet: null,
        studentNo: null,
        schoolingPlanId: null,
        gradeId: null,
        classId: null,
        studyStatus: null,
        difficultyTypeId: null,
        difficultyLevelId: null,
        povertyReliefYear: null,
        memo: null
      }
      this.isEditingAddress = false
      this.showPovertyReliefYear = false
      this.gradeOptions = []
      this.classOptions = []
      this.resetForm("form")
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1
      this.getList()
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm")
      this.handleQuery()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset()
      this.open = true
      this.title = "添加困难学生基础信息"
      // 清空级联选项
      this.gradeOptions = []
      this.classOptions = []
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset()
      const id = row.id || this.ids
      getStudentRecord(id).then(response => {
        this.form = response.data
        // 编辑时，默认显示原有地址，不显示级联选择器
        this.isEditingAddress = false
        // 判断是否显示脱贫年份
        this.showPovertyReliefYear = this.form.difficultyTypeId === '1'
        // 如果有学制ID，加载对应的年级列表
        if (this.form.schoolingPlanId) {
          getGradeList(this.form.schoolingPlanId).then(res => {
            this.gradeOptions = res.data || []
          }).catch(error => {
            console.error('获取年级列表失败:', error)
            this.gradeOptions = []
          })
        }
        // 如果有年级ID，加载对应的班级列表
        if (this.form.gradeId) {
          getClassList(this.form.gradeId).then(res => {
            this.classOptions = res.data || []
          }).catch(error => {
            console.error('获取班级列表失败:', error)
            this.classOptions = []
          })
        }
        this.open = true
        this.title = "修改困难学生基础信息"
      }).catch(error => {
        console.error('获取学生记录失败:', error)
        this.$modal.msgError('获取学生记录失败')
      })
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          // 只有在新增或修改地址时才拼接完整的户籍地址
          if (!this.form.id || this.isEditingAddress) {
            if (this.form.domicile) {
              let fullAddress = this.form.domicile;
              if (this.form.village) {
                fullAddress += this.form.village;
              }
              if (this.form.hamlet) {
                fullAddress += this.form.hamlet;
              }
              this.form.domicile = fullAddress;
            }
          }
          
          if (this.form.id != null) {
            updateStudentRecord(this.form).then(response => {
              this.$modal.msgSuccess("修改成功")
              this.open = false
              this.getList()
            })
          } else {
            addStudentRecord(this.form).then(response => {
              this.$modal.msgSuccess("新增成功")
              this.open = false
              this.getList()
            })
          }
        }
      })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids
      this.$modal.confirm('是否确认删除困难学生基础信息编号为"' + ids + '"的数据项？').then(function() {
        return delStudentRecords(ids)
      }).then(() => {
        this.getList()
        this.$modal.msgSuccess("删除成功")
      }).catch(() => {})
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/students/export', {
        ...this.queryParams
      }, `students_${new Date().getTime()}.xlsx`)
    },
    /** 获取学制列表 */
    getSchoolPlanList() {
      getSchoolPlanList().then(response => {
        this.schoolPlanOptions = response.data;
      });
    },
    /** 获取所有年级列表（用于查询条件） */
    getAllGradeList() {
      // 调用基础配置的年级接口获取所有年级
      import('@/api/system/baseconfig').then(module => {
        module.listGrades().then(response => {
          this.allGradeOptions = response.data;
        });
      });
    },
    /** 学制改变时触发 */
    handleSchoolPlanChange(value) {
      // 清空年级和班级选择
      this.form.gradeId = null;
      this.form.classId = null;
      this.gradeOptions = [];
      this.classOptions = [];
      
      // 如果选择了学制，则加载对应的年级列表
      if (value) {
        getGradeList(value).then(response => {
          this.gradeOptions = response.data || [];
        }).catch(error => {
          console.error('获取年级列表失败:', error);
          this.$modal.msgError('获取年级列表失败');
        });
      }
    },
    /** 年级改变时触发 */
    handleGradeChange(value) {
      this.form.classId = null;
      this.classOptions = [];
      if (value) {
        getClassList(value).then(response => {
          this.classOptions = response.data;
        });
      }
    },
    /** 行政区划改变时触发 */
    handleRegionChange(value) {
      // value 是数组，如 ['450100', '450102', '450102001']
      if (value && value.length > 0) {
        // 获取选中的各级名称
        const labels = this.getRegionLabels(value);
        // 拼接完整地址：广西壮族自治区 + 市 + 县 + 乡镇
        const baseAddress = '广西壮族自治区' + labels.join('');
        // 如果有村和屯，会在提交时拼接
        this.form.domicile = baseAddress;
      } else {
        this.form.domicile = null;
      }
    },
    /** 获取区划名称 */
    getRegionLabels(codes) {
      const labels = [];
      let currentLevel = this.guangxiRegions;
      
      for (let i = 0; i < codes.length; i++) {
        const code = codes[i];
        const item = currentLevel.find(region => region.value === code);
        if (item) {
          labels.push(item.label);
          currentLevel = item.children || [];
        }
      }
      
      return labels;
    },
    /** 困难类型变化事件 */
    handleDifficultyTypeChange(value) {
      // 如果选择的是"脱贫户"（value=1），显示脱贫年份字段
      this.showPovertyReliefYear = value === '1'
      // 如果不是脱贫户，清空脱贫年份
      if (!this.showPovertyReliefYear) {
        this.form.povertyReliefYear = null
      }
    },
    /** 获取字典标签 */
    getDictLabel(dictOptions, value) {
      if (!dictOptions || !value) return ''
      const dict = dictOptions.find(item => item.value === value)
      return dict ? dict.label : value
    },
    /** 格式化户籍所在地，隐藏"自治区"等字样 */
    formatDomicile(domicile) {
      if (!domicile) return ''
      // 移除常见的行政区划后缀和民族名称
      return domicile
        .replace(/壮族/g, '')
        .replace(/回族/g, '')
        .replace(/维吾尔/g, '')
        .replace(/自治区/g, '')
        .replace(/省/g, '')
        .replace(/特别行政区/g, '')
    },
    /** 同步学生按钮操作 */
    handleSync() {
      if (!this.queryParams.yearSemesterId) {
        this.$modal.msgWarning("请先选择学年学期");
        return;
      }
      this.$modal.confirm('是否确认同步当前学年学期的学生数据？').then(() => {
        return syncStudents(this.queryParams.yearSemesterId);
      }).then((response) => {
        this.getList();
        this.$modal.msgSuccess(response.msg || "同步成功");
      }).catch(() => {});
    }
  }
}
</script>

<style scoped lang="scss">
// 表单卡片样式
.form-card {
  margin-bottom: 20px;
  border-radius: 8px;
  border: 1px solid #e4e7ed;
  
  ::v-deep .el-card__header {
    padding: 12px 20px;
    background: #f5f7fa;
    border-bottom: 1px solid #e4e7ed;
  }
  
  ::v-deep .el-card__body {
    padding: 20px;
  }
  
  &:last-of-type {
    margin-bottom: 0;
  }
}

.card-header {
  display: flex;
  align-items: center;
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  
  i {
    margin-right: 8px;
    font-size: 16px;
    color: #409EFF;
  }
}

// 对话框样式优化
::v-deep .el-dialog__body {
  padding: 20px;
  max-height: 65vh;
  overflow-y: auto;
}

::v-deep .el-dialog__footer {
  padding: 15px 20px;
  text-align: right;
  border-top: 1px solid #e4e7ed;
}

// 表单项间距
::v-deep .el-form-item {
  margin-bottom: 18px;
}

// 响应式设计
@media (max-width: 768px) {
  ::v-deep .el-dialog {
    width: 95% !important;
  }
}
</style>
