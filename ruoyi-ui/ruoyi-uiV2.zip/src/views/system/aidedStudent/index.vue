<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="90px">
      <el-form-item label="学年学期" prop="yearSemesterId">
        <el-select v-model="queryParams.yearSemesterId" placeholder="请选择学年学期" clearable style="width: 200px">
          <el-option
            v-for="item in yearSemesterOptions"
            :key="item.id"
            :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="学生姓名" prop="studentName">
        <el-input
          v-model="queryParams.studentName"
          placeholder="请输入学生姓名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="身份证号" prop="idCardNo">
        <el-input
          v-model="queryParams.idCardNo"
          placeholder="请输入身份证号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="困难类型" prop="difficultyTypeId">
        <el-select v-model="queryParams.difficultyTypeId" placeholder="请选择困难类型" clearable>
          <el-option
            v-for="dict in dict.type.sys_difficulty_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:aidedStudent:add']"
        >录入受助金额</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleBatchInput"
          v-hasPermi="['system:aidedStudent:edit']"
        >批量录入</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['system:aidedStudent:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="aidedStudentList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="id" width="80" />
      <el-table-column label="学年" align="center" prop="schoolYear" width="110" />
      <el-table-column label="学期" align="center" prop="semester" width="100">
        <template slot-scope="scope">
          {{ scope.row.semester === 1 ? '第一学期' : '第二学期' }}
        </template>
      </el-table-column>
      <el-table-column label="学生姓名" align="center" prop="studentName" width="100" />
      <el-table-column label="身份证号" align="center" prop="idCardNo" width="160" show-overflow-tooltip />
      <el-table-column label="性别" align="center" prop="gender" width="70">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_student_gender" :value="scope.row.gender"/>
        </template>
      </el-table-column>
      <el-table-column label="民族" align="center" prop="ethnicity" width="80">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_student_ethnicity" :value="scope.row.ethnicity"/>
        </template>
      </el-table-column>
      <el-table-column label="所属年级" align="center" prop="gradeName" width="100" />
      <el-table-column label="困难类型" align="center" prop="difficultyTypeName" width="120" />
      <el-table-column label="困难等级" align="center" prop="difficultyLevelName" width="100">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_difficulty_level" :value="scope.row.difficultyLevelId"/>
        </template>
      </el-table-column>
      <el-table-column label="预算项目" align="center" prop="budgetProjectName" width="180" />
      <el-table-column label="经济分类" align="center" prop="economyCategoryName" width="120" />
      <el-table-column label="受助金额" align="center" prop="aidedAmount" width="120">
        <template slot-scope="scope">
          <span 
            style="color: #E6A23C; font-weight: bold; cursor: pointer;" 
            @click="handleInputAmount(scope.row)"
          >
            ¥{{ parseFloat(scope.row.aidedAmount || 0).toFixed(2) }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="录入时间" align="center" prop="createTime" width="160" />
      <el-table-column label="操作" align="center" width="150" fixed="right">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:aidedStudent:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:aidedStudent:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 录入受助金额对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="700px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="110px">
        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-user"></i>
            <span>学生信息</span>
          </div>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="学年学期" prop="yearSemesterId">
                <el-select v-model="form.yearSemesterId" placeholder="请选择学年学期" style="width: 100%" disabled>
                  <el-option
                    v-for="item in yearSemesterOptions"
                    :key="item.id"
                    :label="item.schoolYear + ' ' + (item.semester === 1 ? '第一学期' : '第二学期')"
                    :value="item.id"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="学生姓名" prop="studentName">
                <el-input v-model="form.studentName" placeholder="学生姓名" readonly />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="身份证号" prop="idCardNo">
                <el-input v-model="form.idCardNo" placeholder="身份证号" readonly />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="所属年级" prop="gradeName">
                <el-input v-model="form.gradeName" placeholder="所属年级" readonly />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="困难类型" prop="difficultyTypeName">
                <el-input v-model="form.difficultyTypeName" placeholder="困难类型" readonly />
              </el-form-item>
            </el-col>
          </el-row>
        </el-card>

        <el-card shadow="never" class="form-card">
          <div slot="header" class="card-header">
            <i class="el-icon-money"></i>
            <span>资助信息</span>
          </div>
          <el-row :gutter="20">
            <el-col :span="24">
              <el-form-item label="预算项目" prop="budgetProjectName">
                <el-select 
                  v-model="form.budgetProjectName" 
                  placeholder="请选择预算项目" 
                  style="width: 100%"
                  @change="handleBudgetProjectChange"
                >
                  <el-option
                    v-for="dict in dict.type.sys_budget_project"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="经济分类" prop="economyCategoryId">
                <el-select 
                  v-model="form.economyCategoryId" 
                  placeholder="请选择经济分类" 
                  style="width: 100%"
                  :disabled="!form.budgetProjectName"
                >
                  <el-option
                    v-for="dict in dict.type.sys_economy_category"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="受助金额" prop="aidedAmount">
                <el-input-number 
                  v-model="form.aidedAmount" 
                  placeholder="请输入受助金额" 
                  controls-position="right" 
                  :min="0"
                  :precision="2"
                  :step="100"
                  style="width: 100%"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20" v-if="budgetInfo.availableAmount !== null">
            <el-col :span="24">
              <el-form-item label="预算余额">
                <el-tag :type="budgetInfo.availableAmount > 0 ? 'success' : 'danger'">
                  可用金额: ¥{{ parseFloat(budgetInfo.availableAmount || 0).toFixed(2) }}
                </el-tag>
                <el-tag type="warning" style="margin-left: 10px;">
                  已使用: ¥{{ parseFloat(budgetInfo.usedAmount || 0).toFixed(2) }}
                </el-tag>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="24">
              <el-form-item label="备注" prop="memo">
                <el-input 
                  v-model="form.memo" 
                  type="textarea" 
                  :rows="3"
                  placeholder="请输入备注信息" 
                  maxlength="500"
                  show-word-limit
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-card>
        
        <el-card shadow="never" class="form-card" v-if="formHistory.length > 0">
          <div slot="header" class="card-header">
            <i class="el-icon-time"></i>
            <span>录入历史</span>
          </div>
          <el-table :data="formHistory" size="small" max-height="200">
            <el-table-column label="录入时间" prop="createTime" width="120" />
            <el-table-column label="受助金额" width="120">
              <template slot-scope="scope">
                <span style="color: #E6A23C; font-weight: bold;">¥{{ parseFloat(scope.row.aidedAmount || 0).toFixed(2) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="预算项目" prop="budgetProjectName" show-overflow-tooltip />
          </el-table>
        </el-card>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 批量录入受助金额对话框 -->
    <el-dialog title="批量录入受助金额" :visible.sync="batchOpen" width="1000px" append-to-body>
      <el-steps :active="batchStep" finish-status="success" simple>
        <el-step title="选择学生" />
        <el-step title="录入金额" />
        <el-step title="确认提交" />
      </el-steps>

      <!-- 第一步：选择学生 -->
      <div v-show="batchStep === 0">
        <el-alert
          title="请选择需要批量录入受助金额的学生"
          type="info"
          show-icon
          style="margin-bottom: 20px;"
        />
        <el-table 
          :data="batchStudentList" 
          height="300" 
          @selection-change="handleBatchSelectionChange"
          ref="batchStudentTable"
        >
          <el-table-column type="selection" width="55" align="center" />
          <el-table-column label="学生姓名" align="center" prop="studentName" width="100" />
          <el-table-column label="身份证号" align="center" prop="idCardNo" width="160" show-overflow-tooltip />
          <el-table-column label="所属年级" align="center" prop="gradeName" width="100" />
          <el-table-column label="困难类型" align="center" prop="difficultyTypeName" width="120" />
        </el-table>
        <div style="margin-top: 15px; text-align: right;">
          <el-pagination
            :total="batchTotal"
            :page.sync="batchQueryParams.pageNum"
            :limit.sync="batchQueryParams.pageSize"
            @pagination="getBatchStudentList"
            layout="total, prev, pager, next"
            small
          />
        </div>
      </div>

      <!-- 第二步：录入金额 -->
      <div v-show="batchStep === 1">
        <el-alert
          title="请为选中的学生录入受助金额"
          type="info"
          show-icon
          style="margin-bottom: 20px;"
        />
        <el-row :gutter="20">
          <el-col :span="18">
            <el-form :model="batchForm" :rules="batchRules" ref="batchForm" label-width="110px">
              <el-card shadow="never" class="form-card">
                <div slot="header" class="card-header">
                  <i class="el-icon-money"></i>
                  <span>统一设置</span>
                </div>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="预算项目" prop="budgetProjectName">
                      <el-select 
                        v-model="batchForm.budgetProjectName" 
                        placeholder="请选择预算项目" 
                        style="width: 100%"
                        @change="handleBatchBudgetProjectChange"
                      >
                        <el-option
                          v-for="dict in dict.type.sys_budget_project"
                          :key="dict.value"
                          :label="dict.label"
                          :value="dict.value"
                        />
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="经济分类" prop="economyCategoryId">
                      <el-select 
                        v-model="batchForm.economyCategoryId" 
                        placeholder="请选择经济分类" 
                        style="width: 100%"
                        :disabled="!batchForm.budgetProjectName"
                      >
                        <el-option
                          v-for="dict in dict.type.sys_economy_category"
                          :key="dict.value"
                          :label="dict.label"
                          :value="dict.value"
                        />
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="受助金额" prop="aidedAmount">
                      <el-input-number 
                        v-model="batchForm.aidedAmount" 
                        placeholder="请输入受助金额" 
                        controls-position="right" 
                        :min="0"
                        :precision="2"
                        :step="100"
                        style="width: 100%"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-card>

              <el-card shadow="never" class="form-card">
                <div slot="header" class="card-header">
                  <i class="el-icon-user"></i>
                  <span>个别调整</span>
                  <span style="float: right; color: #909399; font-size: 12px;">选中{{ selectedBatchStudents.length }}名学生</span>
                </div>
                <el-table :data="selectedBatchStudents" max-height="250">
                  <el-table-column label="学生姓名" align="center" prop="studentName" width="100" />
                  <el-table-column label="身份证号" align="center" prop="idCardNo" width="160" show-overflow-tooltip />
                  <el-table-column label="所属年级" align="center" prop="gradeName" width="100" />
                  <el-table-column label="受助金额" align="center" width="150">
                    <template slot-scope="scope">
                      <el-input-number 
                        v-model="scope.row.aidedAmount" 
                        controls-position="right" 
                        :min="0"
                        :precision="2"
                        :step="100"
                        style="width: 100%"
                        size="small"
                      />
                    </template>
                  </el-table-column>
                </el-table>
              </el-card>
            </el-form>
          </el-col>
          
          <el-col :span="6">
            <el-card shadow="never" class="form-card">
              <div slot="header" class="card-header">
                <i class="el-icon-info"></i>
                <span>批量操作说明</span>
              </div>
              <div class="operation-guide">
                <h4>操作步骤</h4>
                <ul>
                  <li>选择预算项目和经济分类</li>
                  <li>设置统一金额或个别调整</li>
                  <li>确认信息后提交</li>
                </ul>
                <h4>注意事项</h4>
                <ul>
                  <li>批量操作不可逆，请谨慎操作</li>
                  <li>确保预算余额充足</li>
                  <li>操作完成后可导出记录核对</li>
                </ul>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>

      <!-- 第三步：确认提交 -->
      <div v-show="batchStep === 2">
        <el-alert
          title="请确认录入信息无误后提交"
          type="info"
          show-icon
          style="margin-bottom: 20px;"
        />
        <el-row :gutter="20">
          <el-col :span="18">
            <el-descriptions :column="2" border size="small">
              <el-descriptions-item label="预算项目">{{ getDictLabel(dict.type.sys_budget_project, batchForm.budgetProjectName) }}</el-descriptions-item>
              <el-descriptions-item label="经济分类">{{ getDictLabel(dict.type.sys_economy_category, batchForm.economyCategoryId) }}</el-descriptions-item>
              <el-descriptions-item label="统一金额">¥{{ parseFloat(batchForm.aidedAmount || 0).toFixed(2) }}</el-descriptions-item>
              <el-descriptions-item label="学生数量">{{ selectedBatchStudents.length }}人</el-descriptions-item>
            </el-descriptions>

            <el-table :data="selectedBatchStudents" max-height="250" style="margin-top: 20px;">
              <el-table-column label="学生姓名" align="center" prop="studentName" width="100" />
              <el-table-column label="身份证号" align="center" prop="idCardNo" width="160" show-overflow-tooltip />
              <el-table-column label="所属年级" align="center" prop="gradeName" width="100" />
              <el-table-column label="困难类型" align="center" prop="difficultyTypeName" width="120" />
              <el-table-column label="受助金额" align="center" prop="aidedAmount" width="120">
                <template slot-scope="scope">
                  <span style="color: #E6A23C; font-weight: bold;">¥{{ parseFloat(scope.row.aidedAmount || 0).toFixed(2) }}</span>
                </template>
              </el-table-column>
            </el-table>
          </el-col>
          
          <el-col :span="6">
            <el-card shadow="never" class="form-card">
              <div slot="header" class="card-header">
                <i class="el-icon-warning"></i>
                <span>提交确认</span>
              </div>
              <div class="operation-guide">
                <h4>重要提醒</h4>
                <ul>
                  <li>提交后将无法撤回</li>
                  <li>系统将自动扣减预算余额</li>
                  <li>请仔细核对所有信息</li>
                </ul>
                <el-checkbox v-model="batchConfirmChecked" style="margin-top: 20px;">
                  我已确认信息无误
                </el-checkbox>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>

      <div slot="footer" class="dialog-footer">
        <el-button @click="batchCancel">取 消</el-button>
        <el-button v-if="batchStep > 0" @click="batchPrev">上一步</el-button>
        <el-button v-if="batchStep < 2" type="primary" @click="batchNext">下一步</el-button>
        <el-button v-if="batchStep === 2" type="primary" @click="submitBatchForm" :disabled="!batchConfirmChecked">提 交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listStudentRecords } from "@/api/system/studentRecord"
import { listYearSemesters } from "@/api/system/baseconfig"
import { listSubsidyRecord, addSubsidyRecord, updateSubsidyRecord, delSubsidyRecord } from "@/api/system/subsidyRecord"

export default {
  name: "AidedStudent",
  dicts: ['sys_student_gender', 'sys_student_ethnicity', 'sys_difficulty_type', 'sys_difficulty_level', 'sys_budget_project', 'sys_economy_category'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 受助学生表格数据
      aidedStudentList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 是否显示批量录入弹出层
      batchOpen: false,
      // 批量录入步骤
      batchStep: 0,
      // 批量确认复选框
      batchConfirmChecked: false,
      // 学年学期选项
      yearSemesterOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        yearSemesterId: null,
        studentName: null,
        idCardNo: null,
        difficultyTypeId: null
      },
      // 批量学生查询参数
      batchQueryParams: {
        pageNum: 1,
        pageSize: 5,
        yearSemesterId: null
      },
      // 表单参数
      form: {},
      // 预算信息
      budgetInfo: {
        availableAmount: null,
        usedAmount: null
      },
      // 表单历史记录
      formHistory: [],
      // 批量表单参数
      batchForm: {
        budgetProjectName: null,
        economyCategoryId: null,
        aidedAmount: 0
      },
      // 批量学生列表
      batchStudentList: [],
      // 批量选中学生
      selectedBatchStudents: [],
      // 批量学生总数
      batchTotal: 0,
      // 表单校验
      rules: {
        budgetProjectName: [
          { required: true, message: "预算项目不能为空", trigger: "change" }
        ],
        economyCategoryId: [
          { required: true, message: "经济分类不能为空", trigger: "change" }
        ],
        aidedAmount: [
          { required: true, message: "受助金额不能为空", trigger: "blur" }
        ]
      },
      // 批量表单校验
      batchRules: {
        budgetProjectName: [
          { required: true, message: "预算项目不能为空", trigger: "change" }
        ],
        economyCategoryId: [
          { required: true, message: "经济分类不能为空", trigger: "change" }
        ],
        aidedAmount: [
          { required: true, message: "受助金额不能为空", trigger: "blur" }
        ]
      }
    }
  },
  created() {
    this.getList();
    this.getYearSemesterList();
  },
  methods: {
    /** 查询学年学期列表 */
    getYearSemesterList() {
      listYearSemesters({ status: 1 }).then(response => {
        this.yearSemesterOptions = response.rows || response.data || [];
        // 默认选中当前学期
        const currentSemester = this.yearSemesterOptions.find(item => item.isCurrent === 1);
        if (currentSemester) {
          this.queryParams.yearSemesterId = currentSemester.id;
          this.batchQueryParams.yearSemesterId = currentSemester.id;
          this.getList();
        }
      });
    },
    /** 查询受助学生列表 */
    getList() {
      this.loading = true
      listStudentRecords(this.queryParams).then(response => {
        this.aidedStudentList = response.rows
        this.total = response.total
        this.loading = false
      })
    },
    /** 查询批量学生列表 */
    getBatchStudentList() {
      listStudentRecords(this.batchQueryParams).then(response => {
        this.batchStudentList = response.rows
        this.batchTotal = response.total
      })
    },
    // 取消按钮
    cancel() {
      this.open = false
      this.reset()
    },
    // 批量取消按钮
    batchCancel() {
      this.batchOpen = false
      this.batchReset()
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        yearSemesterId: null,
        studentId: null,
        studentName: null,
        idCardNo: null,
        gradeName: null,
        difficultyTypeId: null,
        difficultyTypeName: null,
        difficultyLevelId: null,
        budgetProjectName: null,
        economyCategoryId: null,
        aidedAmount: 0,
        memo: null
      }
      this.budgetInfo = {
        availableAmount: null,
        usedAmount: null
      }
      this.resetForm("form")
    },
    // 批量表单重置
    batchReset() {
      this.batchStep = 0
      this.batchConfirmChecked = false
      this.selectedBatchStudents = []
      this.batchForm = {
        budgetProjectName: null,
        economyCategoryId: null,
        aidedAmount: 0
      }
      this.resetForm("batchForm")
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1
      this.getList()
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm")
      this.handleQuery()
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    // 批量多选框选中数据
    handleBatchSelectionChange(selection) {
      this.selectedBatchStudents = selection
    },
    /** 录入受助金额按钮操作 */
    handleAdd() {
      if (!this.queryParams.yearSemesterId) {
        this.$modal.msgWarning("请先选择学年学期");
        return;
      }
      this.reset()
      this.form.yearSemesterId = this.queryParams.yearSemesterId
      this.open = true
      this.title = "录入受助金额"
    },
    /** 直接点击金额录入 */
    handleInputAmount(row) {
      this.handleUpdate(row);
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset()
      this.form = {
        id: row.id,
        yearSemesterId: row.yearSemesterId,
        studentId: row.studentId,
        studentName: row.studentName,
        idCardNo: row.idCardNo,
        gradeName: row.gradeName,
        difficultyTypeId: row.difficultyTypeId,
        difficultyTypeName: row.difficultyTypeName,
        difficultyLevelId: row.difficultyLevelId,
        budgetProjectName: row.budgetProjectName,
        economyCategoryId: row.economyCategoryId,
        aidedAmount: row.aidedAmount,
        memo: row.memo
      }
      this.open = true
      this.title = "录入受助金额"
      
      // 模拟获取预算信息
      this.getBudgetInfo();
      
      // 模拟获取历史记录
      this.getFormHistory();
    },
    /** 获取预算信息 */
    getBudgetInfo() {
      // 模拟获取预算信息的逻辑
      setTimeout(() => {
        this.budgetInfo = {
          availableAmount: 50000.00,
          usedAmount: 30000.00
        }
      }, 500)
    },
    /** 获取表单历史记录 */
    getFormHistory() {
      // 模拟获取历史记录的逻辑
      setTimeout(() => {
        this.formHistory = [
          {
            studentName: this.form.studentName,
            aidedAmount: 1200.00,
            budgetProjectName: "普通高中国家助学金及免学费",
            createTime: "2023-09-15"
          },
          {
            studentName: this.form.studentName,
            aidedAmount: 1000.00,
            budgetProjectName: "义务教育家庭困难补助",
            createTime: "2023-03-10"
          }
        ]
      }, 500)
    },
    /** 批量录入按钮操作 */
    handleBatchInput() {
      if (!this.queryParams.yearSemesterId) {
        this.$modal.msgWarning("请先选择学年学期");
        return;
      }
      this.batchReset()
      this.batchQueryParams.yearSemesterId = this.queryParams.yearSemesterId
      this.getBatchStudentList()
      this.batchOpen = true
    },
    /** 批量下一步 */
    batchNext() {
      if (this.batchStep === 0) {
        if (this.selectedBatchStudents.length === 0) {
          this.$modal.msgWarning("请至少选择一名学生");
          return;
        }
        this.batchStep++
      } else if (this.batchStep === 1) {
        this.$refs["batchForm"].validate(valid => {
          if (valid) {
            // 为每个学生设置默认金额
            this.selectedBatchStudents.forEach(student => {
              if (!student.aidedAmount) {
                student.aidedAmount = this.batchForm.aidedAmount
              }
            })
            this.batchStep++
          }
        })
      }
    },
    /** 批量上一步 */
    batchPrev() {
      if (this.batchStep > 0) {
        this.batchStep--
      }
    },
    /** 预算项目改变时触发 */
    handleBudgetProjectChange(value) {
      // 清空经济分类选择
      this.form.economyCategoryId = null
    },
    /** 批量预算项目改变时触发 */
    handleBatchBudgetProjectChange(value) {
      // 清空经济分类选择
      this.batchForm.economyCategoryId = null
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          const formData = {
            yearSemesterId: this.form.yearSemesterId,
            studentId: this.form.studentId,
            budgetProjectName: this.form.budgetProjectName,
            economyCategoryId: this.form.economyCategoryId,
            aidedAmount: this.form.aidedAmount,
            memo: this.form.memo
          }

          if (this.form.id != null) {
            // 修改操作
            updateSubsidyRecord({...formData, id: this.form.id}).then(response => {
              this.$modal.msgSuccess("修改成功")
              this.open = false
              this.getList()
            })
          } else {
            // 新增操作
            addSubsidyRecord(formData).then(response => {
              this.$modal.msgSuccess("录入成功")
              this.open = false
              this.getList()
            })
          }
        }
      })
    },
    /** 提交批量表单 */
    submitBatchForm() {
      if (!this.batchConfirmChecked) {
        this.$modal.msgWarning("请确认信息无误后再提交");
        return;
      }
      
      if (this.selectedBatchStudents.length === 0) {
        this.$modal.msgWarning("没有可提交的学生");
        return;
      }

      // 构造批量提交数据
      const batchData = this.selectedBatchStudents.map(student => ({
        yearSemesterId: this.batchQueryParams.yearSemesterId,
        studentId: student.studentId,
        budgetProjectName: this.batchForm.budgetProjectName,
        economyCategoryId: this.batchForm.economyCategoryId,
        aidedAmount: student.aidedAmount,
        memo: student.memo
      }))

      // 批量提交
      Promise.all(batchData.map(data => addSubsidyRecord(data)))
        .then(() => {
          this.$modal.msgSuccess("批量录入成功")
          this.batchOpen = false
          this.getList()
        })
        .catch(() => {
          this.$modal.msgError("批量录入失败")
        })
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids
      this.$modal.confirm('是否确认删除受助记录编号为"' + ids + '"的数据项？').then(function() {
        return delSubsidyRecord(ids)
      }).then(() => {
        this.getList()
        this.$modal.msgSuccess("删除成功")
      }).catch(() => {})
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('system/aidedStudent/export', {
        ...this.queryParams
      }, `aidedStudent_${new Date().getTime()}.xlsx`)
    },
    /** 获取字典标签 */
    getDictLabel(dictOptions, value) {
      if (!dictOptions || !value) return ''
      const dict = dictOptions.find(item => item.value === value)
      return dict ? dict.label : value
    }
  }
}
</script>

<style scoped lang="scss">
// 表单卡片样式
.form-card {
  margin-bottom: 20px;
  border-radius: 8px;
  border: 1px solid #e4e7ed;
  
  ::v-deep .el-card__header {
    padding: 12px 20px;
    background: #f5f7fa;
    border-bottom: 1px solid #e4e7ed;
  }
  
  ::v-deep .el-card__body {
    padding: 20px;
  }
  
  &:last-of-type {
    margin-bottom: 0;
  }
}

.card-header {
  display: flex;
  align-items: center;
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  
  i {
    margin-right: 8px;
    font-size: 16px;
    color: #409EFF;
  }
}

// 对话框样式优化
::v-deep .el-dialog__body {
  padding: 20px;
  max-height: 70vh;
  overflow-y: auto;
}

::v-deep .el-dialog__footer {
  padding: 15px 20px;
  text-align: right;
  border-top: 1px solid #e4e7ed;
}

// 表单项间距
::v-deep .el-form-item {
  margin-bottom: 18px;
}

// 响应式设计
@media (max-width: 768px) {
  ::v-deep .el-dialog {
    width: 95% !important;
  }
}

// 操作指南样式
.operation-guide {
  h4 {
    margin: 0 0 10px 0;
    color: #303133;
    font-size: 14px;
    font-weight: 600;
  }
  
  ul {
    padding-left: 18px;
    margin: 0 0 15px 0;
    
    li {
      margin-bottom: 8px;
      font-size: 13px;
      color: #606266;
      line-height: 1.5;
    }
  }
}

// 时间线样式优化
::v-deep .el-timeline-item__timestamp {
  color: #909399;
  font-size: 12px;
}

::v-deep .el-card__body {
  padding: 15px;
}
</style>