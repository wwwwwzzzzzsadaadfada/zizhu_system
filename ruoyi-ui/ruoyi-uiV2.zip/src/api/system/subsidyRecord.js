import request from '@/utils/request'

// 查询学生补助发放记录列表
export function listSubsidyRecord(query) {
  return request({
    url: '/system/subsidyRecord/list',
    method: 'get',
    params: query
  })
}

// 查询学生补助发放记录详细
export function getSubsidyRecord(id) {
  return request({
    url: '/system/subsidyRecord/' + id,
    method: 'get'
  })
}

// 新增学生补助发放记录
export function addSubsidyRecord(data) {
  return request({
    url: '/system/subsidyRecord',
    method: 'post',
    data: data
  })
}

// 修改学生补助发放记录
export function updateSubsidyRecord(data) {
  return request({
    url: '/system/subsidyRecord',
    method: 'put',
    data: data
  })
}

// 删除学生补助发放记录
export function delSubsidyRecord(id) {
  return request({
    url: '/system/subsidyRecord/' + id,
    method: 'delete'
  })
}

// 审批补助
export function approveSubsidy(id, approvalStatus, approvalMemo) {
  return request({
    url: '/system/subsidyRecord/approve/' + id,
    method: 'put',
    params: {
      approvalStatus: approvalStatus,
      approvalMemo: approvalMemo
    }
  })
}
