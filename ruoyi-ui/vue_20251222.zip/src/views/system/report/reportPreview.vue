<template>
  <div class="report-preview-page">
    <div class="report-preview-container">
      <!-- 左侧报表树 -->
      <div class="report-tree-pane">
        <div class="tree-header">
          <span class="title">报表分类</span>
        </div>
        <el-tree
          v-loading="reportTreeLoading"
          :data="reportTreeData"
          node-key="id"
          :props="{ label: 'label', children: 'children' }"
          :highlight-current="true"
          :expand-on-click-node="false"
          class="report-tree"
          @node-click="handleReportTreeClick"
        >
          <span slot-scope="{ data }" class="custom-tree-node">
            <span class="node-main">
              <i class="el-icon-document"></i>
              <span class="node-label">{{ data.label }}</span>
            </span>
            <el-tag
              v-if="data.count !== undefined"
              size="mini"
              type="info"
              effect="plain"
            >{{ data.count }}</el-tag>
          </span>
        </el-tree>
      </div>

      <!-- 右侧主体：搜索栏 + 预览 -->
      <div class="report-main-pane">
    <!-- 顶部查询和选择区域 -->
    <el-card shadow="never" class="search-card">
      <el-form :inline="true" :model="queryForm" class="demo-form-inline">
        <el-form-item label="学生姓名">
          <el-autocomplete
            v-model="queryForm.studentName"
            :fetch-suggestions="queryStudents"
            placeholder="请输入学生姓名"
            :trigger-on-focus="true"
            @select="handleStudentSelect"
            style="width: 300px;"
            clearable
          >
            <template slot-scope="{ item }">
              <div class="student-item">
                <span class="student-name">{{ item.name }}</span>
                <span class="student-info">{{ item.studentNo }} | {{ item.gradeClass }}</span>
              </div>
            </template>
          </el-autocomplete>
        </el-form-item>
        <el-form-item label="报表">
          <el-input
            v-model="currentReportName"
            placeholder="请在左侧报表树中选择"
            style="width: 300px;"
            disabled
          />
        </el-form-item>
        <el-form-item>
          <el-button type="success" icon="el-icon-download" @click="generateAndSavePdf" :disabled="!canPreview" :loading="pdfGenerating">导出并保存</el-button>
          <el-button type="warning" icon="el-icon-document-copy" @click="openBatchDialog" :disabled="!queryForm.reportId">批量导出</el-button>
          <el-button type="info" icon="el-icon-files" @click="goMergePage">合并PDF</el-button>
          <el-button icon="el-icon-refresh" @click="resetQuery">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 报表显示区域 -->
    <el-card shadow="never" class="preview-card">
      <div class="report-display-area">
        <div v-if="!reportUrl" class="empty-state">
          <el-empty description="请选择学生和报表后点击预览" :image-size="150"></el-empty>
        </div>
        <i-frame
          v-else
          ref="reportIframe"
          :src="reportUrl"
          class="report-iframe"
          @iframe-load="onReportLoad"
        ></i-frame>
      </div>
    </el-card>
      </div>
    </div>

    <!-- 批量导出弹窗 -->
    <el-dialog
      title="批量导出PDF"
      :visible.sync="batchDialogVisible"
      width="900px"
      :close-on-click-modal="false"
    >
      <el-form label-width="90px" :model="batchForm">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="报表">
              <el-input v-model="currentReportName" disabled />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学段">
              <el-select v-model="batchForm.schoolingPlanId" placeholder="可选，选择学段" @change="onSchoolingPlanChange" style="width: 100%;">
                <el-option
                  v-for="plan in schoolingPlanOptions"
                  :key="plan.value"
                  :label="plan.label"
                  :value="plan.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="学生姓名">
              <el-input v-model="batchForm.studentName" placeholder="可选，支持模糊" @input="handleStudentNameSearch" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="学年学期">
              <el-input v-model="batchForm.yearSemesterId" placeholder="可选，留空表示当前" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="批次名称">
          <el-input v-model="batchForm.batchName" placeholder="可选，不填将自动生成" />
        </el-form-item>
        <el-form-item label="学生选择">
          <div class="student-table-container">
            <div class="student-table-header">
              <div class="search-wrapper">
                <el-input
                  v-model="studentSearchKeyword"
                  placeholder="搜索学生姓名"
                  prefix-icon="el-icon-search"
                  clearable
                  @input="handleStudentTableSearch"
                  class="student-search-input"
                />
              </div>
              <div class="action-wrapper">
                <span class="selected-count">
                  <i class="el-icon-check"></i>
                  已选择 <strong>{{ batchForm.studentIds.length }}</strong> 人
                </span>
                <el-button size="small" type="text" @click="handleSelectAll">
                  <i class="el-icon-check"></i> 全选
                </el-button>
                <el-button size="small" type="text" @click="handleClearSelection">
                  <i class="el-icon-close"></i> 清空
                </el-button>
              </div>
            </div>
            <div class="table-wrapper">
              <el-table
                ref="studentTable"
                :data="studentTableData"
                height="320"
                @selection-change="handleStudentSelectionChange"
                v-loading="studentLoading"
                :header-cell-style="{ background: '#f5f7fa', color: '#606266', fontWeight: '600' }"
                :row-style="{ height: '48px' }"
                class="student-table"
              >
                <el-table-column type="selection" width="60" align="center" :reserve-selection="true" />
                <el-table-column prop="name" label="姓名" min-width="120" show-overflow-tooltip>
                  <template slot-scope="scope">
                    <span class="student-name">{{ scope.row.name }}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="gradeClass" label="年级/班级" min-width="200" show-overflow-tooltip>
                  <template slot-scope="scope">
                    <span class="grade-class">{{ scope.row.gradeClass || '未分配' }}</span>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="student-table-pagination">
              <el-pagination
                @size-change="handleStudentPageSizeChange"
                @current-change="handleStudentPageChange"
                :current-page="studentTablePage.pageNum"
                :page-sizes="[10, 20, 50, 100]"
                :page-size="studentTablePage.pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="studentTablePage.total"
                background
              />
            </div>
            <div class="help-text">
              <i class="el-icon-info"></i>
              提示：不选择学生则按学段+姓名条件批量生成
            </div>
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="batchDialogVisible = false">取 消</el-button>
        <el-button type="primary" :loading="batchGenerating" @click="submitBatchGenerate">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { listStudentsBase, getSchoolPlanList } from "@/api/system/studentRecord";
import { listReport, listReportTree } from "@/api/system/report";
import { generatePdf, downloadPdf, batchGeneratePdf, listReportPdf, mergePdfs, mergePdfsByCondition, downloadBatchPdf, listReportPdfBatch } from "@/api/system/reportPdf";
import iFrame from "@/components/iFrame/index";

export default {
  name: "ReportPreview",
  components: {
    iFrame
  },
  data() {
    return {
      // 查询表单
      queryForm: {
        studentName: '',
        studentId: null,
        reportId: null
      },
      // 选中的学生信息
      selectedStudent: null,
      // 报表列表
      reportList: [],
      // 报表URL
      reportUrl: '',
      // 加载状态
      loading: false,
      // PDF生成状态
      pdfGenerating: false,
      // 当前学年学期ID（用于PDF生成）
      currentYearSemesterId: null,
      // 批量导出弹窗
      batchDialogVisible: false,
      batchGenerating: false,
      batchForm: {
        studentIds: [],
        schoolingPlanId: '',
        studentName: '',
        yearSemesterId: '',
        batchName: ''
      },
      schoolingPlanOptions: [],
      studentOptions: [],
      studentLoading: false,
      // 学生表格相关
      studentTableData: [],
      studentSearchKeyword: '',
      studentTablePage: {
        pageNum: 1,
        pageSize: 20,
        total: 0
      },
      // 合并PDF相关
      mergeDialogVisible: false,
      merging: false,
      mergeForm: {
        mergedFileName: '',
        reportId: null
      },
      // 待合并PDF列表
      pdfTableData: [],
      pdfTableLoading: false,
      pdfTablePage: {
        pageNum: 1,
        pageSize: 20,
        total: 0
      },
      availableReports: [], // 有PDF的报表列表
      // 合并结果列表
      batchList: [],
      batchLoading: false,
      batchPage: {
        pageNum: 1,
        pageSize: 10,
        total: 0
      },
      // 报表树
      reportTreeLoading: false,
      reportTreeData: []
    }
  },
  computed: {
    canPreview() {
      return this.queryForm.studentId && this.queryForm.reportId
    },
    currentReportName() {
      const target = this.reportList.find(item => item.id === this.queryForm.reportId)
      return target ? target.name : ''
    },
    currentMergeReportName() {
      if (!this.mergeForm.reportId) return ''
      const report = this.availableReports.find(r => r.id === this.mergeForm.reportId) ||
                     this.reportList.find(r => r.id === this.mergeForm.reportId)
      return report ? report.name : ''
    }
  },
  mounted() {
    this.loadReportList()
    this.loadReportTree()
    this.loadAvailableReports()
    this.loadBatchList()
  },
  methods: {
    /** 查询学生（根据姓名） */
    queryStudents(queryString, cb) {
      this.loading = true

      // 构建查询参数，逻辑由后端处理
      const params = {
        pageNum: 1,
        pageSize: 10
      }

      // 如果有输入文字，传递给后端进行模糊查询
      if (queryString && queryString.trim() !== '') {
        params.name = queryString.trim()
      }

      listStudentsBase(params).then(response => {
        this.loading = false
        if (response.code === 200 && response.rows) {
          const students = response.rows.map(item => {
            // 处理年级班级信息，兼容不同的字段名
            const gradeName = item.gradeName || item.grade_name || ''
            const className = item.className || item.class_name || ''
            const gradeClass = gradeName && className ? `${gradeName}/${className}` : (gradeName || className || '')

            return {
              value: item.name,
              name: item.name,
              studentId: item.id,
              studentNo: item.studentNo || item.student_no || '',
              gradeClass: gradeClass,
              schoolingPlanId: item.schoolingPlanId || item.schooling_plan_id || null
            }
          })
          cb(students)
        } else {
          cb([])
        }
      }).catch(() => {
        this.loading = false
        cb([])
      })
    },

    /** 选择学生 */
    handleStudentSelect(item) {
      this.queryForm.studentId = item.studentId
      this.selectedStudent = item

      // 根据学生ID重新加载报表列表（后端会根据学生学制自动过滤）
      // 安全：所有过滤逻辑在后端完成，前端只传递学生ID
      this.loadReportList(item.studentId)

      // 清空之前选择的报表（因为报表列表可能已变化）
      this.queryForm.reportId = null
      this.reportUrl = ''
    },

    /** 报表选择改变 */
    handleReportChange(value) {
      if (value && this.queryForm.studentId) {
        this.$nextTick(() => {
          this.previewReport()
        })
      } else {
        this.reportUrl = ''
      }
    },

    /** 加载报表树（后端已按学段分组） */
    loadReportTree() {
      this.reportTreeLoading = true
      const params = {}
      if (this.queryForm.studentId) {
        params.studentId = this.queryForm.studentId
      }
      listReportTree(params).then(res => {
        if (res.code === 200) {
          this.reportTreeData = res.data || res
        } else {
          this.reportTreeData = []
        }
      }).catch(err => {
        console.error('加载报表树失败:', err)
        this.reportTreeData = []
      }).finally(() => {
        this.reportTreeLoading = false
      })
    },

    /** 报表树节点点击 */
    handleReportTreeClick(node) {
      // 仅在点击叶子节点（具体报表）时处理
      if (!node || !node.id || node.children) {
        return
      }
      this.queryForm.reportId = node.id
      this.$nextTick(() => {
        if (this.queryForm.studentId) {
          this.previewReport()
        }
      })
    },

    /** 加载报表列表
     * @param {Number} studentId 学生ID（可选）
     *                           如果提供，后端会根据学生学制自动过滤报表
     *                           如果为null，返回所有报表
     */
    loadReportList(studentId = null) {
      this.loading = true
      // 构建查询参数
      // 安全：只传递学生ID，后端会查询学生学制并过滤报表
      const params = {}
      if (studentId != null) {
        params.studentId = studentId
        // 额外传递学段，便于后端按学段限制可生成的报表
        if (this.selectedStudent && this.selectedStudent.schoolingPlanId) {
          params.schoolingPlanId = this.selectedStudent.schoolingPlanId
        }
      }

      // 通过后端API获取报表列表
      listReport(params).then(response => {
        this.loading = false
        console.log('报表列表API响应:', response)

        if (response.code === 200) {
          if (response.data && Array.isArray(response.data) && response.data.length > 0) {
            this.reportList = response.data.map(item => ({
              id: item.id,
              name: item.name,
              code: item.code,
              schoolingPlanId: item.schoolingPlanId || null
            }))
            console.log('成功加载报表列表:', this.reportList)

            // 如果根据学生过滤后没有报表，给出提示
            if (studentId != null && this.reportList.length === 0) {
              this.$modal.msgWarning('该学生学段暂无适用的报表模板')
            }
          } else {
            console.warn('报表列表为空')
            if (studentId != null) {
              // 有学生时，不再回退默认报表，保持为空，避免跨学段显示
              this.reportList = []
              this.$modal.msgWarning('该学生学段暂无适用的报表模板')
            } else {
              this.$modal.msgWarning('未查询到报表模板，使用默认报表')
            this.loadDefaultReportList()
            }
          }
        } else {
          console.error('报表列表API返回错误:', response.msg || '未知错误')
          this.$modal.msgError(response.msg || '获取报表列表失败')
          // 仅在未选择学生时回退默认列表
          if (studentId == null) {
          this.loadDefaultReportList()
          } else {
            this.reportList = []
          }
        }
      }).catch(error => {
        this.loading = false
        console.error('报表列表API调用失败:', error)
        this.$modal.msgError('获取报表列表失败: ' + (error.message || '网络错误'))
        // 仅在未选择学生时回退默认列表
        if (studentId == null) {
        this.loadDefaultReportList()
        } else {
          this.reportList = []
        }
      })
    },

    /** 加载默认报表列表（备用方案） */
    loadDefaultReportList() {
      // 这里可以设置一些默认的报表ID
      // 或者从系统配置中获取
      this.reportList = [
        {
          id: '1159821341794144256',
          name: '普通高中国家助学金申请表',
          code: 'student_aid_application'
        }
      ]
    },

    /** 预览报表 */
    previewReport() {
      if (!this.canPreview) {
        this.$modal.msgWarning('请选择学生和报表')
        return
      }

      const baseUrl = process.env.NODE_ENV === 'development'
        ? 'http://localhost:8080'
        : (process.env.VUE_APP_BASE_API || window.location.origin)

      // 构建报表预览URL
      this.reportUrl = `${baseUrl}/jmreport/view/${this.queryForm.reportId}?studentId=${this.queryForm.studentId}`
    },

    /** 重置查询 */
    resetQuery() {
      this.queryForm = {
        studentName: '',
        studentId: null,
        reportId: null
      }
      this.selectedStudent = null
      this.reportUrl = ''
      // 重新加载所有报表列表（不传学生ID，返回所有报表）
      this.loadReportList()
    },

    /** 报表加载完成 */
    onReportLoad() {
      this.hideReportToolbar()
      this.centerReport()
    },

    /** 隐藏报表内置工具栏 */
    hideReportToolbar() {
      try {
        const iframeComp = this.$refs.reportIframe
        const iframeEl = iframeComp && iframeComp.$refs && iframeComp.$refs.iframe
        const doc = iframeEl && iframeEl.contentDocument
        if (!doc) return

        const style = doc.createElement('style')
        style.innerHTML = `
          .jimu-report-header,
          .jimu-report-action,
          .jimu-toolbar,
          .jr-toolbar,
          .report-operate,
          .ant-card-head,
          .ant-card-actions,
          .vxe-toolbar,
          .jr-tabs-header {
            display: none !important;
          }
          /* 居中报表内容 */
          html, body {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            width: 100%;
            box-sizing: border-box;
            background: #f5f7fa !important;
          }
          /* 让报表容器本身居中 */
          .jimu-report,
          .jimu-container,
          .jimu-report-main,
          .jr-view,
          .jr-layout,
          .jr-sheet,
          .report-view-container,
          .report-view-main,
          .jr-main,
          .jr-body {
            margin-left: auto !important;
            margin-right: auto !important;
            display: flex !important;
            justify-content: center !important;
          }
          .jr-view > * {
            margin-left: auto !important;
            margin-right: auto !important;
          }
          .jr-report,
          .jr-body,
          .jr-container,
          .jr-layout,
          .jr-sheet,
          .jimu-report,
          .jr-view,
          .report-view-container {
            margin: 0 auto !important;
          }
          /* 针对常见根节点与表格再居中一层 */
          body > * {
            margin-left: auto !important;
            margin-right: auto !important;
          }
          #app, .app, .jr-app, .jr-view-main, .jr-view-content {
            display: flex !important;
            justify-content: center !important;
            margin-left: auto !important;
            margin-right: auto !important;
          }
          table {
            margin-left: auto !important;
            margin-right: auto !important;
          }
          body {
            padding: 0 !important;
            margin: 0 !important;
            background: #f5f7fa !important;
          }
        `
        doc.head.appendChild(style)
        // 额外尝试居中
        this.centerReport(doc)
      } catch (e) {
        // 忽略跨域或注入失败
        console.warn('隐藏报表工具栏失败', e)
      }
    },

    /** 尝试将报表主体再居中一次 */
    centerReport(doc) {
      try {
        const iframeComp = this.$refs.reportIframe
        const iframeEl = iframeComp && iframeComp.$refs && iframeComp.$refs.iframe
        const d = doc || (iframeEl && iframeEl.contentDocument)
        if (!d) return

        // 包一层居中容器
        const body = d.body
        if (body && !body.querySelector('.__center-wrap')) {
          const wrapper = d.createElement('div')
          wrapper.className = '__center-wrap'
          wrapper.style.display = 'flex'
          wrapper.style.justifyContent = 'center'
          wrapper.style.alignItems = 'flex-start'
          wrapper.style.width = '100%'
          wrapper.style.boxSizing = 'border-box'
          wrapper.style.background = '#f5f7fa'

          while (body.firstChild) {
            wrapper.appendChild(body.firstChild)
          }
          body.appendChild(wrapper)
          body.style.margin = '0'
          body.style.padding = '0'
          body.style.display = 'block'
        }

        // 找到可能的报表容器或表格
        const candidates = [
          '#app',
          '.jr-view',
          '.jr-view-main',
          '.jr-view-content',
          '.jr-container',
          '.jr-report',
          '.jimu-report',
          '.report-view-container',
          '.report-view-main',
          '.report-container',
          '.jimu-table',
          'table'
        ]

        for (const sel of candidates) {
          const el = d.querySelector(sel)
          if (el) {
            el.style.marginLeft = 'auto'
            el.style.marginRight = 'auto'
            el.style.display = 'block'
            if (el.style.width === '' || el.style.width === 'auto') {
              el.style.width = 'fit-content'
              el.style.maxWidth = '100%'
            }
          }
        }

        // 对 body 再包装一层 flex
        if (body) {
          body.style.display = 'block'
          body.style.background = '#f5f7fa'
        }
      } catch (err) {
        console.warn('居中报表失败', err)
      }
    },

    /** 新窗口打开 */
    openInNewWindow() {
      if (this.reportUrl) {
        window.open(this.reportUrl, '_blank', 'width=1200,height=800,scrollbars=yes')
      }
    },

    /** 打印报表 */
    printReport() {
      if (this.reportUrl) {
        const printWindow = window.open(this.reportUrl, '_blank', 'width=1200,height=800')
        if (printWindow) {
          printWindow.onload = () => {
            setTimeout(() => {
              printWindow.print()
            }, 500)
          }
        }
      }
    },

    /** 导出PDF */
    exportReport() {
      if (this.reportUrl) {
        // 积木报表的导出PDF功能，可以在URL后添加参数
        const exportUrl = this.reportUrl + '&exportType=pdf'
        window.open(exportUrl, '_blank')
      }
    },

    /** 生成并保存PDF */
    async generateAndSavePdf() {
      if (!this.canPreview) {
        this.$modal.msgWarning('请选择学生和报表')
        return
      }

      this.pdfGenerating = true
      try {
        // 获取当前学年学期ID（可以从系统配置或学生信息中获取）
        // 这里暂时使用null，实际应该从学生信息或系统配置中获取
        const yearSemesterId = this.currentYearSemesterId || null

        const response = await generatePdf({
          studentId: this.queryForm.studentId,
          reportId: this.queryForm.reportId,
          yearSemesterId: yearSemesterId
        })

        if (response.code === 200) {
          this.$modal.msgSuccess('PDF生成并保存成功')
          // 可以提示用户下载
          this.$modal.confirm('PDF已保存到服务器，是否立即下载？', '提示', {
            confirmButtonText: '下载',
            cancelButtonText: '取消',
            type: 'success'
          }).then(() => {
            // 使用下载API下载PDF
            downloadPdf(response.data.id).then(res => {
              const blob = new Blob([res], { type: 'application/pdf' })
              const link = document.createElement('a')
              link.href = window.URL.createObjectURL(blob)
              link.download = response.data.fileName
              document.body.appendChild(link)
              link.click()
              document.body.removeChild(link)
              window.URL.revokeObjectURL(link.href)
              this.$modal.msgSuccess('下载成功')
            }).catch(err => {
              console.error('下载失败:', err)
              this.$modal.msgError('下载失败：' + (err.message || '网络错误'))
            })
          }).catch(() => {})
        } else {
          this.$modal.msgError(response.msg || 'PDF生成失败')
        }
      } catch (error) {
        console.error('生成PDF失败:', error)
        this.$modal.msgError('PDF生成失败：' + (error.message || '网络错误'))
      } finally {
        this.pdfGenerating = false
      }
    },

    /** 打开批量导出弹窗 */
    openBatchDialog() {
      if (!this.queryForm.reportId) {
        this.$modal.msgWarning('请先选择报表')
        return
      }
      // 默认批次名
      this.batchForm.batchName = this.batchForm.batchName || `批次_${new Date().getTime()}`
      // 若已有当前学年学期，带上
      if (this.currentYearSemesterId) {
        this.batchForm.yearSemesterId = this.currentYearSemesterId
      }
      // 重置学生表格数据
      this.batchForm.studentIds = []
      this.studentSearchKeyword = ''
      this.studentTablePage.pageNum = 1
      // 初始化学段列表
      if (!this.schoolingPlanOptions.length) {
        this.loadSchoolingPlans()
      } else {
        // 已有学段列表时，加载学生表格
        this.loadStudentTable()
      }
      this.batchDialogVisible = true
    },

    /** 提交批量导出 */
    async submitBatchGenerate() {
      if (!this.queryForm.reportId) {
        this.$modal.msgWarning('请先选择报表')
        return
      }

      // 防止重复提交
      if (this.batchGenerating) {
        return
      }

      // 处理学生ID：转换为数字、过滤无效值、去重
      let studentIds = (this.batchForm.studentIds || []).map(x => Number(x)).filter(x => !isNaN(x) && x > 0)
      // 去重
      studentIds = [...new Set(studentIds)]

      // 如果没有选择学生，也没有筛选条件，提示用户
      if (studentIds.length === 0 && !this.batchForm.schoolingPlanId && !this.batchForm.studentName) {
        this.$modal.msgWarning('请选择学生或提供筛选条件（学段/姓名）')
        return
      }

      const payload = {
        studentIds: studentIds.length > 0 ? studentIds : null,
        reportId: this.queryForm.reportId,
        yearSemesterId: this.batchForm.yearSemesterId || null,
        batchName: this.batchForm.batchName || null,
        schoolingPlanId: this.batchForm.schoolingPlanId || null,
        studentName: this.batchForm.studentName || null
      }

      this.batchGenerating = true
      try {
        const res = await batchGeneratePdf(payload)
        if (res.code === 200) {
          this.$modal.msgSuccess('批量生成已提交，批次ID：' + res.data.batchId)
          // 清空表单
          this.batchForm.studentIds = []
          this.batchDialogVisible = false
        } else {
          this.$modal.msgError(res.msg || '批量生成失败')
        }
      } catch (e) {
        console.error('批量生成失败', e)
        this.$modal.msgError('批量生成失败：' + (e.message || '网络错误'))
      } finally {
        this.batchGenerating = false
      }
    },

    /** 加载学生表格数据 */
    loadStudentTable() {
      this.studentLoading = true
      const params = {
        pageNum: this.studentTablePage.pageNum,
        pageSize: this.studentTablePage.pageSize,
        schoolingPlanId: this.batchForm.schoolingPlanId || undefined
      }

      // 如果有搜索关键字，添加到查询参数
      const searchKeyword = this.studentSearchKeyword || this.batchForm.studentName
      if (searchKeyword && searchKeyword.trim()) {
        params.name = searchKeyword.trim()
      }

      listStudentsBase(params).then(res => {
        if (res.code === 200 && res.rows) {
          this.studentTableData = res.rows.map(item => {
            const gradeName = item.gradeName || item.grade_name || ''
            const className = item.className || item.class_name || ''
            const gradeClass = gradeName && className ? `${gradeName}/${className}` : (gradeName || className || '')
            return {
              id: item.id,
              name: item.name,
              gradeClass: gradeClass
            }
          })
          this.studentTablePage.total = res.total || 0

          // 恢复已选中的学生
          this.$nextTick(() => {
            this.restoreStudentSelection()
          })
        } else {
          this.studentTableData = []
          this.studentTablePage.total = 0
        }
      }).catch(err => {
        console.error('加载学生列表失败:', err)
        this.studentTableData = []
        this.studentTablePage.total = 0
      }).finally(() => {
        this.studentLoading = false
      })
    },

    /** 恢复已选中的学生 */
    restoreStudentSelection() {
      if (!this.$refs.studentTable || !this.batchForm.studentIds || this.batchForm.studentIds.length === 0) {
        return
      }
      this.studentTableData.forEach(row => {
        if (this.batchForm.studentIds.includes(row.id)) {
          this.$refs.studentTable.toggleRowSelection(row, true)
        }
      })
    },

    /** 学段变化时，重新加载学生表格 */
    onSchoolingPlanChange() {
      // 清空已选学生，避免跨学段误选
      this.batchForm.studentIds = []
      this.studentTablePage.pageNum = 1
      this.loadStudentTable()
    },

    /** 学生表格搜索 */
    handleStudentTableSearch() {
      this.studentTablePage.pageNum = 1
      this.loadStudentTable()
    },

    /** 学生姓名输入框搜索 */
    handleStudentNameSearch() {
      this.studentSearchKeyword = this.batchForm.studentName
      this.studentTablePage.pageNum = 1
      this.loadStudentTable()
    },

    /** 学生表格选择变化 */
    handleStudentSelectionChange(selection) {
      const selectedIds = selection.map(item => item.id)
      // 合并当前页选中的学生ID
      const currentPageIds = this.studentTableData.map(item => item.id)
      // 移除当前页未选中的ID
      this.batchForm.studentIds = this.batchForm.studentIds.filter(id => !currentPageIds.includes(id))
      // 添加当前页新选中的ID
      this.batchForm.studentIds = [...this.batchForm.studentIds, ...selectedIds]
      // 去重
      this.batchForm.studentIds = [...new Set(this.batchForm.studentIds)]
    },

    /** 全选 */
    handleSelectAll() {
      if (!this.$refs.studentTable) {
        return
      }
      this.studentTableData.forEach(row => {
        this.$refs.studentTable.toggleRowSelection(row, true)
      })
      // 更新选中列表
      const selectedIds = this.studentTableData.map(item => item.id)
      this.batchForm.studentIds = [...new Set([...this.batchForm.studentIds, ...selectedIds])]
    },

    /** 清空选择 */
    handleClearSelection() {
      if (!this.$refs.studentTable) {
        return
      }
      this.$refs.studentTable.clearSelection()
      // 移除当前页的学生ID
      const currentPageIds = this.studentTableData.map(item => item.id)
      this.batchForm.studentIds = this.batchForm.studentIds.filter(id => !currentPageIds.includes(id))
    },

    /** 学生表格分页大小变化 */
    handleStudentPageSizeChange(size) {
      this.studentTablePage.pageSize = size
      this.studentTablePage.pageNum = 1
      this.loadStudentTable()
    },

    /** 学生表格页码变化 */
    handleStudentPageChange(page) {
      this.studentTablePage.pageNum = page
      this.loadStudentTable()
    },

    /** 加载学段列表 */
    loadSchoolingPlans() {
      getSchoolPlanList().then(res => {
        if (res.code === 200 && Array.isArray(res.data)) {
          this.schoolingPlanOptions = res.data.map(item => ({
            label: item.name || item.planName || item.plan_name || item.id,
            value: item.id
          }))
          // 如果未选择学段，默认选第一个并触发学生表格加载
          if (!this.batchForm.schoolingPlanId && this.schoolingPlanOptions.length > 0) {
            this.batchForm.schoolingPlanId = this.schoolingPlanOptions[0].value
            this.loadStudentTable()
          } else {
            this.loadStudentTable()
          }
        }
      })
    },

    /** 跳转到合并页面 */
    goMergePage() {
      this.$router.push({ path: '/system/report/merge' })
    },

    /** 重置合并表单 */
    resetMergeForm() {
      this.mergeForm = {
        mergedFileName: '',
        reportId: null
      }
      this.pdfTableData = []
      this.pdfTablePage.pageNum = 1
      this.pdfTablePage.total = 0
    },

    /** 加载有PDF的报表列表 */
    loadAvailableReports() {
      // 先加载所有报表的PDF统计
      listReportPdf({ status: 1, isMerged: 0 }).then(res => {
        if (res.code === 200) {
          const allPdfs = res.rows || res.data || []
          // 按报表ID分组统计
          const reportMap = new Map()
          allPdfs.forEach(pdf => {
            const reportId = pdf.reportId
            const reportName = pdf.reportName || '未知报表'
            if (!reportMap.has(reportId)) {
              reportMap.set(reportId, {
                id: reportId,
                name: reportName,
                pdfCount: 0
              })
            }
            reportMap.get(reportId).pdfCount++
          })

          // 转换为数组，只显示有PDF的报表
          this.availableReports = Array.from(reportMap.values()).filter(r => r.pdfCount > 0)

          // 如果当前选择的报表在列表中，保持选中
          if (this.mergeForm.reportId && this.availableReports.find(r => r.id === this.mergeForm.reportId)) {
            this.handleReportSelectChange(this.mergeForm.reportId)
          }
        }
      }).catch(err => {
        console.error('加载报表列表失败:', err)
        this.availableReports = []
      })
    },

    /** 报表选择变化 */
    handleReportSelectChange(reportId) {
      if (!reportId) {
        this.pdfTableData = []
        this.pdfTablePage.total = 0
        this.mergeForm.mergedFileName = ''
        return
      }

      // 获取报表名称
      const report = this.availableReports.find(r => r.id === reportId) ||
                     this.reportList.find(r => r.id === reportId)
      const reportName = report ? report.name : '报表'

      // 自动生成合并文件名：报表名称+汇总
      this.mergeForm.mergedFileName = reportName + '汇总'

      // 加载该报表的所有PDF
      this.loadPdfListByReport(reportId)
    },

    /** 根据报表ID加载PDF列表 */
    loadPdfListByReport(reportId) {
      this.pdfTableLoading = true
      const params = {
        pageNum: this.pdfTablePage.pageNum,
        pageSize: this.pdfTablePage.pageSize,
        reportId: reportId,
        status: 1, // 只查询有效的PDF
        isMerged: 0 // 只查询未合并的PDF
      }

      listReportPdf(params).then(res => {
        if (res.code === 200) {
          this.pdfTableData = (res.rows || res.data || []).map(item => ({
            id: item.id,
            reportName: item.reportName || '未知报表',
            fileName: item.fileName || '未知文件',
            fileSize: item.fileSize || 0,
            createTime: item.createTime || '',
            isMerged: item.isMerged || 0
          }))
          this.pdfTablePage.total = res.total || 0
        } else {
          this.pdfTableData = []
          this.pdfTablePage.total = 0
        }
      }).catch(err => {
        console.error('加载PDF列表失败:', err)
        this.pdfTableData = []
        this.pdfTablePage.total = 0
        this.$modal.msgError('加载PDF列表失败：' + (err.message || '网络错误'))
      }).finally(() => {
        this.pdfTableLoading = false
      })
    },

    /** PDF表格分页大小变化 */
    handlePdfPageSizeChange(size) {
      this.pdfTablePage.pageSize = size
      this.pdfTablePage.pageNum = 1
      if (this.mergeForm.reportId) {
        this.loadPdfListByReport(this.mergeForm.reportId)
      }
    },

    /** PDF表格页码变化 */
    handlePdfPageChange(page) {
      this.pdfTablePage.pageNum = page
      if (this.mergeForm.reportId) {
        this.loadPdfListByReport(this.mergeForm.reportId)
      }
    },

    /** 格式化文件大小 */
    formatFileSize(bytes) {
      if (!bytes || bytes === 0) return '0 B'
      const k = 1024
      const sizes = ['B', 'KB', 'MB', 'GB']
      const i = Math.floor(Math.log(bytes) / Math.log(k))
      return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
    },

    /** 下载单个PDF */
    downloadSinglePdf(id) {
      downloadPdf(id).then(res => {
        const blob = new Blob([res], { type: 'application/pdf' })
        const link = document.createElement('a')
        link.href = window.URL.createObjectURL(blob)
        // 从PDF列表中获取文件名
        const pdf = this.pdfTableData.find(p => p.id === id)
        link.download = pdf ? pdf.fileName : 'download.pdf'
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        window.URL.revokeObjectURL(link.href)
        this.$modal.msgSuccess('下载成功')
      }).catch(err => {
        console.error('下载失败:', err)
        this.$modal.msgError('下载失败：' + (err.message || '网络错误'))
      })
    },

    /** 提交合并 */
    async submitMerge() {
      if (!this.mergeForm.reportId) {
        this.$modal.msgWarning('请选择要合并的报表')
        return
      }

      if (this.pdfTablePage.total < 1) {
        this.$modal.msgWarning('该报表没有可合并的PDF文件')
        return
      }

      // 防止重复提交
      if (this.merging) {
        return
      }

      this.merging = true
      try {
        // 使用按条件合并接口，更高效
        const response = await mergePdfsByCondition({
          reportId: this.mergeForm.reportId,
          yearSemesterId: null, // 不限制学年学期
          schoolingPlanId: null, // 不限制学段
          gradeId: null, // 不限制年级
          classId: null, // 不限制班级
          mergedFileName: this.mergeForm.mergedFileName.trim()
        })

        if (response.code === 200) {
          this.$modal.msgSuccess('PDF合并成功')
          // 提示用户下载
          this.$modal.confirm('PDF合并成功，是否立即下载？', '提示', {
            confirmButtonText: '下载',
            cancelButtonText: '取消',
            type: 'success'
          }).then(() => {
            // 下载合并后的PDF
            if (response.data && response.data.id) {
              downloadBatchPdf(response.data.id).then(res => {
                const blob = new Blob([res], { type: 'application/pdf' })
                const link = document.createElement('a')
                link.href = window.URL.createObjectURL(blob)
                link.download = response.data.mergedFileName || 'merged.pdf'
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link)
                window.URL.revokeObjectURL(link.href)
                this.$modal.msgSuccess('下载成功')
              }).catch(err => {
                console.error('下载失败:', err)
                this.$modal.msgError('下载失败：' + (err.message || '网络错误'))
              })
            }
          }).catch(() => {})

          // 刷新列表
          this.loadAvailableReports()
          if (this.mergeForm.reportId) {
            this.loadPdfListByReport(this.mergeForm.reportId)
          }
          this.loadBatchList()
        } else {
          this.$modal.msgError(response.msg || 'PDF合并失败')
        }
      } catch (error) {
        console.error('合并PDF失败:', error)
        this.$modal.msgError('PDF合并失败：' + (error.message || '网络错误'))
      } finally {
        this.merging = false
      }
    },

    /** 右侧合并结果列表 */
    loadBatchList() {
      this.batchLoading = true
      const params = {
        pageNum: this.batchPage.pageNum,
        pageSize: this.batchPage.pageSize
      }
      listReportPdfBatch(params).then(res => {
        if (res.code === 200) {
          this.batchList = res.rows || res.data || []
          this.batchPage.total = res.total || 0
        } else {
          this.batchList = []
          this.batchPage.total = 0
        }
      }).catch(err => {
        console.error('加载合并结果失败:', err)
        this.batchList = []
        this.batchPage.total = 0
      }).finally(() => {
        this.batchLoading = false
      })
    },

    handleBatchPageSizeChange(size) {
      this.batchPage.pageSize = size
      this.batchPage.pageNum = 1
      this.loadBatchList()
    },

    handleBatchPageChange(page) {
      this.batchPage.pageNum = page
      this.loadBatchList()
    },

    /** 下载合并后的PDF */
    downloadMergedBatch(id, fileName) {
      downloadBatchPdf(id).then(res => {
        const blob = new Blob([res], { type: 'application/pdf' })
        const link = document.createElement('a')
        link.href = window.URL.createObjectURL(blob)
        link.download = fileName || 'merged.pdf'
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        window.URL.revokeObjectURL(link.href)
        this.$modal.msgSuccess('下载成功')
      }).catch(err => {
        console.error('下载失败:', err)
        this.$modal.msgError('下载失败：' + (err.message || '网络错误'))
      })
    },

    /** 预览合并后的PDF（新窗口） */
    previewMergedBatch(id) {
      downloadBatchPdf(id).then(res => {
        const blob = new Blob([res], { type: 'application/pdf' })
        const url = window.URL.createObjectURL(blob)
        window.open(url, '_blank')
        setTimeout(() => window.URL.revokeObjectURL(url), 10000)
      }).catch(err => {
        console.error('预览失败:', err)
        this.$modal.msgError('预览失败：' + (err.message || '网络错误'))
      })
    }
  }
}
</script>

<style scoped lang="scss">
.report-preview-page {
  min-height: 100vh;
  background: #ffffff; /* 全局白色背景 */
  padding: 16px 0 24px;
}

.report-preview-container {
  width: 100%;
  margin: 0;
  padding: 0 24px 24px 16px;
  height: 100%;
  display: flex;
  flex-direction: row;
  gap: 0; /* 容器之间紧贴，无间隙 */
}

.report-main-pane {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.search-card {
  flex-shrink: 0;
  position: sticky;
  top: 0;
  z-index: 20;
  background: transparent;

  ::v-deep .el-card__body {
    padding: 20px;
    background: #ffffff;
  }
}

.preview-card {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: transparent;

  ::v-deep .el-card__body {
    flex: 1;
    padding: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: #ffffff;
  }
}

.report-tree-pane {
  width: 320px; /* 扩大左侧树容器宽度 */
  border-right: 1px solid #ebeef5;
  padding: 12px 12px 12px 8px;
  box-sizing: border-box;
  background: #f5f9ff; /* 浅蓝色背景，区分树区域 */
  position: sticky;
  top: 16px; /* 与页面上边距一致，滚动时保持在视口内 */
  display: flex;
  flex-direction: column;
  height: 100%;
}

.tree-header {
  margin-bottom: 8px;
  .title {
    font-size: 14px;
    font-weight: 600;
    color: #303133;
  }
  .subtitle {
    margin-top: 2px;
    font-size: 12px;
    color: #909399;
  }
}

.report-tree {
  margin-top: 4px;
  max-height: calc(100% - 30px);
  overflow: auto;
  background: transparent;
  padding-right: 4px;
}

.custom-tree-node {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  .node-main {
    display: flex;
    align-items: center;
    gap: 4px;
    color: #303133;
  }

  .node-main .el-icon-document {
    font-size: 14px;
    color: #409eff;
  }

  .node-label {
    font-size: 13px;
  }
}

/* 高亮当前选中的树节点，让选中效果更明显 */
::v-deep .el-tree-node.is-current > .el-tree-node__content {
  background-color: #e6f0ff !important;
  color: #1f2d3d;
  font-weight: 600;
}

::v-deep .el-tree-node__content:hover {
  background-color: #edf3ff;
}

.report-display-area {
  flex: 1;
  position: relative;
  overflow: auto;
  background: #ffffff;
  display: flex;
  justify-content: flex-start; /* 报表内容靠左对齐 */
  align-items: flex-start;
  padding: 16px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  border-radius: 6px;

  .empty-state {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 400px;
  }

  .report-iframe {
    width: 100%;
    max-width: 100%;
    min-height: 600px;
    border: 1px solid #e4e7ed;
    border-radius: 4px;
    background: #ffffff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  }
}

.merge-section {
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: 16px;
}

.merge-card {
  background: transparent;

  ::v-deep .el-card__body {
    background: #ffffff;
  }
}

.merge-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;

  .title {
    font-size: 16px;
    font-weight: 600;
    color: #303133;
  }

  .desc {
    color: #909399;
    font-size: 13px;
  }
}

.merge-form {
  margin-bottom: 8px;
}

.merge-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;

  .tips {
    color: #909399;
    font-size: 13px;
  }
}

.merge-table-container {
  border: 1px solid #ebeef5;
  border-radius: 6px;
  padding: 12px;
  background: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}

.merge-table-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
  .title {
    font-weight: 600;
    color: #303133;
  }
  .count {
    color: #909399;
    font-size: 13px;
  }
}

.merge-table-pagination {
  margin-top: 8px;
  display: flex;
  justify-content: flex-end;
}

.student-item {
  display: flex;
  justify-content: space-between;
  align-items: center;

  .student-name {
    font-weight: 600;
    color: #303133;
  }

  .student-info {
    font-size: 12px;
    color: #909399;
    margin-left: 20px;
  }
}

::v-deep .el-autocomplete-suggestion__list {
  .student-item {
    padding: 8px 0;
    border-bottom: 1px solid #f0f0f0;

    &:last-child {
      border-bottom: none;
    }
  }
}

.student-table-container {
  border: 1px solid #e4e7ed;
  border-radius: 6px;
  padding: 16px;
  background: #ffffff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);

  .student-table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f0f0f0;

    .search-wrapper {
      flex: 1;
      max-width: 300px;

      .student-search-input {
        ::v-deep .el-input__inner {
          border-radius: 20px;
          border: 1px solid #dcdfe6;
          transition: all 0.3s;

          &:focus {
            border-color: #409eff;
            box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.1);
          }
        }
      }
    }

    .action-wrapper {
      display: flex;
      align-items: center;
      gap: 16px;

      .selected-count {
        color: #409eff;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 4px;

        i {
          font-size: 16px;
        }

        strong {
          color: #303133;
          font-weight: 600;
          margin: 0 2px;
        }
      }

      .el-button {
        padding: 6px 12px;
        color: #606266;
        font-size: 13px;

        &:hover {
          color: #409eff;
          background: #ecf5ff;
        }

        i {
          margin-right: 4px;
        }
      }
    }
  }

  .table-wrapper {
    border: 1px solid #ebeef5;
    border-radius: 4px;
    overflow: hidden;
    background: #ffffff;

    .student-table {
      ::v-deep .el-table__header {
        th {
          padding: 12px 0;
          font-size: 14px;
        }
      }

      ::v-deep .el-table__body {
        td {
          padding: 12px 0;
          font-size: 14px;
        }

        tr {
          &:hover {
            background-color: #f5f7fa;
          }
        }

        .student-name {
          color: #303133;
          font-weight: 500;
        }

        .grade-class {
          color: #606266;
        }
      }

      ::v-deep .el-checkbox {
        .el-checkbox__input.is-checked .el-checkbox__inner {
          background-color: #409eff;
          border-color: #409eff;
        }

        .el-checkbox__input.is-indeterminate .el-checkbox__inner {
          background-color: #409eff;
          border-color: #409eff;
        }
      }
    }
  }

  .student-table-pagination {
    margin-top: 16px;
    display: flex;
    justify-content: flex-end;
    padding-top: 12px;
    border-top: 1px solid #f0f0f0;

    ::v-deep .el-pagination {
      .el-pagination__total,
      .el-pagination__jump {
        color: #606266;
        font-size: 13px;
      }

      .btn-prev,
      .btn-next,
      .el-pager li {
        background-color: #ffffff;
        color: #606266;
        border: 1px solid #dcdfe6;

        &:hover {
          color: #409eff;
        }

        &.active {
          background-color: #409eff;
          color: #ffffff;
          border-color: #409eff;
        }
      }
    }
  }

  .help-text {
    margin-top: 12px;
    font-size: 12px;
    color: #909399;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    background: #f5f7fa;
    border-radius: 4px;

    i {
      font-size: 14px;
      color: #409eff;
    }
  }

  .pdf-table-container {
    border: 1px solid #e4e7ed;
    border-radius: 6px;
    padding: 16px;
    background: #ffffff;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);

    .pdf-table-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 1px solid #f0f0f0;

      .selected-info {
        color: #409eff;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 4px;

        i {
          font-size: 16px;
        }

        strong {
          color: #303133;
          font-weight: 600;
          margin: 0 2px;
        }
      }

      .action-buttons {
        display: flex;
        align-items: center;
        gap: 12px;

        .el-button {
          padding: 6px 12px;
          color: #606266;
          font-size: 13px;

          &:hover {
            color: #409eff;
            background: #ecf5ff;
          }

          i {
            margin-right: 4px;
          }
        }
      }
    }

    .table-wrapper {
      border: 1px solid #ebeef5;
      border-radius: 4px;
      overflow: hidden;
      background: #ffffff;
    }

    .pdf-table-pagination {
      margin-top: 16px;
      display: flex;
      justify-content: flex-end;
      padding-top: 12px;
      border-top: 1px solid #f0f0f0;
    }

    .help-text {
      margin-top: 12px;
      font-size: 12px;
      color: #909399;
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 12px;
      background: #f5f7fa;
      border-radius: 4px;

      i {
        font-size: 14px;
        color: #409eff;
      }
    }
  }
}
</style>

