import request from '@/utils/request'

// 查询报表列表
export function listReport(query) {
  return request({
    url: '/system/report/list',
    method: 'get',
    params: query
  })
}

// 查询报表树（后端已按学段分组）
export function listReportTree(query) {
  return request({
    url: '/system/report/tree',
    method: 'get',
    params: query
  })
}

// 查询报表详细
export function getReport(id) {
  return request({
    url: '/system/report/' + id,
    method: 'get'
  })
}


